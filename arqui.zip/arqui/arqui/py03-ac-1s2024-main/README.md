## Proyecto PY03 - Battleship

Este repositorio contiene el código y la documentación para el Proyecto PY03, desarrollado como parte del curso de Arquitectura de Computadoras.

### Descripción

Desarrollar un juego de Battleship en lenguaje ensamblador ARM x64, con opción para partidas solitarias o multijugador (opcional) a través de sockets.

### Requerimientos

- Configuración del juego: Mapa estándar o personalizado.
- Tamaño del mapa: Entre 10x10 y 20x20 celdas.
- Colocación de barcos: Portaaviones, acorazado, submarino, crucero y destructor.
- Modos de juego: Solitario o multijugador (opcional).
- Jugabilidad: Movimientos mediante comandos en consola.

### Integrantes

- Eyden Su Díaz             [2023025837]
- Brasly Villarebia Morales []
- Elder Joshua Leon Perez   []