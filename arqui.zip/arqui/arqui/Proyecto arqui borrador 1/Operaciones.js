//Codigo Elder
class Operaciones {
  static baseFinal=0;
  static base=0;
  // Listas
  jerarquia = [];
  opereacionA=[];
  funcion="";
    constructor(funcion,basex) {
      this.baseFinal=basex;
      this.funcion = funcion;
      this.jerarquia = [];
      this.base=0;
      this.separarExpresion() ;
      
    }
  /**
* Función: sumaBases
* Realiza la división de dos números en la misma base del 2 al 16, sin usar bases intermedias ni parseInt.
* @param {string} num1 - El numero que va sumado
* @param {string} num2 - El nuemero que se va a sumar
 *@param {string} base - base comun de los numeros

* @returns {string|result} - El resultado de la suma en la misma base o NaN si hay un error.
*/
  sumaBases(num1, num2,base,w){
    let key= true;
    key=w;
    let num3=0;
    let carrry=0;
    let result = '';
    function divisionConResiduo(dividendo, divisor) {
      let cociente = Math.floor(dividendo / divisor);
      let residuo = dividendo % divisor;
      return [cociente, residuo];
    }
    
    while (num1.length < num2.length) {
      num1 = '0' + num1;
    }
    
    while (num2.length < num1.length) {
      num2 = '0' + num2;
    }
    

    for (let i=num1.length-1; i>=0;i--){
      let z = num1[i];
      let A=num2[num2.length-1];
      let S =0;
      if (A+''=='A'||'B'|'C'||'D'||'E'||'F'){
        A= this.hexADecimal(A);
        if (A==-1){
          A=num2[num2.length-1]*1
        }
      }
      if (z+''=='A'||'B'|'C'||'D'||'E'||'F'){
        z= this.hexADecimal(z);
        if (z==-1){
           z = num1[i]*1;
        }
      }
      S = z+A*1+carrry;
      if (S>=base){
       
        let change =divisionConResiduo(S,base);
        S=change[1];
        carrry=change[0];
        }
      else{
      carrry=0;
      }
      if (base>10&&S>9){
        S=this.convertirBase(S+'',10+'',base+'');

      }
      else{
        S=S+""+"_"+base+""
      }
    
       
      
      
      let d= this.BaseDeOperacion(S)
      result=d[0]+""+result;
      num2=num2.slice(0, -1);
    }
    //result=this.convertirBase(result,10+'',base+'');
    if (carrry>0){
      result=carrry+""+result;
    }
    if (key){
      result=(result+"_"+base+"")

    }
    
    return result;
    }
  



 
 /**
* Función: multplicacionBases
* Realiza la multiplicacion de dos números en la misma base del 2 al 16, sin usar bases intermedias ni parseInt.
* @param {string} num1 - El numero que va sumado
* @param {string} num2 - El nuemero que se va a sumar
 *@param {string} base - base comun de los numeros

* @returns {string|resultado} - El resultado de la suma en la misma base o NaN si hay un error.
*/

multplicacionBases(num1,num2,base){
  
  let x=this.BaseDeOperacion(num2+""+"_"+base+"");
  if (x[1]!='10'){
    num2=this.convertirBase(num2,base,10);
     x=this.BaseDeOperacion(num2);
  }
  let num=num1;
  let contador=x[0]*1;
  let resultado="0";
  while (contador!=0){
    let r=this.sumaBases(resultado, num,base,false);
    let r2=r[0];
    resultado=r;
    contador--;
  }
  resultado= (resultado+""+"_"+base+"")  
  return resultado;
}
/**
* Función: restaBases
* Realiza la resta de dos números en la misma base del 2 al 16, sin usar bases intermedias ni parseInt.
* @param {string} num1 - El numero que va sumado
* @param {string} num2 - El nuemero que se va a sumar
 *@param {string} base - base comun de los numeros

* @returns {string|resultado} - El resultado de la suma en la misma base o NaN si hay un error.
*/
restaBases (num1,num2,base){
  let num3=0;
  let carrry=0;
  let result = '';
  function pedir(){

    let valor=num1[num1.length-2];
    let x = valor-base;
    if (isNaN(valor)) {
      num1[num1.length-2]=0;
    }
    else{
      num1[num1.length-2]=x;
    }
    return base*1;
  }
  while (num1.length < num2.length) {
    num1 = '0' + num1;
  }
  
  while (num2.length < num1.length) {
    num2 = '0' + num2;
  
  }
  num1=num1.split("");
  num2=num2.split("");
  while (num1.length && num2.length>0){
    let numero1=num1[num1.length-1];
    let numero2=num2[num2.length-1];// verificar si es letra
    if (numero1+''=='A'||'B'|'C'||'D'||'E'||'F'){
      numero1= this.hexADecimal(numero1);
      if (numero1==-1){
        numero1=num1[num1.length-1]*1;
      }
    }
    if (numero2+''=='A'||'B'|'C'||'D'||'E'||'F'){
      numero2= this.hexADecimal(numero2);
      if (numero2==-1){
        numero2 = num2[num2.length-1]*1;
      }
    if (numero1-numero2<0){
      if (num1.length==1){
        result=numero1-numero2+result;
      }
      else{
        numero1=numero1+pedir();
        result=numero1-numero2+result;

      }
      
    }
    else {
      result=numero1-numero2+""+result;

    }
    num1=num1.slice(0,-1);
    num2=num2.slice(0,-1);
  }
}
result=result+"_"+base+"";
return result;
}

    //metodos auxilares 
    /**
* Función: igualarBases
* Realiza la homogenizacion de dos números en la misma base del 2 al 16, sin usar bases intermedias ni parseInt.
* @param {string} num1 - El numero que va utilizar
* @param {string} num2 - El numero que se va a utilizar
* @returns {array|final} - ambas bases se igualan 
*/

    IgualarBases(num1,num2){
      let temp="";
      let final=[];
      if (num1[1]==num2[1]){
        if (this.base *1< num2[1] * 1) {
          this.base = num2[1] * 1;
        }

      }

      else if (num1[1]*1==this.base){
      temp=this.convertirBase(num2[0],num2[1],this.base);//num, baseNum, baseFin
       num2=this.BaseDeOperacion(temp);
     }
     else if (num2[1]*1==this.base){
       temp=this.convertirBase(num1[0],num1[1],this.base);//num, baseNum, baseFin
       num1=this.BaseDeOperacion(temp);
       
     }
     else{
       temp=this.convertirBase(num2[0],num2[1],this.base);//num, baseNum, baseFin
       num2=this.BaseDeOperacion(temp);
       temp=this.convertirBase(num1[0],num1[1],this.base);//num, baseNum, baseFin
       num1=this.BaseDeOperacion(temp);
     }
     final.push(num1);
     final.push(num2);
     return final;
    }
    /**
* Función: EliminarEspacios
* Elimina los espacios entre la funcion desde base del 2 al 16, sin usar bases intermedias ni parseInt.
* @returns {string|resultado} - iguala la variable global a otra sin espacios
*/

    EliminarEspacios() {
      let nuevaCadena = [];

      for (let i = 0; i < this.jerarquia.length; i++) {
          if (this.jerarquia[i] != ""||this.jerarquia[i] !='') {
              nuevaCadena.push( this.jerarquia[i]);
          }
      }
      this.jerarquia=nuevaCadena;
     // this.RecorrerFuncion();
  }
  /**
* Función: BaseDeOperacion
* Realiza la busqueda de las bases de los números en la misma base del 2 al 16, sin usar bases intermedias ni parseInt.
* @param {string} operacion -Es un numero a cual se le extrae su base
* @returns {array|[num, base]} - El resultado de la busqueda y sus bases
*/

BaseDeOperacion(operacion) {
 

  let base = "";
  let num = "";

  for (let i = 0; i < operacion.length; i++) {
    if (operacion[i] == "_") {
      for (let x = i + 1; x < operacion.length; x++) {
        base += operacion[x];
      }
      break;
    }
    num += operacion[i];
  }

  
  if (this.base *1< base * 1) {
    this.base = base * 1;
  }
  return [num,base];
}

  /**
* Función: separarExpresion
* Realiza la separacion  de dos números en la misma base del 2 al 16 por cada operador, sin usar bases intermedias ni parseInt.
* @returns {string|resultado} - El resultado de la suma en la misma base o NaN si hay un error.
*/
  separarExpresion() {
    let inicio = 0;
    let expresion = this.funcion;
    for (let i = 0; i < expresion.length; i++) {
      let caracter = expresion.charAt(i);

      if (
        caracter === "+" ||
        caracter === "-" ||
        caracter === "*" ||
        caracter === "/" ||
        caracter === "("
      ) {
        let parte = expresion.substring(inicio, i);
        this.jerarquia.push(parte.trim());
        this.jerarquia.push(caracter);
        inicio = i + 1;
      } else if (caracter === ")") {
        let parte = expresion.substring(inicio, i);
        this.jerarquia.push(parte.trim());
        this.jerarquia.push(caracter);
        inicio = i + 1;
      }
    }
    if (inicio < expresion.length) {
      let parteFinal = expresion.substring(inicio);
      this.jerarquia.push(parteFinal.trim());
    }

    this.EliminarEspacios();
    return this.jerarquia;
  }
    /**
* Función: igualarBases
* Realiza la cuenta de dos operador que salgan en la funcion 
* @param {string} numeros - El numero que va utilizar
* @param {string} busca - el operador que se este buscando
* @returns {array|final} - ambas bases se igualan 
*/
  contadorOperaciones (numeros , busca) {
    let pos = 0;
    let contador = 0;
    let resultado=[];
    for (let i = 0; i < numeros.length; i++) {
      if (numeros[i] === busca) { // Buscar coincidencia del elemento completo
        contador++;
        pos = i;
      }
      
    }
    resultado.push(contador);
    resultado.push(pos);
    return resultado;
  }
    /**
* Función: resolverLineal
* se encarga de ejecutar la jerarquia de operaciones
* @param {string} x -son las operaciones que se van a analizar 
* @returns {string|resultado} - ambas bases se igualan 
*/
  resolverLineal(x) {//hacer que num1 y 2 sean listas con numero y base
    let resultado="";
    let multi = this.contadorOperaciones(x, "*");
    let divi = this.contadorOperaciones(x, "/");
    let rest = this.contadorOperaciones(x, "-");
    let sum = this.contadorOperaciones(x, "+");
  if (multi[0]!=0||divi[0]!=0||rest[0]!=0||sum[0]!=0){
      while (multi[0] > 0) {
   
        let pos = multi[1];
        let temp=[];
        let num1=[];
        let num2=[];
        num1=this.BaseDeOperacion(x[pos - 1] );//enviar a convertir base
        num2=this.BaseDeOperacion(x[pos + 1] );
        temp=this.IgualarBases(num1,num2);
        num1=temp[0][0];
        num2=temp[1][0];  
        let d =this.base;// no,jala la base 
       
        let multiplicacion = this.multplicacionBases(num1,num2,d)
        x.splice(pos, 2);//elimina hacia adelante + 1 para el operador
        x.splice(pos-1, 1, multiplicacion);
       // resultado=multiplicacion;
        multi = this.contadorOperaciones(x, "*");
      
    
      }

      while (divi[0] > 0) {
        
        let pos = divi[1];
        
        let temp=[];
        let num1=[];
        let num2=[];
        let division=0;
        num1=this.BaseDeOperacion(x[pos - 1] );//enviar a convertir base
        num2=this.BaseDeOperacion(x[pos + 1] );
        temp=this.IgualarBases(num1,num2);
        num1=temp[0][0];
        num2=temp[1][0];  
        
        if (temp[0][1]>=11){
           division = this.div11To16(num1+""+"_"+temp[0][1]+"",num2+""+"_"+temp[0][1]);
        }
        else{
          division = this.div2To10(num1+""+"_"+temp[0][1]+"",num2+""+"_"+temp[0][1]);
        }
        x.splice(pos,2);//elimina hacia adelante + 1 para el operador
        x.splice(pos-1, 1,division);
        this.resolverLineal(x);
        
        //resultado=division;
        divi = this.contadorOperaciones(x, "/");
      
        
      }

      while (sum[0] > 0) {
        
        let pos = sum[1];
  
        let temp=[];
        let num1=[];
        let num2=[];
        num1=this.BaseDeOperacion(x[pos - 1] );//enviar a convertir base
        num2=this.BaseDeOperacion(x[pos + 1] );
        temp=this.IgualarBases(num1,num2);
        num1=temp[0][0];
        num2=temp[1][0];  
        let suma =  this.sumaBases(num1,num2,this.base,true);
        x.splice(pos, 2);//elimina hacia adelante + 1 para el operador
        x.splice(pos-1, 1, suma);
        this.resolverLineal(x);
        //resultado=suma;
        sum = this.contadorOperaciones(x, "+");
       
      }

      while (rest[0] > 0) {
        
        let pos = rest[1];
        
        let temp=[];
        let num1=[];
        let num2=[];
        num1=this.BaseDeOperacion(x[pos - 1] );//enviar a convertir base
        num2=this.BaseDeOperacion(x[pos + 1] );
        temp=this.IgualarBases(num1,num2);
        num1=temp[0][0];
        num2=temp[1][0];  
        let resto = this.restaBases (num1,num2,this.base);
        x.splice(pos,2);//elimina hacia adelante + 1 para el operador
        x.splice(pos-1, 1, resto);
        this.resolverLineal(x);
        //resultado=resto;
        rest = this.contadorOperaciones(x, "-");
      }
     
    }
   
    resultado+=x[0]+"";
    x=[];
    return resultado;
  }
  

 /**
* Función: RecorrerFuncion
* recorre la funcion completa 
* @returns {string|resultados} - ambas bases se igualan 
*/
RecorrerFuncion() {
  let Evaluando = [];
  let resultados = "";
  let contador = 0;
  let pos = this.contadorOperaciones(this.jerarquia, "(");

  if (pos[0] > 0) {
      for (let i = pos[1] + 1; i < this.jerarquia.length; i++) {
          if (this.jerarquia[i] != ")") {
              Evaluando.push(this.jerarquia[i]);
              contador += 1;
          } else if (this.jerarquia[i] == ")") {
              resultados = this.resolverLineal(Evaluando);
              this.jerarquia.splice(pos[1], contador + 1); // elimina desde pos[0] hasta contador + 1 elementos
              this.jerarquia.splice(pos[1], 1, resultados);
              pos = this.contadorOperaciones(this.jerarquia, "(");
              // Reiniciar evaluación
              Evaluando = [];
              contador = 0;
              if(pos[0]>0){
                this.RecorrerFuncion() ;
              }
          }
      }
  }
  if (pos[0] <= 0) {
      resultados = this.resolverLineal(this.jerarquia);
      this.jerarquia.splice(0, this.jerarquia.length, resultados);
      //console.log(this.jerarquia);
  }
  resultados=this.BaseDeOperacion(this.jerarquia[0]+"");
  if(resultados[1]!=this.baseFinal+""){
     resultados= this.convertirBase(resultados[0],resultados[1],this.baseFinal+"");
    // console.log(resultados);
     //this.jerarquia=[];
    return resultados;
  }
  //this.jerarquia=[];
  //console.log(resultados);
  resultados=resultados[0]+""+"_"+resultados[1]+"";
  return resultados;
}
 
 /**
 * Función: hexADecimal
 * Convierte un dígito hexadecimal en su equivalente decimal.
 * @param {string} pNum - El dígito hexadecimal a convertir.
 * @returns {number} - El equivalente decimal del dígito hexadecimal.
 */
 hexADecimal(pNum) {
   switch (pNum) {
       case 'A': return 10;
       case 'B': return 11;
       case 'C': return 12;
       case 'D': return 13;
       case 'E': return 14;
       case 'F': return 15;
       default: return -1; 
   }
 }


 /**
 * Función: biggerBase
 * Verifica si algún dígito de un número es mayor o igual a una base dada.
 * @param {string} num - El número a verificar.
 * @param {number} finBase - La base a comparar.
 * @returns {boolean} - Devuelve true si algún dígito es mayor o igual a la base, de lo contrario false.
 */
  biggerBase(num, finBase) {
   for (let i = 0; i < num.length; i++) { if (num[i]*1 >= finBase*1) { return true; } }
   return false;
 }
 
 /**
 * Función: decimalAHex
 * Convierte un número decimal en su equivalente hexadecimal.
 * @param {number} pNum - El número decimal a convertir.
 * @returns {string|number} - El equivalente hexadecimal del número decimal o -1 si no es posible la conversión.
 */
 decimalAHex(pNum) {
   switch (pNum) {
       case 10: return 'A';
       case 11: return 'B';
       case 12: return 'C';
       case 13: return 'D';
       case 14: return 'E';
       case 15: return 'F';
       default: return -1; 
   }
 }
 
 /**
 * Función: changeBase
 * Convierte un número de una base a otra base.
 * @param {string} num - El número a convertir.
 * @param {number} baseFin - La base objetivo de la conversión.
 * @returns {number} - El número convertido en la base objetivo.
 */
  changeBase(num, baseFin) { 
   let resul = 0;
   for (let i = 0; i < num.length; i++) {
       resul += (Math.trunc(num[num.length - (i+1)] / baseFin) * 10**(i+1)) + ((num[[num.length - (i+1)]] % baseFin)* 10**(i));
   }
   return resul;
 }
 
 /**
 * Función: sum
 * Realiza la suma de dos números en la misma base.
 * @param {string} num - El primer número a sumar.
 * @param {number} baseFin - La base en la que se realiza la suma.
 * @param {string} num2 - El segundo número a sumar.
 * @returns {string} - El resultado de la suma en la misma base.
 */
 sum(num, baseFin, num2) {
 
   let aux = 0;
   let maxlen = 0;
 
   if (num.length > num2.length) {
       maxlen = num.length;
 
   } else {
       maxlen = num2.length;
   }
   for (let i = 1; i <= maxlen; i++) {
 
       if (i > num.length) {
           aux = (num * 1 + (num2[num2.length - i] * 10**(i -1)));
 
       } else if (i > num2.length) {
           return num;
 
       } else if (((num[num.length - i] * 1) + (num2[num2.length - i] * 1)) >= baseFin) {
 
           aux = ((num[num.length - i] * 1) + (num2[num2.length - i] * 1) * 1);
           aux = (Math.trunc(aux / baseFin) * 10 **(i)) + (aux % baseFin* 10 **(i-1));
           aux += (num * 1 - (num[num.length - i] * 10**(i -1)));
           aux += '';
 
           if (aux[(aux).length - (i+1)] >= baseFin) {
               aux *= 1;
               aux -= (num * 1 - num[num.length - i] * 10**(i-1));
               aux = this.sum((num * 1 - num[num.length - i] * 10**(i-1))+'', baseFin, aux+'');
           }
 
       } else {
           aux = (num*1 + (num2[num2.length - i]) * 10 ** (i-1));
       }
       num = aux+'';
   }
   return aux;
 }
 
 /**
 * Función: hexSum
 * Realiza la suma de dos números en base hexadecimal.
 * @param {string} num - El primer número en hexadecimal a sumar.
 * @param {number} baseFin - La base en la que se realiza la suma.
 * @param {string} num2 - El segundo número en hexadecimal a sumar.
 * @returns {string} - El resultado de la suma en hexadecimal.
 */
 hexSum(num, baseFin, num2) {
 
   let resultado = '';
   let aux = 0;
   let maxlen = 0;
   let count = 0;
 
   if (num.length > num2.length) {
       maxlen = num.length;
   } else {
       maxlen = num2.length;
   }
   for (let i = 1; i <= maxlen; i++) {
       let num1_aux = (num[num.length - i]);
       let num2_aux = (num2[num2.length - i]);
 
       if ((num1_aux === undefined) && (num2_aux === undefined)) {
           break;
       }
       
       if ((i > num.length)) {
           aux = '';
           count = i-1;
       
           while (count != 0) {
               aux +='0';
               count -= 1;
           }
           aux = num2_aux + aux;
 
           if (aux.length === resultado.length) {
               resultado = this.hexSum(resultado, baseFin, aux);
           
           } else {
               resultado = num2_aux + resultado;
           }
           continue;
       
       } else if (i > num2.length ) {
           aux = '';
           count = i-1;
       
           while (count != 0) {
               aux +='0';
               count -= 1;
           }
 
           aux = num1_aux + aux;
 
           if (aux.length === resultado.length) {
               resultado = this.hexSum(resultado, baseFin, aux);
 
           } else {
               resultado = num1_aux + resultado;
           }
           continue;
       }
       
       if (this.hexADecimal(num1_aux) != -1) {
           num1_aux = this.hexADecimal(num1_aux);
       }
       if (this.hexADecimal(num2_aux) != -1) {
           num2_aux = this.hexADecimal(num2_aux);
       }
 
       if ((num1_aux*1 + num2_aux*1) >= baseFin) {
 
           aux = (num1_aux*1 + num2_aux*1);
           let aux2 = (Math.trunc(aux / baseFin));
           let aux3 = (aux % baseFin);
 
           if ((this.decimalAHex(aux2) != -1)) {
               aux2 = this.decimalAHex(aux2);
           }
           if (this.decimalAHex(aux3) != -1) {
               aux3 = this.decimalAHex(aux3);
           }
           count = i-1;
           aux = '';
           while (count != 0) {
               aux +='0';
               count -= 1;
           }
           aux = (aux2+'') + (aux3+'') + aux;
           resultado = this.hexSum(resultado, baseFin, aux);
       
       } else {
           aux = (num1_aux*1) + (num2_aux*1);
           if (this.decimalAHex(aux) != -1) {
               aux = this.decimalAHex(aux);
               count = i-1;
 
               while (count != 0) {
                   aux +='0';
                   count -= 1;
               }
               if (resultado != '') {
                   resultado = this.hexSum(aux, baseFin, resultado);
 
               } else {
                   resultado += aux;
               }
 
           } else {
               resultado = aux+'' + resultado;
           }
       }
   }
   return resultado;
 }

 /**
 * Función: mult
 * Realiza la multiplicación de dos números en la misma base.
 * @param {string} num - El primer número a multiplicar.
 * @param {string} baseAux - La base en la que se encuentra el primer número.
 * @param {number} baseFin - La base en la que se realiza la multiplicación.
 * @returns {string} - El resultado de la multiplicación en la misma base.
 */
 mult(num, baseAux, baseFin) {
   let resultado = ''
   let numAux = 0;
   for (let i=1; i <= baseAux.length; i++) {
 
       for (let j=1; j <= num.length; j++) {
           numAux = ((num[num.length - j] * 1) * (baseAux[baseAux.length - i] * 1)) ;
           numAux = (Math.trunc(numAux / baseFin) * 10 **(j)) + (numAux % baseFin* 10 **(j-1));
           while(this.biggerBase(numAux+'', baseFin)) {
               numAux = this.changeBase(numAux+'', baseFin);
           }
           resultado = this.sum(resultado+'', baseFin, numAux+'');
       }
   }
   return resultado;
 }
 
 /**
 * Función: hexMult
 * Realiza la multiplicación de dos números en base hexadecimal.
 * @param {string} num - El primer número en hexadecimal a multiplicar.
 * @param {string} baseAux - La base en la que se encuentra el primer número.
 * @param {number} baseFin - La base en la que se realiza la multiplicación.
 * @returns {string} - El resultado de la multiplicación en hexadecimal.
 */
 hexMult(num, baseAux, baseFin) {
   let resultado = '';
   let numAux = 0;
   let aux = '';
   let baseNum = 0;
   let count = 0;
 
   if (baseAux%baseFin === 0) {
       baseNum = (Math.trunc(baseAux / baseFin) * 10) + (baseAux % baseFin* 1);
       while(this.biggerBase(baseNum+'', baseFin)) {
           baseNum = this.changeBase(baseNum+'', baseFin);
       }
   }
   for (let j=1 ; j <= num.length; j++) {
 
       numAux = num[num.length - j];
       
       if (this.hexADecimal(numAux) != -1) {
           numAux = this.hexADecimal(numAux);
       }
       if (baseNum != 0 && !this.isHex(num)) {
           return (num * baseNum)+'';
       }
       let aux1 = (numAux * (baseAux* 1));
       let aux2 = Math.trunc(aux1 / baseFin);
       let aux3 = aux1 % baseFin;
 
       if ((this.decimalAHex(aux2) != -1)  && baseFin*1 > 10) {
           aux2 = this.decimalAHex(aux2);
       }
       if (this.decimalAHex(aux3) != -1  && baseFin*1 > 10) {
           aux3 = this.decimalAHex(aux3);
       }
       if (aux2 === 0) {
           if (aux2*1 != 0 || aux3*1 != 0) {
 
               count = j-1;
               while (count > 0) {
                   aux3 = aux3 + '0';
                   count -= 1;
               }
               if (aux2*1 != 0) {
                   aux = this.hexSum(aux, baseFin, (aux2+'') + (aux3+''));
               } else {
                   aux = this.hexSum(resultado, baseFin, (aux3+''));
               }
           } else {
               aux = '0';
           }
           
       } else if (((aux2+'') + (aux3+'')).length === aux.length) {
 
           count = j-1;
 
           while (count > 0) {
               aux3 = aux3 + '0';
               count -= 1;
           }
           aux = this.hexSum(aux, baseFin, (aux2+'') + (aux3+''));
       } else {
           aux = ''; 
           count = ((aux2+'') + (aux3+'')).length -1;
           
           while (count < j) {
               aux += '0';
               count ++;
           }
 
           aux = (aux2+'') + (aux3+'') + aux;
           resultado = this.hexSum(aux, baseFin, resultado);
           aux = '0';
       }
       if (aux*1 != 0) {
           resultado = aux;
       }
   }
   return resultado;
 }
 
 /**
 * Función: hexMult2
 * Realiza la multiplicación de dos números en base hexadecimal (variante).
 * @param {string} num - El primer número en hexadecimal a multiplicar.
 * @param {string} baseAux - La base en la que se encuentra el primer número.
 * @param {number} baseFin - La base en la que se realiza la multiplicación.
 * @returns {string} - El resultado de la multiplicación en hexadecimal.
 */
 hexMult2(num, baseAux, baseFin) {
   let resultado = '';
   let numAux = 0;
   let aux = '';
   let multAux = '';
   let count = 0;
 
   baseAux = (Math.trunc(baseAux / baseFin) * 10) + (baseAux % baseFin* 1) +'';
   while (this.biggerBase(baseAux+'', baseFin)) {
       baseAux = this.changeBase(baseAux+'', baseFin) +'';
   }
 
   for (let i=1; i <= baseAux.length; i++) {
       multAux = baseAux[baseAux.length-i];
       for (let j=1 ; j <= num.length; j++) { 
           numAux = num[num.length - j];
       if (this.hexADecimal(numAux) != -1) {
           numAux = this.hexADecimal(numAux);
       }
       let aux1 = (numAux * (multAux* 1));
       let aux2 = (Math.trunc(aux1 / baseFin));
       let aux3 = (aux1 % baseFin);
       count = i-1;
       
       while (count > 0) {
           aux3 += '0';
           count --;
       }
       if (aux2*1 === 0) {
           if (aux3*1 != 0) {
 
               count = j-1;
               while (count > 0) {
                   aux3 = aux3 + '0';
                   count -= 1;
               }
               if (aux2*1 != 0) {
                   aux = this.hexSum(aux, baseFin, (aux2+'') + (aux3+''));
               } else {
                   aux = this.hexSum(resultado, baseFin, (aux3+''));
               }
           } else {
               aux = '0';
           }
           
       } else if (((aux2+'') + (aux3+'')).length === aux.length) {
 
           count = j-1;
 
           while (count > 0) {
               aux3 = aux3 + '0';
               count -= 1;
           }
           aux = this.hexSum(aux, baseFin, (aux2+'') + (aux3+''));
       } else {
           aux = ''; 
           if (aux3.length > 1) {
               count = ((aux2+'') + (aux3+'')).length -2;
           } else {
               count = ((aux2+'') + (aux3+'')).length -1;
           }
           
           while (count < j) {
               aux += '0';
               count ++;
           }
           aux = (aux2+'') + (aux3+'') + aux;
           resultado = this.hexSum(aux, baseFin, resultado);
           aux = '0';
       }
       if (aux*1 != 0) {
           resultado = aux;
       }
       }
   }
   return resultado
 }
 
 /**
 * Función: convertirBaseMayorAMenor
 * Convierte un número de una base mayor a una base menor o igual.
 * @param {string} num - El número a convertir.
 * @param {number} baseNum - La base en la que se encuentra el número.
 * @param {number} baseFin - La base objetivo de la conversión.
 * @returns {string} - El número convertido en la base objetivo.
 */
 convertirBaseMayorAMenor(num, baseNum, baseFin) {
   let aux = '';
   let i = 0;
   if(num.length === 1) {
       if (this.hexADecimal(num) != -1) {
           num = this.hexADecimal(num);
       }
       let aux = (Math.trunc(num / baseFin) * 10) + (num % baseFin* 1);
       if(this.biggerBase(aux+'', baseFin)) {
           aux = this.changeBase(aux+'', baseFin);
       }
       return aux + '_' + baseFin;
   }
 
   if (baseNum*1 === 10) {
       return this.base10ABaseN(num*1, baseFin*1);
   }
 
   while (i < num.length-1) {
       if (i === 0) {
           aux = num[i];
       }
       if (baseNum*1 > 10) {
           if (this.hexADecimal(aux) != -1 ) {
               aux = this.hexADecimal(aux);
               if(baseFin*1 < baseNum*1) {
                   aux = (Math.trunc(aux / baseFin) * 10) + (aux % baseFin* 1);
                   while(this.biggerBase(aux+'', baseFin)) {
                       aux = this.changeBase(aux+'', baseFin);
                   }
               }
               aux = this.hexMult2(aux+'', baseNum+'', baseFin*1);
           }else {
 
               aux = this.hexMult2(aux+'', baseNum+'', baseFin*1);
           }
       } else {
           aux = this.mult(aux+'', baseNum+'', baseFin*1);
       }
       if ((i+1) < num.length) {
           if(baseNum*1 > 10) {
               if (this.hexADecimal(num[i+1]) != -1) {
                   let digit = this.hexADecimal(num[i+1]);
                   
                   if ((num[i+1]*1) + digit >= baseFin) {
                       aux = this.hexSum(aux+'', baseFin*1, num[i+1]);
                   } else {
                       aux = this.hexSum(aux, baseFin, num[i+1]);
                   }
               } else {
                   aux = this.hexSum(aux, baseFin, num[i+1]);
               }
           } else {
               console.log(num[i+1])
               aux = this.sum(aux+'', baseFin*1, num[i+1]);
           }
       }
       i += 1;
   }
   while (this.biggerBase(aux+'', baseFin)) {
       aux = this.changeBase(aux+'', baseFin);
   }
   return aux + '_' + baseFin;
 }

 /**
 * Función: convertirBase
 * Convierte un número de una base a otra base.
 * @param {string} num - El número a convertir.
 * @param {number} baseNum - La base en la que se encuentra el número.
 * @param {number} baseFin - La base objetivo de la conversión.
 * @returns {string} - El número convertido en la base objetivo.
 */
 convertirBase(num, baseNum, baseFin) {
   let aux = '';
   let i = 0;
   let baseAux = baseNum;
 
   if(baseFin*1 < baseNum*1) {
       return this.convertirBaseMayorAMenor(num,baseNum, baseFin);
   }
   while (this.biggerBase(baseAux+'', baseFin)) {
       baseAux = this.changeBase(baseAux, baseFin);
   }
 
   while (i < num.length - 1) {
       if (i === 0) {
           aux = num[i];
       }
       if (num[i] * 1 >= baseFin) {
           aux = this.changeBase(aux, baseFin);
       }
       if (baseFin > 10) {
           aux = this.hexMult(aux+'', baseAux+'', baseFin*1);
           
       } else {
           aux = this.mult(aux+'', baseAux+'', baseFin*1);
       }
       if ((i+1) < num.length) {
           if (baseFin > 10) {
               let digit = (aux+'')[(aux+'').length- 1];
               if (this.hexADecimal(digit) != -1) { digit = this.hexADecimal(digit); }
 
               if ((num[i+1]*1) + digit >= baseFin) {
                   aux = this.hexSum(aux+'', baseFin*1, num[i+1]);
               } else {
                   aux = this.hexSum(aux, baseFin, num[i+1]);
               }
           } else {
               aux = this.sum(aux+'', baseFin*1, num[i+1]);
           }
       }
       i += 1;
   }
   return aux + '_' + baseFin;
 }


 
// Codigo heldys 
//Código de Heldyis Agüero Espinoza

/**
 * Función: compararBase
 * Compara dos números en una base dada.
 * @param {string} num1 - El primer número a comparar.
 * @param {string} num2 - El segundo número a comparar.
 * @param {number} base - La base en la que se están comparando los números.
 * @returns {number} - 0 si los números son iguales, -1 si el primer número es menor, 1 si el segundo número es menor.
 */

 compararBase(num1, num2, base) {
  num1 = num1.toUpperCase();
  num2 = num2.toUpperCase();

  if (num1.length < num2.length) return -1;
  if (num1.length > num2.length) return 1;

  for (let i = 0; i < num1.length; i++) {
      if (num1[i] !== num2[i]) {
          return num1[i] < num2[i] ? -1 : 1;
      }
  }
  return 0;
}

/**
* Función: sumaEnBase
* Realiza la suma de dos números en una base dada.
* @param {string} num1 - El primer número a sumar.
* @param {string} num2 - El segundo número a sumar.
* @param {number} base - La base en la que se están sumando los números.
* @returns {string} - El resultado de la suma en la misma base.
*/

 sumaEnBase(num1, num2, base) {
  const digitos = '0123456789ABCDEF';
  let carry = 0;
  let result = '';

  num1 = num1.padStart(num2.length, '0');
  num2 = num2.padStart(num1.length, '0');

  for (let i = num1.length - 1; i >= 0; i--) {
      const sum = digitos.indexOf(num1[i].toUpperCase()) + digitos.indexOf(num2[i].toUpperCase()) + carry;
      carry = sum >= base ? 1 : 0;
      result = digitos[sum % base] + result;
  }

  if (carry > 0) {
      result = '1' + result;
  }
  return result;
}

/**
* Función: restaEnBase
* Realiza la resta de dos números en una base dada.
* @param {string} num1 - El número del cual se resta el segundo número.
* @param {string} num2 - El número que se resta del primer número.
* @param {number} base - La base en la que se están restando los números.
* @returns {string} - El resultado de la resta en la misma base.
*/

 restaEnBase(num1, num2, base) {
  const digitos = '0123456789ABCDEF';
  let borrow = 0;
  let result = '';

  num1 = num1.padStart(num2.length, '0');
  num2 = num2.padStart(num1.length, '0');

  for (let i = num1.length - 1; i >= 0; i--) {
      let diff = digitos.indexOf(num1[i].toUpperCase()) - digitos.indexOf(num2[i].toUpperCase()) - borrow;
      if (diff < 0) {
          diff += base;
          borrow = 1;
      } else {
          borrow = 0;
      }
      result = digitos[diff] + result;
  }
  return result.replace(/^0+(?=\d)/, '') || '0';
}

/**
* Función: separarNumero
* Separa un número junto con su base a partir del guion bajo.
* @param {string} numero_base - El número junto con su base en el formato "numero_base".
* @returns {Array} - Un array que contiene el número y su base por separado.
*/

 separarNumero (numero_base) {
  //Separamos las partes a partir del guion bajo
  let partes = numero_base.split('_');
  return [partes[0],partes[1]];
}

/**
* Función: div2To10
* Realiza la división de dos números en la misma base sin usar bases intermedias ni parseInt.
* @param {string} numeroDividendo - El número que será dividido.
* @param {string} numeroDivisor - El número por el cual se dividirá el dividendo.
* @returns {string|NaN} - El resultado de la división en la misma base o NaN si hay un error.
*/

 div2To10(numeroDividendo, numeroDivisor) {
  // Separar el dividendo y el divisor en número y base
  let [dividendo_valor, baseString] = this.separarNumero(numeroDividendo);
  let [divisor_valor, divisor_base] = this.separarNumero(numeroDivisor);

  // Verificar que ambos números tengan la misma base
  if (baseString !== divisor_base) {
      return NaN;
  }

  let base = baseString * 1;

  // Verificar si el divisor es cero
  if (divisor_valor === '0') {
      return NaN;
  }

  let dividendo = dividendo_valor;
  let divisor = divisor_valor;

  // Inicializar el resultado de la división
  let resultado = '';

  // Convertir los números a arrays de dígitos
  const dividendoArray = dividendo.split('');
  const divisorArray = divisor.split('');

  let cocienteParcial = '';

  const digitosValidos = '0123456789ABCDEF'.slice(0, base);

  // Validar cada dígito del dividendo
  for (let i = 0; i < dividendoArray.length; i++) {
      if (!digitosValidos.includes(dividendoArray[i])) {
          return NaN;
      }
  }

  // Validar cada dígito del divisor
  for (let i = 0; i < divisorArray.length; i++) {
      if (!digitosValidos.includes(divisorArray[i])) {
          return NaN;
      }
  }

  // Iterar sobre cada dígito del dividendo
  for (let i = 0; i < dividendoArray.length; i++) {
      
      cocienteParcial += dividendoArray[i];

      let division = '';
      let divisorTemp = divisor;

      // Realizar la división en la base adecuada
      while (compararBase(cocienteParcial, divisorTemp, base) >= 0) {
          cocienteParcial = restaEnBase(cocienteParcial, divisorTemp, base);
          division = sumaEnBase(division, '1', base);
      }

      resultado += division === '' ? '0' : division; // Agregar el dígito al resultado
  }

  // Eliminar ceros a la izquierda del resultado
  if (resultado !== '0') {
      resultado = resultado.replace(/^0+/, '');
  }
  
  // Concatenar la base al resultado final
  resultado += '_' + baseString;
  return resultado;
}

/**
* Función: div11To16
* Realiza la división de dos números en la misma base del 11 al 16, sin usar bases intermedias ni parseInt.
* @param {string} numeroDividendo - El número que será dividido.
* @param {string} numeroDivisor - El número por el cual se dividirá el dividendo.
* @returns {string|NaN} - El resultado de la división en la misma base o NaN si hay un error.
*/
 div11To16(numeroDividendo, numeroDivisor) {
  let [numero, baseString] = this.separarNumero(numeroDividendo);
  let [divisor, divisor_base] = this.separarNumero(numeroDivisor);

  if (baseString !== divisor_base) {
      return "Error: Los números tienen bases diferentes.";
  }

  let base = baseString * 1;

  // Verificar que los números de entrada sean válidos
  if (typeof numero !== 'string' || typeof divisor !== 'string' || numero.length === 0 || divisor.length === 0 || base < 2 || base > 16) {
      return "Entrada inválida";
  }

  // Mapa de referencia para los dígitos hexadecimales
  const hexMap = {
      '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
      'A': 10, 'B': 11, 'C': 12, 'D': 13, 'E': 14, 'F': 15
  };

  // Función para realizar la división directamente en la base original
  const realizarDivision = (numero, divisor) => {
      let cociente = '';
      let resto = 0;
      let cocienteNoCero = false;

      for (let i = 0; i < numero.length; i++) {
          const valorNumero = hexMap[numero[i].toUpperCase()];
          const valorDivisor = hexMap[divisor.toUpperCase()];
          if (isNaN(valorNumero) || isNaN(valorDivisor) || valorNumero >= base || valorDivisor >= base) {
              return NaN; // Si algún dígito no es válido para la base, retornar NaN
          }

          const dividendo = resto * base + valorNumero;
          const division = Math.floor(dividendo / valorDivisor);
          resto = dividendo % valorDivisor;

          if (division !== 0) {
              cocienteNoCero = true;
          }

          if (cocienteNoCero || division !== 0 || i === numero.length - 1) {
              cociente += Object.keys(hexMap).find(key => hexMap[key] === division);
          }
      }
      // Concatenar la base al resultado final
      cociente += '_' + baseString;

      return cociente;
  };

  // Realizar la división directamente en la base original
  return realizarDivision(numero, divisor);
}

}


 











