function hexADecimal(pNum) {
    switch (pNum) {
        case 'A': return 10;
        case 'B': return 11;
        case 'C': return 12;
        case 'D': return 13;
        case 'E': return 14;
        case 'F': return 15;
        default: return -1; 
    }
}

function base10ABaseN(num, baseFin) {
    let result = '';
    while (num > 0) {
        let remainder = num % baseFin;
        result = (remainder+'') + result;
        num = Math.trunc(num / baseFin);
    }
    return result;
}

function isHex(num) {
    for (let i=0; i< num.length; i++) {
        if (hexADecimal(num[i]) != -1 ) {
            return true;
        }
    }
    return false;
}

function biggerBase(num, finBase) {
    for (let i = 0; i < num.length; i++) { if (num[i]*1 >= finBase*1) { return true; } }
    return false;
}

function decimalAHex(pNum) {
    switch (pNum) {
        case 10: return 'A';
        case 11: return 'B';
        case 12: return 'C';
        case 13: return 'D';
        case 14: return 'E';
        case 15: return 'F';
        default: return -1; 
    }
}

function changeBase(num, baseFin) { 
    let resul = 0;
    let count = 0;
    for (let i = 0; i < num.length; i++) {
        resul += (Math.trunc(num[num.length - (i+1)] / baseFin) * 10**(i+1)) + ((num[[num.length - (i+1)]] % baseFin)* 10**(i));
    }
    count --;
    
    return resul;
}

function sum(num, baseFin, num2) {

    let aux = 0;
    let maxlen = 0;

    if (num.length > num2.length) {
        maxlen = num.length;

    } else {
        maxlen = num2.length;
    }
    for (let i = 1; i <= maxlen; i++) {

        if (i > num.length) {
            aux = (num * 1 + (num2[num2.length - i] * 10**(i -1)));

        } else if (i > num2.length) {
            return num;

        } else if (((num[num.length - i] * 1) + (num2[num2.length - i] * 1)) >= baseFin) {

            aux = ((num[num.length - i] * 1) + (num2[num2.length - i] * 1) * 1);
            aux = (Math.trunc(aux / baseFin) * 10 **(i)) + (aux % baseFin* 10 **(i-1));
            aux += (num * 1 - (num[num.length - i] * 10**(i -1)));
            aux += '';

            if (aux[(aux).length - (i+1)] >= baseFin) {
                aux *= 1;
                aux -= (num * 1 - num[num.length - i] * 10**(i-1));
                aux = sum((num * 1 - num[num.length - i] * 10**(i-1))+'', baseFin, aux+'');
            }

        } else {
            aux = (num*1 + (num2[num2.length - i]) * 10 ** (i-1));
        }
        num = aux+'';
    }
    return aux;
}

function hexSum(num, baseFin, num2) {

    let resultado = '';
    let aux = 0;
    let maxlen = 0;

    if (num.length > num2.length) {
        maxlen = num.length;
    } else {
        maxlen = num2.length;
    }
    for (let i = 1; i <= maxlen; i++) {
        let num1_aux = (num[num.length - i]);
        let num2_aux = (num2[num2.length - i]);

        if ((num1_aux === undefined) && (num2_aux === undefined)) {
            break;
        }

        if ((i > num.length)) {
            aux = '';
            let count = i-1;
        
            while (count != 0) {
                aux +='0';
                count -= 1;
            }
            aux = num2_aux + aux;

            if (aux.length === resultado.length) {
                resultado = hexSum(resultado, baseFin, aux);
            
            } else {
                resultado = num2_aux + resultado;
            }
            continue;
        
        } else if (i > num2.length ) {
            aux = '';
            count = i-1;
        
            while (count != 0) {
                aux +='0';
                count -= 1;
            }

            aux = num1_aux + aux;

            if (aux.length === resultado.length) {
                resultado = hexSum(resultado, baseFin, aux);

            } else {
                resultado = num1_aux + resultado;
            }
            continue
        }
        
        if (hexADecimal(num1_aux) != -1) {
            num1_aux = hexADecimal(num1_aux);
        }
        if (hexADecimal(num2_aux) != -1) {
            num2_aux = hexADecimal(num2_aux);
        }

        if ((num1_aux*1 + num2_aux*1) >= baseFin) {

            aux = (num1_aux*1 + num2_aux*1);
            let aux2 = (Math.trunc(aux / baseFin));
            let aux3 = (aux % baseFin);

            if ((decimalAHex(aux2) != -1)) {
                aux2 = decimalAHex(aux2);
            }
            if (decimalAHex(aux3) != -1) {
                aux3 = decimalAHex(aux3);
            }
            count = i-1;
            aux = '';
            while (count != 0) {
                aux +='0';
                count -= 1;
            }
            aux = (aux2+'') + (aux3+'') + aux;
            resultado = hexSum(resultado, baseFin, aux);
        
        } else {
            aux = (num1_aux*1) + (num2_aux*1);
            if (decimalAHex(aux) != -1) {
                aux = decimalAHex(aux);
                count = i-1;

                while (count != 0) {
                    aux +='0';
                    count -= 1;
                }
                if (resultado != '') {
                    resultado = hexSum(aux, baseFin, resultado);

                } else {
                    resultado += aux;
                }

            } else {
                resultado = aux+'' + resultado;
            }
        }
    }
    return resultado;
}

function mult(num, baseAux, baseFin) {
    resultado = ''
    numAux = 0;
    for (let i=1; i <= baseAux.length; i++) {

        for (let j=1; j <= num.length; j++) {
            console.log(num[num.length -j ])
            numAux = ((num[num.length - j] * 1) * (baseAux[baseAux.length - i] * 1)) ;
            numAux = (Math.trunc(numAux / baseFin) * 10 **(j)) + (numAux % baseFin* 10 **(j-1));
            while(biggerBase(numAux+'', baseFin)) {
                numAux = changeBase(numAux+'', baseFin);
            }
            resultado = sum(resultado+'', baseFin, numAux+'');
        }
    }
    return resultado;
}

function hexMult(num, baseAux, baseFin) {
    let resultado = '';
    let numAux = 0;
    let aux = '';

    for (let j=1 ; j <= num.length; j++) {

        numAux = num[num.length - j];

        if (hexADecimal(numAux) != -1) {
            numAux = hexADecimal(numAux);
        }

        let aux1 = (numAux * (baseAux* 1));
        let aux2 = Math.trunc(aux1 / baseFin);
        let aux3 = aux1 % baseFin;

        if ((decimalAHex(aux2) != -1)  && baseFin*1 > 10) {
            aux2 = decimalAHex(aux2);
        }
        if (decimalAHex(aux3) != -1  && baseFin*1 > 10) {
            aux3 = decimalAHex(aux3);
        }
        if (aux2 === 0) {
            if (aux2*1 != 0 || aux3*1 != 0) {

                count = j-1;
                while (count > 0) {
                    aux3 = aux3 + '0';
                    count -= 1;
                }
                if (aux2*1 != 0) {
                    aux = hexSum(aux, baseFin, (aux2+'') + (aux3+''));
                } else {
                    aux = hexSum(resultado, baseFin, (aux3+''));
                }
            } else {
                aux = '0';
            }
            
        } else if (((aux2+'') + (aux3+'')).length === aux.length) {

            count = j-1;

            while (count > 0) {
                aux3 = aux3 + '0';
                count -= 1;
            }
            aux = hexSum(aux, baseFin, (aux2+'') + (aux3+''));
        } else {
            aux = '';
            count = ((aux2+'') + (aux3+'')).length -1;
            
            while (count < j) {
                aux += '0';
                count ++;
            }

            aux = (aux2+'') + (aux3+'') + aux;
            resultado = hexSum(aux, baseFin, resultado);
            aux = '0';
        }
        if (aux*1 != 0) {
            resultado = aux;
        }
    }
    return resultado;
}

function convertirBaseMayorAMenor(num, baseNum, baseFin) {
    let aux = '';
    let i = 0;
    if(num.length === 1) {
        if (hexADecimal(num) != -1) {
            num = hexADecimal(num);
        }
        let aux = (Math.trunc(num / baseFin) * 10) + (num % baseFin* 1);
        if(biggerBase(aux+'', baseFin)) {
            aux = changeBase(aux+'', baseFin);
        }
        return aux + '_' + baseFin;
    }

    if (baseNum*1 === 10) {
        return base10ABaseN(num*1, baseFin*1);
    }

    while (i < num.length-1) {
        if (i === 0) {
            aux = num[i];
        }
        if (baseNum*1 > 10) {
            if (hexADecimal(aux) != -1 ) {
                aux = hexADecimal(aux);
                aux = hexMult(aux+'', baseNum+'', baseFin*1);
            }else {
                aux = hexMult(aux+'', baseNum+'', baseFin*1);
            }
        } else {
            aux = mult(aux+'', baseNum+'', baseFin*1);
        }
        if ((i+1) < num.length) {
            if(baseNum*1 > 10) {
                if (hexADecimal(num[i+1]) != -1) {
                    digit = hexADecimal(num[i+1]);
                    
                    if ((num[i+1]*1) + digit >= baseFin) {
                        aux = hexSum(aux+'', baseFin*1, num[i+1]);
                    } else {
                        aux = hexSum(aux, baseFin, num[i+1]);
                    }
                } else {
                    x = Math.trunc(num[i+1]/baseFin);
                    aux = hexSum(aux, baseFin, num[i+1]);
                }
            } else {
                console.log(num[i+1])
                aux = sum(aux+'', baseFin*1, num[i+1]);
            }
        }
        i += 1;
    }
    while (biggerBase(aux+'', baseFin)) {
        aux = changeBase(aux+'', baseFin);
    }
    return aux + '_' + baseFin;
}


function convertirBase(num, baseNum, baseFin) {
    let aux = '';
    let i = 0;
    let baseAux = baseNum;

    if(baseFin*1 < baseNum*1) {
        return convertirBaseMayorAMenor(num,baseNum, baseFin);
    }
    while (biggerBase(baseAux+'', baseFin)) {
        baseAux = changeBase(baseAux, baseFin);
    }

    while (i < num.length - 1) {
        if (i === 0) {
            aux = num[i];
        }
        if (num[i] * 1 >= baseFin) {
            aux = changeBase(aux, baseFin);
        }
        if (baseFin > 10) {
            aux = hexMult(aux+'', baseAux+'', baseFin*1);
            
        } else {
            aux = mult(aux+'', baseAux+'', baseFin*1);
        }
        if ((i+1) < num.length) {
            if (baseFin > 10) {
                digit = (aux+'')[(aux+'').length- 1];
                if (hexADecimal(digit) != -1) { digit = hexADecimal(digit); }

                
                if ((num[i+1]*1) + digit >= baseFin) {
                    aux = hexSum(aux+'', baseFin*1, num[i+1]);
                } else {
                    aux = hexSum(aux, baseFin, num[i+1]);
                }
            } else {
                aux = sum(aux+'', baseFin*1, num[i+1]);
            }
        }
        i += 1;
    }
    return aux + '_' + baseFin;
}

