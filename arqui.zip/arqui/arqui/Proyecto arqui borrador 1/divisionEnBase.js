//Código de Heldyis Agüero Espinoza

/**
 * Función: compararBase
 * Compara dos números en una base dada.
 * @param {string} num1 - El primer número a comparar.
 * @param {string} num2 - El segundo número a comparar.
 * @param {number} base - La base en la que se están comparando los números.
 * @returns {number} - 0 si los números son iguales, -1 si el primer número es menor, 1 si el segundo número es menor.
 */

function compararBase(num1, num2, base) {
    num1 = num1.toUpperCase();
    num2 = num2.toUpperCase();

    if (num1.length < num2.length) return -1;
    if (num1.length > num2.length) return 1;

    for (let i = 0; i < num1.length; i++) {
        if (num1[i] !== num2[i]) {
            return num1[i] < num2[i] ? -1 : 1;
        }
    }
    return 0;
}

/**
 * Función: sumaEnBase
 * Realiza la suma de dos números en una base dada.
 * @param {string} num1 - El primer número a sumar.
 * @param {string} num2 - El segundo número a sumar.
 * @param {number} base - La base en la que se están sumando los números.
 * @returns {string} - El resultado de la suma en la misma base.
 */

function sumaEnBase(num1, num2, base) {
    const digitos = '0123456789ABCDEF';
    let carry = 0;
    let result = '';

    num1 = num1.padStart(num2.length, '0');
    num2 = num2.padStart(num1.length, '0');

    for (let i = num1.length - 1; i >= 0; i--) {
        const sum = digitos.indexOf(num1[i].toUpperCase()) + digitos.indexOf(num2[i].toUpperCase()) + carry;
        carry = sum >= base ? 1 : 0;
        result = digitos[sum % base] + result;
    }

    if (carry > 0) {
        result = '1' + result;
    }
    return result;
}

/**
 * Función: restaEnBase
 * Realiza la resta de dos números en una base dada.
 * @param {string} num1 - El número del cual se resta el segundo número.
 * @param {string} num2 - El número que se resta del primer número.
 * @param {number} base - La base en la que se están restando los números.
 * @returns {string} - El resultado de la resta en la misma base.
 */

function restaEnBase(num1, num2, base) {
    const digitos = '0123456789ABCDEF';
    let borrow = 0;
    let result = '';

    num1 = num1.padStart(num2.length, '0');
    num2 = num2.padStart(num1.length, '0');

    for (let i = num1.length - 1; i >= 0; i--) {
        let diff = digitos.indexOf(num1[i].toUpperCase()) - digitos.indexOf(num2[i].toUpperCase()) - borrow;
        if (diff < 0) {
            diff += base;
            borrow = 1;
        } else {
            borrow = 0;
        }
        result = digitos[diff] + result;
    }
    return result.replace(/^0+(?=\d)/, '') || '0';
}

/**
 * Función: separarNumero
 * Separa un número junto con su base a partir del guion bajo.
 * @param {string} numero_base - El número junto con su base en el formato "numero_base".
 * @returns {Array} - Un array que contiene el número y su base por separado.
 */

function separarNumero (numero_base) {
    //Separamos las partes a partir del guion bajo
    let partes = numero_base.split('_');
    return [partes[0],partes[1]];
}

/**
 * Función: div2To10
 * Realiza la división de dos números en la misma base sin usar bases intermedias ni parseInt.
 * @param {string} numeroDividendo - El número que será dividido.
 * @param {string} numeroDivisor - El número por el cual se dividirá el dividendo.
 * @returns {string|NaN} - El resultado de la división en la misma base o NaN si hay un error.
 */

function div2To10(numeroDividendo, numeroDivisor) {
    // Separar el dividendo y el divisor en número y base
    let [dividendo_valor, baseString] = separarNumero(numeroDividendo);
    let [divisor_valor, divisor_base] = separarNumero(numeroDivisor);

    // Verificar que ambos números tengan la misma base
    if (baseString !== divisor_base) {
        return NaN;
    }

    base = baseString * 1;

    // Verificar si el divisor es cero
    if (divisor_valor === '0') {
        return NaN;
    }

    let dividendo = dividendo_valor;
    let divisor = divisor_valor;

    // Inicializar el resultado de la división
    let resultado = '';

    // Convertir los números a arrays de dígitos
    const dividendoArray = dividendo.split('');
    const divisorArray = divisor.split('');

    let cocienteParcial = '';

    const digitosValidos = '0123456789ABCDEF'.slice(0, base);

    // Validar cada dígito del dividendo
    for (let i = 0; i < dividendoArray.length; i++) {
        if (!digitosValidos.includes(dividendoArray[i])) {
            return NaN;
        }
    }

    // Validar cada dígito del divisor
    for (let i = 0; i < divisorArray.length; i++) {
        if (!digitosValidos.includes(divisorArray[i])) {
            return NaN;
        }
    }

    // Iterar sobre cada dígito del dividendo
    for (let i = 0; i < dividendoArray.length; i++) {
        
        cocienteParcial += dividendoArray[i];

        let division = '';
        let divisorTemp = divisor;

        // Realizar la división en la base adecuada
        while (compararBase(cocienteParcial, divisorTemp, base) >= 0) {
            cocienteParcial = restaEnBase(cocienteParcial, divisorTemp, base);
            division = sumaEnBase(division, '1', base);
        }

        resultado += division === '' ? '0' : division; // Agregar el dígito al resultado
    }

    // Eliminar ceros a la izquierda del resultado
    if (resultado !== '0') {
        resultado = resultado.replace(/^0+/, '');
    }
    
    // Concatenar la base al resultado final
    resultado += '_' + baseString;
    return resultado;
}

/**
 * Función: div11To16
 * Realiza la división de dos números en la misma base del 11 al 16, sin usar bases intermedias ni parseInt.
 * @param {string} numeroDividendo - El número que será dividido.
 * @param {string} numeroDivisor - El número por el cual se dividirá el dividendo.
 * @returns {string|NaN} - El resultado de la división en la misma base o NaN si hay un error.
 */

function div11To16(numeroDividendo, numeroDivisor) {
    let [numero, baseString] = separarNumero(numeroDividendo);
    let [divisor, divisor_base] = separarNumero(numeroDivisor);

    if (baseString !== divisor_base) {
        return "Error: Los números tienen bases diferentes.";
    }

    base = baseString * 1;

    // Verificar que los números de entrada sean válidos
    if (typeof numero !== 'string' || typeof divisor !== 'string' || numero.length === 0 || divisor.length === 0 || base < 2 || base > 16) {
        return "Entrada inválida";
    }

    // Mapa de referencia para los dígitos hexadecimales
    const hexMap = {
        '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
        'A': 10, 'B': 11, 'C': 12, 'D': 13, 'E': 14, 'F': 15
    };

    // Función para realizar la división directamente en la base original
    const realizarDivision = (numero, divisor) => {
        let cociente = '';
        let resto = 0;
        let cocienteNoCero = false;

        for (let i = 0; i < numero.length; i++) {
            const valorNumero = hexMap[numero[i].toUpperCase()];
            const valorDivisor = hexMap[divisor.toUpperCase()];
            if (isNaN(valorNumero) || isNaN(valorDivisor) || valorNumero >= base || valorDivisor >= base) {
                return NaN; // Si algún dígito no es válido para la base, retornar NaN
            }

            const dividendo = resto * base + valorNumero;
            const division = Math.floor(dividendo / valorDivisor);
            resto = dividendo % valorDivisor;

            if (division !== 0) {
                cocienteNoCero = true;
            }

            if (cocienteNoCero || division !== 0 || i === numero.length - 1) {
                cociente += Object.keys(hexMap).find(key => hexMap[key] === division);
            }
        }
        // Concatenar la base al resultado final
        cociente += '_' + baseString;

        return cociente;
    };

    // Realizar la división directamente en la base original
    return realizarDivision(numero, divisor);
}



// Ejemplo de uso
console.log(div2To10('1010_2', '101_2')); // Base 2
console.log(div2To10('102_3', '11_3')); // Base 3
console.log(div2To10('313_4', '2_4')); // Base 4
console.log(div2To10('314_5', '31_5')); // Base 5
console.log(div2To10('405_6', '34_6')); // Base 6
console.log(div2To10('506_7', '45_7')); // Base 7
console.log(div2To10('607_8', '46_8')); // Base 8
console.log(div2To10('708_9', '51_9')); // Base 9
console.log(div2To10('2_10', '10_10')); // Base 10
console.log(div11To16('A_12', '2_12')); 
console.log(div11To16('2_11', 'a_11')); 
console.log(div11To16('AAAAA_16', 'C_16')); 

// Verificación de division por cero y bases desiguales.
console.log(div2To10('1010_2', '0_2')); // Error: No se puede dividir por cero.
console.log(div2To10('1010_2', '101_4')); //Error: Los números tienen bases diferentes