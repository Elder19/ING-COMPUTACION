use Basept1
go 

SELECT [profecionalcedula],[Correo],[Numero],[Nombre],[Apaterno],[Amaterno],[Profesion] from [PersonalMedico]



SELECT [Nombre],[Apaterno],[Amaterno],[Sexo],[correo],[Grupo_sanguineo],[cedula] from [Paciente]



SELECT [cedulapaciente],[Motivo],[Fecha_hora],[Resultado],[profecionalcedula] from [Cita]

SELECT * FROM Tratamiento;


SELECT * FROM Padecimiento;


SELECT * FROM Afectacion;


SELECT * FROM ResultadoCita;


SELECT * FROM Medicamento;


SELECT * FROM Medicamentocita;


SELECT * FROM EfectoSecundario;


SELECT * FROM Procedimiento;


SELECT * FROM MedicamentoProcedimiento;
