using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PRY_3.Pages
{
    public class Products : PageModel
    {
        public void OnGet()
        {
        }
    }
}
