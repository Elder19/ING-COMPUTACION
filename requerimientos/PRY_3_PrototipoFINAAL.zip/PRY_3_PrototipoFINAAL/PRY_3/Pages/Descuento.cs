using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PRY_3.Pages
{
    public class Descuento : PageModel
    {
        public void OnGet()
        {
        }
    }
}
