using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PRY_3.Pages
{
    public class Lotes : PageModel
    {
        public void OnGet()
        {
        }
    }
}
