[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/t6f4PyC8)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=11316753&assignment_repo_type=AssignmentRepo)
# [Proyecto Programado #3 Sistema de ventas]
### Carné y Nombre por integrante
carné 2023166120 Elder León Pérez 
carne 2023105915 Brasly Villarebia Morales
### Estado del proyecto: [Superior **]
### Enlace del video: https://youtu.be/POygrxzv7Qg
Recordar que el video debe ser público para ser visto por el profesor
