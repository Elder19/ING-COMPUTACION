from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import tkinter as tk

from modelo import *
from tkinter import ttk

color = "goldenrod1"
ordeFcrtura=3
factura=2

salida = "Red"
#===================================================================================================================
"""
Nombre:ingreso
Entrada:usuario, password
Salida: permite el acceso
Restricciones: ninguna
"""
def ingreso(usuario, password):
    acceso = False
    with open("Acceso.txt") as archi:
        for indice in archi.readlines():
            if usuario == indice.split(";")[0] and password == indice.split(";")[1].rstrip("\n"):
                acceso = True
        if not acceso:
            messagebox.showerror("ERROR", message="El usuario o la contraseña estan incorrectas")
        else:
            menuPrin()
#==========================================================================================
"""
Nombre:seAnuloLaFacrura
Entrada:codigo
Salida: anula la factura
Restricciones: ninguna
"""
def seAnuloLaFacrura(codigo):
    if codigo=="":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    codigo=int(codigo)
    inicio.anularfactura(codigo)
#===================================================================================================================
"""
Nombre:TodasCategorias
Entrada:ninguna
Salida: una lista con todos los nombres de las acategoria
Restricciones: ninguna
"""
def TodasCategorias():
    lista=[]
    for categoria in inicio.listacategoria:
        lista+=[categoria.categoria]

    return lista
#===================================================================================================================
"""
Nombre:seAgregaCarrito
Entrada:cliente,producto,cantidad
Salida: ninguna
Restricciones:
    los parametros no deben de estar vacion y la cantidad debe ser mayor a o
"""
def seAgregaCarrito(cliente,producto,cantidad):
    if producto=="":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    if cantidad=="":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    cantidad=int(cantidad)
    if cantidad<=0:
        return messagebox.showerror(title="Error",message="la cantidad debe ser mayor a 0")
    
    for cli in inicio.listacliente:
        if cliente==cli.nombre:
            cliente=cli.codigoCL
            cliente=int(cliente)
            break
    inicio.facturar(cliente,producto,cantidad)
    return messagebox.showinfo(title="Aviso", message="Se agrego compra")

#===================================================================================================================
"""
Nombre:LosProductos
Entrada:ninguna
Salida: una lista con todos los nombres de los productos
Restricciones: ninguna
"""
def LosProductos():
    lista=[]
    for productos in inicio.listaproductos:
        lista+=[productos.nombre]
    return lista
    
#===================================================================================================================
"""
Nombre:Agreegar
Entrada: proveedor,producto,cantidad,precio
Salida: Agrega productos a una compra
Restricciones: 
    ningun parametro debe de estar vacio
"""
def Agreegar(proveedor,producto,cantidad,precio):
    if proveedor == "":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    if producto == "":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    if cantidad == "":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    if precio == "":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    for proveedores in inicio.listaprovedor:
        if proveedor == proveedores.nombre:
            proveedor = proveedores.codigoPV
    cantidad=int(cantidad)
    precio=int(precio)
    proveedor=int(proveedor)
    inicio.Ordenesdecompra(proveedor,precio,cantidad,producto)
    return messagebox.showinfo(title="Aviso", message="Se agrego compra")

#===================================================================================================================
"""
Nombre:TodosLosProveedores
Entrada:ninguna
Salida: una lista con todos los nombres de los proveedores
Restricciones: ninguna
"""
def TodosLosProveedores():
    lista=[]
    for proveedores in inicio.listaprovedor:
        lista+=[proveedores.nombre]
    return lista
#===================================================================================================================
"""
Nombre:TodosLosClientes
Entrada:ninguna
Salida: una lista con todos los nombres de los clientes
Restricciones: ninguna
"""
def TodosLosClientes():
    lista=[]
    for clientes in inicio.listacliente:
        lista+=[clientes.nombre]
    return lista
#===================================================================================================================
"""
Nombre:Todaslasordenesdecompra
Entrada:ninguna
Salida: una lista con los codigos de las ordenes de compra
Restricciones: ninguna
"""
def Todaslasordenesdecompra():
    lista=[]
    for orden in inicio.listaorden:
        lista+=[orden.codigo]
    return lista
#===================================================================================================================
"""
Nombre:Todaslasordenesdecompra
Entrada:ninguna
Salida: una lista con los codigos de las facturas
Restricciones: ninguna
"""
def TodaslasFacturas():
    lista=[]
    for fac in inicio.facturacion:
        lista+=[fac.codigoFC]
    return lista
#===================================================================================================================
"""
Nombre:Anularcompra
Entrada:codigo
Salida: anula ordenes de compra
Restricciones: los parametros no deben de estra vacio
"""
def Anularcompra(codigo):
    if codigo=="":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    else:
        inicio.anularorden(codigo)
#===================================================================================================================
"""
Nombre:SeMODIFICAProducto
Entrada:selector,nombre,categoria,proveedor,precio
Salida: modifica productos
Restricciones: los parametros no deben de estra vacio
"""
def SeMODIFICAProducto(selector,nombre,categoria,proveedor,precio):
    for proveedores in inicio.listaprovedor:
        if proveedor == proveedores.nombre:
            proveedor = proveedores.codigoPV

    for categorisa in inicio.listacategoria:
        if categoria == categorisa.categoria:
            categoria= categorisa.codigocat

    inicio.modificarproducto(selector,nombre,proveedor,categoria,precio)
    return menuPrin()
#===================================================================================================================
"""
Nombre:MostrarProductos
Entrada:Frame
Salida: muestra todos los productos
Restricciones: los parametros no deben de estra vacio
"""
def MostrarProductos(Freme):
    pro=""
    cat=""
    todasLasCategorias = Listbox(Freme,  width=80, height=15)
    todasLasCategorias.place(x=250, y=147)
    todasLasCategorias.config(bd=0)
    for productos in inicio.listaproductos:
        for proveedores in inicio.listaprovedor:
            if productos.codigoPV==proveedores.codigoPV:
                pro=proveedores.nombre
        todasLasCategorias.insert("end",productos.codigoPD+"                              "+ productos.nombrecat +"             "+pro+"                 "+productos.nombre+"                "+str(productos.cantidad)+"                            "+str(productos.precio))
#===================================================================================================================
"""
Nombre:SeAgregProducto
Entrada:nombre,categoria,proveedor,precio
Salida: se agregan productos
Restricciones: los parametros no deben de estra vacio
"""
def SeAgregProducto(nombre,categoria,proveedor,precio):
    for proveedores in inicio.listaprovedor:
        if proveedor == proveedores.nombre:
            proveedor = proveedores.codigoPV

    for categorisa in inicio.listacategoria:
        if categoria == categorisa.categoria:
            categoria= categorisa.codigocat

    inicio.crearProducto(nombre,proveedor,categoria,precio)
#===================================================================================================================
"""
Nombre:verificador
Entrada:cat,opcion
Salida: muestra el producto
Restricciones: los parametros no deben de estra vacio
"""
def verificador(cat,opcion):
    verificador=0

    try:
        valor=int(opcion)
        verificador=1
    except:
        verificador=0
    
    if verificador==0:
        x=len(opcion)
        for productos in inicio.listaproductos:
            if opcion == productos.nombre[0:x]:
                if cat == productos.nombrecat:
                    
                    return Decidir(productos.codigoPD,productos.nombrecat,productos.codigoPV,productos.nombre,productos.cantidad,productos.precio)
                else:
                    return messagebox.showerror( message= "ERROR:  No coincide la categoria")
                
        return messagebox.showerror( message= "ERROR:  No existe este producto")
    else:
    
        for productos in inicio.listaproductos:
            if opcion == productos.codigoPD:

                if cat == productos.nombrecat:
                    return Decidir(productos.codigoPD,productos.nombrecat,productos.codigoPV,productos.nombre,productos.cantidad,productos.precio)
                else:
                    return messagebox.showerror( message= "ERROR:  No coincide la categoria")
                

        return messagebox.showerror( message= "ERROR:  No existe este producto")
#===================================================================================================================
"""
Nombre:MostrarCategoria
Entrada:Freme
Salida: muestra las catedorias
Restricciones: los parametros no deben de estra vacio
"""
def MostrarCategoria(Freme):
    todasLasCategorias = Listbox(Freme,  width=50, height=10)
    todasLasCategorias.place(x=600, y=150)
    for categoria in inicio.listacategoria:
        todasLasCategorias.insert("end","Codigo:  " + str(categoria.codigocat )+ "      " + "categoria: " + categoria.categoria  )
#===================================================================================================================
"""
Nombre:MostrarCategoria2
Entrada:Freme
Salida: muestra las catedorias
Restricciones: los parametros no deben de estra vacio
"""
def MostrarCategoria2(Freme):
    todasLasCategorias = Listbox(Freme,  width=40, height=10)
    todasLasCategorias.place(x=375, y=125)
    todasLasCategorias.config(bd=0)
    for categoria in inicio.listacategoria:
        todasLasCategorias.insert("end","Codigo:  " + str(categoria.codigocat) + "  " +"categoria: " + str(categoria.categoria))
#===================================================================================================================
"""
Nombre:MostrarLosClientes
Entrada:Freme
Salida: muestra los clientes
Restricciones: los parametros no deben de estra vacio
"""
def MostrarLosClientes(Freme):
    todasLasCategorias = Listbox(Freme,  width=150, height=7)
    todasLasCategorias.place(x=50, y=200)
    todasLasCategorias.config(bd=0)
    for clientes in inicio.listacliente:
        todasLasCategorias.insert("end","        "+str(clientes.codigoCL) + "                                                                  " + str(clientes.nombre)+" "+str(clientes.apellidos)+" "+str(clientes.apellido2)+ "                                                                   " +str(clientes.provicia)+ "                          " +str(clientes.telefono)+ "                              " + str(clientes.correo))

#===================================================================================================================
"""
Nombre:MostrarLosProveedoes
Entrada:Freme
Salida: muestra los proveedores
Restricciones: los parametros no deben de estra vacio
"""
def MostrarLosProveedoes(Freme):
    todasLasCategorias = Listbox(Freme,  width=120, height=7)
    todasLasCategorias.place(x=150, y=200)
    todasLasCategorias.config(bd=0)
    for proveedores in inicio.listaprovedor:
        todasLasCategorias.insert("end","          "+proveedores.codigoPV+"                                                                           "+proveedores.nombre+"                                                   "+proveedores.telefono+"                                               "+proveedores.correo)

#===================================================================================================================
"""
Interfas
Nombre:menuCrearCategoria
Entrada:ninguna
Salida: un menu de crear Categoria
Restricciones: los parametros no deben de estra vacio
"""
def menuCrearCategoria():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =crearCategoria)
    label.pack()


    txt = Label(cuadro, text="Nombre de la categoria:", font=("Times New Roman", 13), bd=0)
    txt.place(x=175, y=200)
    txt.config(bg=color)

    nombreCategoria = StringVar()
    nombrecategoria= Entry(cuadro, textvariable=nombreCategoria, font=("Times New Roman", 13),relief="raised")
    nombrecategoria.place(x=350, y=200)
    

    crear = Button(cuadro, text="Crear Categoria",command=lambda:inicio.crearcat(nombreCategoria.get()),font=("Times New Roman", 13), relief="raised")
    crear.place(x=380, y=250)
    crear.config(bg=color)
    

    mostrar = Button(cuadro, text="Mostrar lista",command=lambda: MostrarCategoria(cuadro), font=("Times New Roman", 13),relief="raised")
    mostrar.place(x=175, y=300)
    mostrar.config(bg=color)
    

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:modificarCategoriaMenu
Entrada:ninguna
Salida: un menu de modificar Categoria
Restricciones: los parametros no deben de estra vacio
"""
def modificarCategoriaMenu():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =plantillaModificar)
    label.pack()

    cambiarCategoria = StringVar()
    cambiarcategoria= Entry(cuadro, textvariable=cambiarCategoria, font=("Times New Roman", 15),relief="raised")
    cambiarcategoria.place(x=180, y=235)

    nuevoNombre = StringVar()
    nuevonombre= Entry(cuadro, textvariable=nuevoNombre, font=("Times New Roman", 15),relief="raised")
    nuevonombre.place(x=180, y=325)

    crear = Button(cuadro, text="Modificar Categoria",command=lambda:inicio.modificarcat(cambiarCategoria.get(),nuevoNombre.get()),font=("Times New Roman", 13), relief="raised")
    crear.place(x=200, y=400)
    crear.config(bg=color)



    mostrar = Button(cuadro, text="Mostrar lista",command=lambda: MostrarCategoria(cuadro),font=("Times New Roman", 13),relief="raised")
    mostrar.place(x=450, y=400)
    mostrar.config(bg=color)


    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:BorrarCategoriaMenu
Entrada:ninguna
Salida: un menu de borrar Categoria
Restricciones: los parametros no deben de estra vacio
"""
def BorrarCategoriaMenu():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    
    label = tk.Label(cuadro, image =BorrarCategoria)
    label.pack()

    BorrarCategoriaTXT = StringVar()
    borrarCategoria= Entry(cuadro, textvariable=BorrarCategoriaTXT, font=("Times New Roman", 15),relief="raised")
    borrarCategoria.place(x=180, y=235)

    borrar = Button(cuadro, image=BotonBorrar,command=lambda:inicio.borrarcat(BorrarCategoriaTXT.get()),relief="raised",bd=0)
    borrar.place(x=225, y=300)
    borrar.config(bg=color)

    mostrar = Button(cuadro, text="Mostrar lista",command=lambda: MostrarCategoria(cuadro),font=("Times New Roman", 13),relief="raised")
    mostrar.place(x=450, y=400)
    mostrar.config(bg=color)

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)
    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:enseñarCategoria
Entrada:ninguna
Salida: enseña la categorias
Restricciones: los parametros no deben de estra vacio
"""
def enseñarCategoria():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)

    label = tk.Label(cuadro, image =enseñamenuCategoria)
    label.pack()

    enseña = Button(cuadro, text="Revelar", command=lambda:MostrarCategoria2(cuadro),font=("Times New Roman", 13),relief="raised")
    enseña.place( x=475,y=330)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)

#===================================================================================================================
#menu de categoria

"""
Interfas
Nombre:Categorias
Entrada:ninguna
Salida: menu de categorias
Restricciones: los parametros no deben de estra vacio
"""
def Categorias():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =categoria)
    label.pack()

    crearC = Button(cuadro, text="Crear Categoria",command=lambda:menuCrearCategoria(), font=("Times New Roman", 13),relief="raised")
    crearC.place(x=500, y=200)
    crearC.config(bg=color)

    modificarC = Button(cuadro, text="Modificadar Categoria", command=lambda:modificarCategoriaMenu(),font=("Times New Roman", 13),relief="raised")
    modificarC.place(x=475, y=250)
    modificarC.config(bg=color)
    
    borrarC = Button(cuadro, text="Borrar Categoria", command=lambda:BorrarCategoriaMenu(),font=("Times New Roman", 13),relief="raised")
    borrarC.place(x=500, y=300)
    borrarC.config(bg=color)

    listarC = Button(cuadro, text="Listar Categorias", command=lambda:enseñarCategoria(),font=("Times New Roman", 13),relief="raised")
    listarC.place( x=500,y=350)
    listarC.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500) 

#===================================================================================================================
"""
Interfas
Nombre:AgregarCliente
Entrada:ninguna
Salida: se agrega cliente 
Restricciones: los parametros no deben de estra vacio
"""
def AgregarCliente():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =RegistrarCLiente)
    label.pack()

    Nombre = StringVar()
    nombre = Entry(cuadro, textvariable=Nombre, font=("Times New Roman", 13))
    nombre.place(x=390, y=140,width=125, height=20)

    Apellido1 = StringVar()
    apellido1 = Entry(cuadro, textvariable=Apellido1, font=("Times New Roman", 13))
    apellido1.place(x=610, y=140,width=125, height=20)

    Apellido2 = StringVar()
    apellido2 = Entry(cuadro, textvariable=Apellido2, font=("Times New Roman", 13))
    apellido2.place(x=830, y=140,width=125, height=20)

    Cedula = IntVar()
    cedula = Entry(cuadro, textvariable=Cedula, font=("Times New Roman", 13))
    cedula.place(x=390, y=210,width=125, height=20)

    Correo = StringVar()
    correo = Entry(cuadro, textvariable=Correo, font=("Times New Roman", 13))
    correo.place(x=390, y=280,width=175, height=20)

    Telefono = IntVar()
    telefono = Entry(cuadro, textvariable=Telefono, font=("Times New Roman", 13))
    telefono.place(x=700, y=280,width=150, height=20)

    Provincia  = StringVar()
    provincia = Entry(cuadro, textvariable=Provincia, font=("Times New Roman", 13))
    provincia.place(x=410, y=350,width=125, height=20)

    CrearUsuario = Button(cuadro, text="Registrar",command=lambda:inicio.crearcliente(Nombre.get(),Apellido1.get(),Apellido2.get(),Telefono.get(),Cedula.get(),Provincia.get(),Correo.get()),font=("Times New Roman", 13),relief="raised")
    CrearUsuario.place( x=600,y=340)
    CrearUsuario.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500) 
#===================================================================================================================
"""
Interfas
Nombre:modificarClienteMenu
Entrada:ninguna
Salida: menu de modificar cliente 
Restricciones: los parametros no deben de estra vacio
"""
def modificarClienteMenu():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    
    label = tk.Label(cuadro, image =ModificarCLiente)
    label.pack()
    
    txt = Label(cuadro, text="Codigo, Cedula o completo o parte del nombre a modificar:", font=("Times New Roman", 15), bd=0)
    txt.place(x=75, y=125)
    txt.config(bg=color)
    

    PorModificar = StringVar()
    porModificar = Entry(cuadro, textvariable=PorModificar, font=("Times New Roman", 13))
    porModificar.place(x=550, y=125,width=125, height=20)


    Nombre = StringVar()
    nombre = Entry(cuadro, textvariable=Nombre, font=("Times New Roman", 13))
    nombre.place(x=390, y=160,width=125, height=20)

    Apellido1 = StringVar()
    apellido1 = Entry(cuadro, textvariable=Apellido1, font=("Times New Roman", 13))
    apellido1.place(x=610, y=160,width=125, height=20)

    Apellido2 = StringVar()
    apellido2 = Entry(cuadro, textvariable=Apellido2, font=("Times New Roman", 13))
    apellido2.place(x=830, y=160,width=125, height=20)

    Cedula = IntVar()
    cedula = Entry(cuadro, textvariable=Cedula, font=("Times New Roman", 13))
    cedula.place(x=390, y=230,width=125, height=20)

    Correo = StringVar()
    correo = Entry(cuadro, textvariable=Correo, font=("Times New Roman", 13))
    correo.place(x=390, y=300,width=175, height=20)

    Telefono = StringVar()
    telefono = Entry(cuadro, textvariable=Telefono, font=("Times New Roman", 13))
    telefono.place(x=700, y=300,width=150, height=20)

    Provincia  = StringVar()
    provincia = Entry(cuadro, textvariable=Provincia, font=("Times New Roman", 13))
    provincia.place(x=410, y=370,width=125, height=20)

    CrearUsuario = Button(cuadro, text="Registrar",command=lambda:inicio.modificarcliente(PorModificar.get(),Nombre.get(),Apellido1.get(),Apellido2.get(),Telefono.get(),Cedula.get(),Provincia.get(),Correo.get()),font=("Times New Roman", 13),relief="raised")
    CrearUsuario.place( x=600,y=370)
    CrearUsuario.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500) 

#===================================================================================================================
"""
Interfas
Nombre:deleteCliente
Entrada:ninguna
Salida: elimina cliente
Restricciones: los parametros no deben de estra vacio
"""
def deleteCliente():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =BorrarCliente)
    label.pack()

    PorBorrar = StringVar()
    porBorrar = Entry(cuadro, textvariable=PorBorrar, font=("Times New Roman", 13))
    porBorrar.place(x=430, y=200,width=125, height=20)

    CrearUsuario = Button(cuadro, image=BotonBorrar,command=lambda:inicio.borrarcliente(PorBorrar.get()),text="Registrar",font=("Times New Roman", 13),relief="raised")
    CrearUsuario.place(x=440, y=250)
    CrearUsuario.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500) 
#===================================================================================================================
"""
Interfas
Nombre:enseñarCliente
Entrada:ninguna
Salida: muestra clientes
Restricciones: los parametros no deben de estra vacio
"""
def enseñarCliente():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)

    label = tk.Label(cuadro, image =MostrarCliente)
    label.pack()

    enseña = Button(cuadro, text="Revelar", command=lambda:MostrarLosClientes(cuadro),font=("Times New Roman", 13),relief="raised")
    enseña.place( x=475,y=400)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)
    
    cuadro.config(width=1000, height=500)


#===================================================================================================================
#menu de cliente
"""
Interfas
Nombre:MenuCliente
Entrada:ninguna
Salida: muestra un menu de clientes
Restricciones: los parametros no deben de estra vacio
"""
def MenuCliente():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =MenuDeCLiente)
    label.pack()
    crearCliente = Button(cuadro, text="Crear Cliente",command=lambda:AgregarCliente(), font=("Times New Roman", 13),relief="raised")
    crearCliente.place(x=465, y=160)
    crearCliente.config(bg=color)

    modificarCliente = Button(cuadro, text="Modificadar Cliente",command=lambda:modificarClienteMenu(),font=("Times New Roman", 13),relief="raised")
    modificarCliente.place(x=440, y=215)
    modificarCliente.config(bg=color)

    borrarCliente = Button(cuadro, text="Borrar Cliente",command=lambda:deleteCliente(),font=("Times New Roman", 13),relief="raised")
    borrarCliente.place(x=460, y=265)
    borrarCliente.config(bg=color)

    listaCliente = Button(cuadro, text="Lista Cliente",command=lambda:enseñarCliente(),font=("Times New Roman", 13),relief="raised")
    listaCliente.place( x=465,y=320)
    listaCliente.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)
    
    cuadro.config(width=1000, height=500)

#===================================================================================================================

"""
Interfas
Nombre:RegistrarProveedor
Entrada:ninguna
Salida: registra proveedor
Restricciones: los parametros no deben de estra vacio
"""
def RegistrarProveedor():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)

    label = tk.Label(cuadro, image =AgregarProveedor)
    label.pack()

    SeAgrega = StringVar()
    seAgrega = Entry(cuadro, textvariable=SeAgrega, font=("Times New Roman", 13))
    seAgrega.place(x=450, y=200,width=125, height=20)

    SeCedula = StringVar()
    seCedula = Entry(cuadro, textvariable=SeCedula, font=("Times New Roman", 13))
    seCedula.place(x=270, y=252,width=125, height=20)

    SeCorreo = StringVar()
    seCorreo = Entry(cuadro, textvariable=SeCorreo, font=("Times New Roman", 13))
    seCorreo.place(x=270, y=315,width=150, height=20)

    SeTelefono = StringVar()
    seTelefono = Entry(cuadro, textvariable=SeTelefono, font=("Times New Roman", 13))
    seTelefono.place(x=575, y=315,width=150, height=20)

    Crearpro = Button(cuadro,text="Registrar",command=lambda:inicio.crearProvedor(SeCedula.get(),SeAgrega.get(),SeTelefono.get(),SeCorreo.get()),font=("Times New Roman", 13),relief="raised")
    Crearpro.place(x=400, y=400)
    Crearpro.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:seModificaProveedor
Entrada:ninguna
Salida: modifaca  proveedor
Restricciones: los parametros no deben de estra vacio
"""
def seModificaProveedor():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =ModificarProveedor)
    label.pack()

    Verificardor1 = StringVar()
    verificardor1 = Entry(cuadro, textvariable=Verificardor1, font=("Times New Roman", 13))
    verificardor1.place(x=425, y=175,width=150, height=20)

    SeAgrega = StringVar()
    seAgrega = Entry(cuadro, textvariable=SeAgrega, font=("Times New Roman", 13))
    seAgrega.place(x=485, y=235,width=125, height=20)

    SeCedula = StringVar()
    SeCedula = Entry(cuadro, textvariable=SeCedula, font=("Times New Roman", 13))
    SeCedula.place(x=325, y=305,width=125, height=20)

    SeCorreo = StringVar()
    seCorreo = Entry(cuadro, textvariable=SeCorreo, font=("Times New Roman", 13))
    seCorreo.place(x=330, y=370,width=150, height=20)

    SeTelefono = StringVar()
    seTelefono = Entry(cuadro, textvariable=SeTelefono, font=("Times New Roman", 13))
    seTelefono.place(x=625, y=370,width=150, height=20)

    semodifico = Button(cuadro,text="modificar", command=lambda:inicio.modificarprovedor(Verificardor1.get(),SeCedula.get(),SeAgrega.get(),SeTelefono.get(),SeCorreo.get()),font=("Times New Roman", 13),relief="raised")
    semodifico.place(x=400, y=400)
    semodifico.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:seBorraProveedor
Entrada:ninguna
Salida: borra  proveedor
Restricciones: los parametros no deben de estra vacio
"""
def seBorraProveedor():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =BorrarProveedor)
    label.pack()
    PorBorrar = StringVar()

    porBorrar = Entry(cuadro, textvariable=PorBorrar, font=("Times New Roman", 13))
    porBorrar.place(x=430, y=200,width=125, height=20)

    BorraPeoveedor = Button(cuadro, image=BotonBorrar,command=lambda:inicio.eliminarprovedor(PorBorrar.get()),text="Registrar",font=("Times New Roman", 13),relief="raised")
    BorraPeoveedor.place(x=440, y=250)
    BorraPeoveedor.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:enseñarProveedores
Entrada:ninguna
Salida: enseña los proveedores
Restricciones: los parametros no deben de estra vacio
"""
def enseñarProveedores():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =ListaProveedor)
    label.pack()
    enseña = Button(cuadro, text="Revelar", command=lambda:MostrarLosProveedoes(cuadro),font=("Times New Roman", 13),relief="raised")
    enseña.place( x=475,y=400)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)
    cuadro.config(width=1000, height=500)
#===================================================================================================================
#menu de proveedores
"""
Interfas
Nombre:MenuProveedoresprint
Entrada:ninguna
Salida: menu de proveedores
Restricciones: los parametros no deben de estra vacio
"""
def MenuProveedoresprint():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)

    label = tk.Label(cuadro, image =MenuProveedores)

    crearProveedores = Button(cuadro, text="Crear Proveedor",command=lambda:RegistrarProveedor(), font=("Times New Roman", 13),relief="raised")
    crearProveedores.place(x=465, y=160)
    crearProveedores.config(bg=color)

    modificarProveedores = Button(cuadro, text="Modificadar Proveedor",command=lambda:seModificaProveedor(),font=("Times New Roman", 13),relief="raised")
    modificarProveedores.place(x=440, y=215)
    modificarProveedores.config(bg=color)

    borrarProveedores = Button(cuadro, text="Borrar Proveedor",command=lambda:seBorraProveedor(),font=("Times New Roman", 13),relief="raised")
    borrarProveedores.place(x=460, y=265)
    borrarProveedores.config(bg=color)

    listaProveedores = Button(cuadro, text="Lista Proveedor",command=lambda:enseñarProveedores(),font=("Times New Roman", 13),relief="raised")
    listaProveedores.place( x=465,y=320)
    listaProveedores.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)
    
    label.pack()
    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:MostrarLiataProducros
Entrada:ninguna
Salida: enseña la lista de productos
Restricciones: los parametros no deben de estra vacio
"""
def MostrarLiataProducros():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)

    label = tk.Label(cuadro, image =LiataDEProducto)
    label.pack()

    mostrar = Button(cuadro, text="Mostrar lista",command=lambda: MostrarProductos(cuadro), font=("Times New Roman", 13),relief="raised")
    mostrar.place(x=500, y=400)
    mostrar.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)
    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:SeModifico
Entrada:Codigo
Salida:modifica productos
Restricciones: los parametros no deben de estra vacio
"""
def SeModifico(Codigo):
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)

    label = tk.Label(cuadro, image =SeModificaProducto)
    label.pack()

    Nombre = StringVar()
    nombre = Entry(cuadro, textvariable=Nombre, font=("Times New Roman", 13))
    nombre.place(x=350, y=175,width=150, height=20)

    Precio = IntVar()
    precio = Entry(cuadro, textvariable=Precio, font=("Times New Roman", 13))
    precio.place(x=350, y=210,width=125, height=20)

    opciones1 = TodasCategorias()
    comboboxC = ttk.Combobox(cuadro, values=opciones1)
    comboboxC.place(x=375, y=275,width=125, height=20)

    opciones2 = TodosLosProveedores()
    comboboxP = ttk.Combobox(cuadro, values=opciones2)
    comboboxP.place(x=650, y=275,width=125, height=20)

    SeCRea = Button(cuadro, text="Crear", command=lambda:SeMODIFICAProducto(Codigo,Nombre.get(),comboboxC.get(),comboboxP.get(),Precio.get()),font=("Times New Roman", 13),relief="raised")
    SeCRea.place( x=500,y=400)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:Decidir
Entrada:Codigo,categoria,proveedor,nombre,cantidad,precio
Salida: decidir que hacer con el producto
Restricciones: los parametros no deben de estra vacio
"""
def Decidir(Codigo,categoria,proveedor,nombre,cantidad,precio):
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =VerProductoTotal)
    label.pack()

    CodigoL= Label(cuadro,text=Codigo,font=("Times New Roman", 13),bd=0)
    CodigoL.place(x=175, y=125)
    CodigoL.config(bg=color)

    categoriaL= Label(cuadro,text=categoria,font=("Times New Roman", 13),bd=0)
    categoriaL.place(x=235, y=215)
    categoriaL.config(bg=color)

    ProveedorL= Label(cuadro,text=proveedor,font=("Times New Roman", 13),bd=0)
    ProveedorL.place(x=400, y=215)
    ProveedorL.config(bg=color)

    nombreL= Label(cuadro,text=nombre,font=("Times New Roman", 13),bd=0)
    nombreL.place(x=515, y=215)
    nombreL.config(bg=color)

    CantidadL= Label(cuadro,text=str(cantidad),font=("Times New Roman", 13),bd=0)
    CantidadL.place(x=650, y=215)
    CantidadL.config(bg=color)

    PrecioL= Label(cuadro,text=str(precio),font=("Times New Roman", 13),bd=0)
    PrecioL.place(x=775, y=215)
    PrecioL.config(bg=color)

    borrar = Button(cuadro, image=BotonBorrar,command=lambda:inicio.borrarProducto(Codigo),relief="raised",bd=0)
    borrar.place(x=450, y=300)
    borrar.config(bg=color)

    modificarP = Button(cuadro,text="Modificar",command=lambda:SeModifico(Codigo) ,font=("Times New Roman", 13))
    modificarP.place(x=300, y=325)
    modificarP.config(bg=salida)

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:TomarDeciccionProductos
Entrada:ninguno
Salida: busca un producto especifico 
Restricciones: los parametros no deben de estra vacio
"""
def TomarDeciccionProductos():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =ProductoEspecifico)
    label.pack()

                                                                                                    
    opciones1 = TodasCategorias()
    comboboxC = ttk.Combobox(cuadro, values=opciones1)
    comboboxC.place(x=320, y=200,width=125, height=20)

    Nombre = StringVar()
    nombre = Entry(cuadro, textvariable=Nombre, font=("Times New Roman", 13))
    nombre.place(x=650, y=200,width=150, height=20)

    Buscar = Button(cuadro, text="Crear", command=lambda:verificador(comboboxC.get(),Nombre.get()),font=("Times New Roman", 13),relief="raised")
    Buscar.place( x=500,y=400)

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===========================================mos========================================================================
"""
Interfas
Nombre:AgregarNuevoProducto
Entrada:ninguno
Salida: Agrega un producto
Restricciones: los parametros no deben de estra vacio
"""
def AgregarNuevoProducto():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =MenuCrearProductos)
    label.pack()

    Nombre = StringVar()
    nombre = Entry(cuadro, textvariable=Nombre, font=("Times New Roman", 13))
    nombre.place(x=300, y=165,width=150, height=20)

    Precio = IntVar()
    precio = Entry(cuadro, textvariable=Precio, font=("Times New Roman", 13))
    precio.place(x=275, y=220,width=125, height=20)

    opciones1 = TodasCategorias()
    comboboxC = ttk.Combobox(cuadro, values=opciones1)
    comboboxC.place(x=300, y=280,width=125, height=20)

    opciones2 = TodosLosProveedores()
    comboboxP = ttk.Combobox(cuadro, values=opciones2)
    comboboxP.place(x=725, y=280,width=125, height=20)

    SeCRea = Button(cuadro, text="Crear", command=lambda:SeAgregProducto(Nombre.get(),comboboxC.get(),comboboxP.get(),Precio.get()),font=("Times New Roman", 13),relief="raised")
    SeCRea.place( x=500,y=400)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)

#===================================================================================================================
# menu de produtos
"""
Interfas
Nombre:MenuDeProducto
Entrada:ninguno
Salida: menu de productos
Restricciones: los parametros no deben de estra vacio
"""
def MenuDeProducto():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)

    label = tk.Label(cuadro, image =MenudeProducto)
    label.pack()

    AgregraNuevoProducto = Button(cuadro,text="Agregar",command=lambda:AgregarNuevoProducto(),font=("Times New Roman", 13),relief="raised")
    AgregraNuevoProducto.place(x=225, y=225)
    AgregraNuevoProducto.config(bg=color)

    verLosProductos = Button(cuadro,text="Producto",command=lambda:TomarDeciccionProductos(),font=("Times New Roman", 13),relief="raised")
    verLosProductos.place(x=475, y=225)
    verLosProductos.config(bg=color)

    ListaDeProductos  = Button(cuadro,text="Lista de productos",command=lambda:MostrarLiataProducros(),font=("Times New Roman", 13),relief="raised")
    ListaDeProductos.place(x=700, y=225)
    ListaDeProductos.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:VerFacturaCompra
Entrada:ninguno
Salida: enseña facturas de orden de compra
Restricciones: los parametros no deben de estra vacio
"""
def VerFacturaCompra():
    global ordeFcrtura
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =FacturaDeOrdenCompra)
    label.pack()
    inicio.ordenescompraaux()


    Salir= Button(cuadro,image=salir, command=lambda:menuPrin())
    Salir.place(x=40, y=420)
    Salir.config(bg=salida)
    x=ordeFcrtura
    ordeFcrtura+=1
    for elemento in inicio.listaorden:
        if  x == elemento.codigo:
            total=elemento.total
            impuesto=elemento.iva
            subTotal=elemento.subtotal
            nombre=elemento.provedor
            Fecha=elemento.fecha
            fac=elemento.codigo
            lista=elemento.caracteristicas
            break
    todasLasCategorias = Listbox(cuadro,  width=55, height=7,font=("Times New Roman", 14))
    todasLasCategorias.place(x=90, y=220)
    todasLasCategorias.config(bd=0)

    for elementos in lista:
        y=elementos[0]*elementos[1]
        ProductoL=str(elementos[2])
        cantidadL=str(elementos[1])
        precioUnitarioL=str(elementos[0])
        totalL=str(y)
        todasLasCategorias.insert("end",ProductoL+"                    "+cantidadL+"                        "+precioUnitarioL+"                            "+totalL)


    fac= Label(cuadro,text=fac,font=("Times New Roman", 15),bd=0)
    fac.place(x=410, y=45)
    fac.config(bg=color)

    nombre= Label(cuadro,text=nombre,font=("Times New Roman", 15),bd=0)
    nombre.place(x=175, y=95)
    nombre.config(bg=color)

    Fecha= Label(cuadro,text=Fecha,font=("Times New Roman", 15),bd=0)
    Fecha.place(x=160, y=140)
    Fecha.config(bg=color)

    subTotal= Label(cuadro,text=subTotal,font=("Times New Roman", 15),bd=0)
    subTotal.place(x=750, y=350)
    subTotal.config(bg=color)

    impuesto= Label(cuadro,text=impuesto,font=("Times New Roman", 15),bd=0)
    impuesto.place(x=750, y=375)
    impuesto.config(bg=color)

    total= Label(cuadro,text=total,font=("Times New Roman", 15),bd=0)
    total.place(x=750, y=400)
    total.config(bg=color)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:SeAnulaOrden
Entrada:ninguno
Salida: anula orden de compra
Restricciones: los parametros no deben de estra vacio
"""
def SeAnulaOrden():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)   
    label = tk.Label(cuadro, image =Anular)
    label.pack()

    opciones1 = Todaslasordenesdecompra()
    comboboxP = ttk.Combobox(cuadro, values=opciones1)
    comboboxP.place(x=450, y=230,width=125, height=20)


    seanula = Button(cuadro, text="Anular", command=lambda:Anularcompra(comboboxP.get()),font=("Times New Roman", 13),relief="raised")
    seanula.place( x=500,y=400)

    Salir= Button(cuadro,image=salir, command=lambda: menuPrin())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
# Orden de compra
"""
Interfas
Nombre:menuOrdenCompra
Entrada:ninguno
Salida: menu de orden de compra
Restricciones: los parametros no deben de estra vacio
"""
def menuOrdenCompra():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =Menudeordendecompra)
    label.pack()


    opciones1 = TodosLosProveedores()
    comboboxC = ttk.Combobox(cuadro, values=opciones1)
    comboboxC.place(x=260, y=190,width=100, height=20)

    opciones2 = LosProductos()
    comboboxP = ttk.Combobox(cuadro, values=opciones2)
    comboboxP.place(x=500, y=190,width=125, height=20)

    PrecioU = IntVar()
    precioU = Entry(cuadro, textvariable=PrecioU, font=("Times New Roman", 13))
    precioU.place(x=360, y=280,width=100, height=20)

    Cantidad = IntVar()
    cantidad = Entry(cuadro, textvariable=Cantidad, font=("Times New Roman", 13))
    cantidad.place(x=600, y=280,width=125, height=20)

    Facturar = Button(cuadro, text="Facturar",command=lambda:VerFacturaCompra(),font=("Times New Roman", 15),relief="raised")
    Facturar.place( x=250,y=350)
    Facturar.config(bg=color)

    anular = Button(cuadro, text="anular",command=lambda:SeAnulaOrden(),font=("Times New Roman", 15),relief="raised")
    anular.place( x=400,y=350)
    anular.config(bg=color)

    Agrega = Button(cuadro, text="Agrega",command=lambda: Agreegar(comboboxC.get(),comboboxP.get(),Cantidad.get(),PrecioU.get()),font=("Times New Roman", 15),relief="raised")
    Agrega.place( x=525,y=350)
    Agrega.config(bg=color)

    Salir= Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:LaFactura
Entrada:ninguno
Salida: muestra la factuera
Restricciones: los parametros no deben de estra vacio
"""
def LaFactura():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =FacturaDeCompra)
    label.pack()
    inicio.finalizarfactura()
    global factura
    Factura=factura
    factura+=1
    for elementos in inicio.facturacion:
        if Factura ==elementos.codigoFC:
                total=elementos.total
                impuesto=elementos.iva
                subTotal=elementos.subtotal
                nombre=elementos.nombre
                Fecha=elementos.fecha
                fac=elementos.codigoFC
                lista=elementos.caracteristicas
                break
    todasLasCategorias = Listbox(cuadro,  width=55, height=7,font=("Times New Roman", 14))
    todasLasCategorias.place(x=90, y=220)
    todasLasCategorias.config(bd=0)

    for elementos in lista:
        totalU=str(elementos[7])
        Unitario=str(elementos[3])
        cantidad=str(elementos[2])
        for pro in inicio.listaproductos:
            if elementos[1]==pro.codigoPD:
                nombreProducto=pro.nombre
                break
    
        todasLasCategorias.insert("end",nombreProducto+"                      "+cantidad+"                     "+Unitario+"                          "+totalU)
    fac= Label(cuadro,text=fac,font=("Times New Roman", 15),bd=0)
    fac.place(x=300, y=45)
    fac.config(bg=color)

    nombre= Label(cuadro,text=nombre,font=("Times New Roman", 15),bd=0)
    nombre.place(x=175, y=95)
    nombre.config(bg=color)

    Fecha= Label(cuadro,text=Fecha,font=("Times New Roman", 15),bd=0)
    Fecha.place(x=160, y=140)
    Fecha.config(bg=color)

    subTotal= Label(cuadro,text=subTotal,font=("Times New Roman", 15),bd=0)
    subTotal.place(x=750, y=350)
    subTotal.config(bg=color)

    impuesto= Label(cuadro,text=impuesto,font=("Times New Roman", 15),bd=0)
    impuesto.place(x=750, y=375)
    impuesto.config(bg=color)

    total= Label(cuadro,text=total,font=("Times New Roman", 15),bd=0)
    total.place(x=750, y=400)
    total.config(bg=color)

    Salir = Button(cuadro,image=salir, command=lambda: menuPrin())
    Salir.place(x=40, y=420)
    Salir.config(bg=salida)
#===================================================================================================================
"""
Interfas
Nombre:Facturando
Entrada:cliente
Salida: menu de facturas
Restricciones: los parametros no deben de estra vacio
"""
def Facturando(cliente):
    if cliente=="":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    
    
    label = tk.Label(cuadro, image =carritoCompras)
    label.pack()

    labelnombre = tk.Label(cuadro,text="Hola "+cliente,font=("Times New Roman", 18))
    labelnombre.place(x=125, y=75)
    labelnombre.config(bg=color)

    opciones = LosProductos()
    comboboxP = ttk.Combobox(cuadro, values=opciones)
    comboboxP.place(x=340, y=230,width=125, height=20)

    Cantidad = IntVar()
    Cantidad = Entry(cuadro, textvariable=Cantidad, font=("Times New Roman", 13))
    Cantidad.place(x=600, y=230,width=100, height=20)

    Facturar = Button(cuadro, text="Facturar",command=lambda:LaFactura(),font=("Times New Roman", 15),relief="raised")
    Facturar.place( x=250,y=350)
    Facturar.config(bg=color)

    Agrega = Button(cuadro, text="Agrega",command=lambda:seAgregaCarrito(cliente,comboboxP.get(),Cantidad.get()),font=("Times New Roman", 15),relief="raised")
    Agrega.place( x=525,y=350)
    Agrega.config(bg=color)

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)
    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:anulaLaFactura
Entrada:ninguna
Salida: se anula factura especifica
Restricciones: los parametros no deben de estra vacio
"""
def anulaLaFactura():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =AnulacionFactura)
    label.pack()

    opciones2 = TodaslasFacturas()
    comboboxP = ttk.Combobox(cuadro, values=opciones2)
    comboboxP.place(x=425, y=200,width=125, height=20)

    Anular = Button(cuadro,text="Anular facturas", command=lambda: seAnuloLaFacrura(comboboxP.get()),font=("Times New Roman", 15))
    Anular.place(x=420, y=250)
    Anular.config(bg=color)

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
# menu Facturacion
"""
Interfas
Nombre:seFactura
Entrada:ninguna
Salida: se selecciona al cliente
Restricciones: los parametros no deben de estra vacio
"""
def seFactura():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =quienEres)
    label.pack()

    opciones2 = TodosLosClientes()
    comboboxP = ttk.Combobox(cuadro, values=opciones2)
    comboboxP.place(x=350, y=225,width=125, height=20)

    Compras = Button(cuadro,text="iniciar Compra",command=lambda:Facturando(comboboxP.get()),font=("Times New Roman", 15))
    Compras.place(x=300, y=400)
    Compras.config(bg=color)

    Anular = Button(cuadro,text="Anular facturas",command=lambda:anulaLaFactura(), font=("Times New Roman", 15))
    Anular.place(x=500, y=400)
    Anular.config(bg=color)

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=390)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:LaOrdenDeFactura
Entrada:factura1
Salida: muestra una orden de compra especifica
Restricciones: los parametros no deben de estra vacio
"""
def LaOrdenDeFactura(factura1):
    if factura1 == "":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =FacturaDeOrdenCompra)
    label.pack()
    Salir= Button(cuadro,image=salir, command=lambda:menuPrin())
    Salir.place(x=40, y=420)
    Salir.config(bg=salida)
    x=int(factura1)
    for elemento in inicio.listaorden:
        if  x == elemento.codigo:
            total=elemento.total
            impuesto=elemento.iva
            subTotal=elemento.subtotal
            nombre=elemento.provedor
            Fecha=elemento.fecha
            fac=elemento.codigo
            lista=elemento.caracteristicas
            break
    todasLasCategorias = Listbox(cuadro,  width=55, height=7,font=("Times New Roman", 14))
    todasLasCategorias.place(x=90, y=220)
    todasLasCategorias.config(bd=0)

    for elementos in lista:
        y=elementos[0]*elementos[1]
        ProductoL=str(elementos[2])
        cantidadL=str(elementos[1])
        precioUnitarioL=str(elementos[0])
        totalL=str(y)
        todasLasCategorias.insert("end",ProductoL+"                    "+cantidadL+"                        "+precioUnitarioL+"                            "+totalL)


    fac= Label(cuadro,text=fac,font=("Times New Roman", 15),bd=0)
    fac.place(x=410, y=45)
    fac.config(bg=color)

    nombre= Label(cuadro,text=nombre,font=("Times New Roman", 15),bd=0)
    nombre.place(x=175, y=95)
    nombre.config(bg=color)

    Fecha= Label(cuadro,text=Fecha,font=("Times New Roman", 15),bd=0)
    Fecha.place(x=160, y=140)
    Fecha.config(bg=color)

    subTotal= Label(cuadro,text=subTotal,font=("Times New Roman", 15),bd=0)
    subTotal.place(x=750, y=350)
    subTotal.config(bg=color)

    impuesto= Label(cuadro,text=impuesto,font=("Times New Roman", 15),bd=0)
    impuesto.place(x=750, y=375)
    impuesto.config(bg=color)



    total= Label(cuadro,text=total,font=("Times New Roman", 15),bd=0)
    total.place(x=750, y=400)
    total.config(bg=color)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:LaFacturaEapecifica
Entrada:lafactura
Salida: muestra una Factura especifica
Restricciones: los parametros no deben de estra vacio
"""
def LaFacturaEapecifica(lafactura):
    if lafactura == "":
        return messagebox.showerror(title="Error",message="no debe dejar parametros vacio")
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =FacturaDeCompra)
    label.pack()
    Factura=int(lafactura)
    for elementos in inicio.facturacion:
        if Factura ==elementos.codigoFC:
                total=elementos.total
                impuesto=elementos.iva
                subTotal=elementos.subtotal
                nombre=elementos.nombre
                Fecha=elementos.fecha
                fac=elementos.codigoFC
                lista=elementos.caracteristicas
                break
    todasLasCategorias = Listbox(cuadro,  width=55, height=7,font=("Times New Roman", 14))
    todasLasCategorias.place(x=90, y=220)
    todasLasCategorias.config(bd=0)

    for elementos in lista:
        totalU=str(elementos[7])
        Unitario=str(elementos[3])
        cantidad=str(elementos[2])
        for pro in inicio.listaproductos:
            if elementos[1]==pro.codigoPD:
                nombreProducto=pro.nombre
                break
    
        todasLasCategorias.insert("end",nombreProducto+"                      "+cantidad+"                     "+Unitario+"                          "+totalU)
    fac= Label(cuadro,text=fac,font=("Times New Roman", 15),bd=0)
    fac.place(x=300, y=45)
    fac.config(bg=color)

    nombre= Label(cuadro,text=nombre,font=("Times New Roman", 15),bd=0)
    nombre.place(x=175, y=95)
    nombre.config(bg=color)

    Fecha= Label(cuadro,text=Fecha,font=("Times New Roman", 15),bd=0)
    Fecha.place(x=160, y=140)
    Fecha.config(bg=color)

    subTotal= Label(cuadro,text=subTotal,font=("Times New Roman", 15),bd=0)
    subTotal.place(x=750, y=350)
    subTotal.config(bg=color)

    impuesto= Label(cuadro,text=impuesto,font=("Times New Roman", 15),bd=0)
    impuesto.place(x=750, y=375)
    impuesto.config(bg=color)

    total= Label(cuadro,text=total,font=("Times New Roman", 15),bd=0)
    total.place(x=750, y=400)
    
    total.config(bg=color)
    
    descargar = Button(cuadro,text="Descargar Factura", command=lambda: inicio.facturapdf(Factura),font=("Times New Roman", 14))
    descargar.place(x=850, y=400)
    descargar.config(bg=color)

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=420)
    Salir.config(bg=salida)


    cuadro.config(width=1000, height=500)
#===================================================================================================================
"""
Interfas
Nombre:ListasDeFacturas
Entrada:ninguna
Salida: menu de las facturas
Restricciones: los parametros no deben de estra vacio
"""
def ListasDeFacturas():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =listaFacaturas)
    label.pack()

    opciones1 = Todaslasordenesdecompra()
    comboboxP = ttk.Combobox(cuadro, values=opciones1)
    comboboxP.place(x=250, y=225,width=125, height=20)

    opciones2 =TodaslasFacturas()
    comboboxP2 = ttk.Combobox(cuadro, values=opciones2)
    comboboxP2.place(x=580, y=225,width=125, height=20)

    facu1 = Button(cuadro,text="Ver orden de compra", command=lambda:LaOrdenDeFactura(comboboxP.get()),font=("Times New Roman", 15))
    facu1.place(x=250, y=300)
    facu1.config(bg=color)

    facu2 = Button(cuadro,text="Ver factura", command=lambda:LaFacturaEapecifica(comboboxP2.get()),font=("Times New Roman", 15))
    facu2.place(x=580, y=300)
    facu2.config(bg=color)

    descargarOrden = Button(cuadro,text="Descargar lista de ordenes de compra",command=lambda:inicio.listadeorden(),font=("Times New Roman", 12))
    descargarOrden.place(x=250, y=400)
    descargarOrden.config(bg=color)

    descargarFac = Button(cuadro,text="Descargar facturas",command=lambda:inicio.facturasreport(),font=("Times New Roman", 12))
    descargarFac.place(x=580, y=400)
    descargarFac.config(bg=color)

    Salir = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    Salir.place(x=40, y=420)
    Salir.config(bg=salida)

    cuadro.config(width=1000, height=500)
#===================================================================================================================
# este es el menu
#===================================================================================================================
"""
Interfas
Nombre:menuPrin
Entrada:ninguna
Salida: menu principal
Restricciones: los parametros no deben de estra vacio
"""
def menuPrin():
    cuadro = Frame(ventana)
    cuadro.place(x=0, y=0)
    label = tk.Label(cuadro, image =menu)
    label.pack()

    categoria = Button(cuadro, text="Categorías", command=lambda: Categorias(),font=("Times New Roman", 12), relief="raised")
    categoria.place(x=325, y=250)
    categoria.config(bg=color)


    producto = Button(cuadro, text="Productos", command=lambda:MenuDeProducto(),  font=("Times New Roman", 12), relief="raised")
    producto.place(x=325, y=300)
    producto.config(bg=color)

    cliente= Button(cuadro, text="Clientes", command=lambda:MenuCliente(),font=("Times New Roman", 15), relief="raised")
    cliente.place(x=200, y=350)
    cliente.config(bg=color)

    provedores = Button(cuadro, text="Proveedores",  command=lambda:MenuProveedoresprint(),font=("Times New Roman", 15), relief="raised")
    provedores.place(x=200, y=400)
    provedores.config(bg=color)

    ordenC = Button(cuadro, text="Orden de Compra",  command=lambda:menuOrdenCompra(),font=("Times New Roman", 15), relief="raised")
    ordenC.place(x=750, y=250)
    ordenC.config(bg=color)

    facturacion = Button(cuadro, text="Factuación", command=lambda:seFactura(),font=("Times New Roman", 15), relief="raised")
    facturacion.place(x=750, y=300)
    facturacion.config(bg=color)

    busquedaF = Button(cuadro, text="Búsquedas de facturas", command=lambda:ListasDeFacturas(),font=("Times New Roman", 15), relief="raised")
    busquedaF.place(x=750, y=350)
    busquedaF.config(bg=color)


    SalirB = Button(cuadro,image=salir, command=lambda: cuadro.destroy())
    SalirB.place(x=40, y=390)
    SalirB.config(bg=salida)

    cuadro.config(width=1000, height=500)

ventana = Tk()

#===================================================================================================================
#imagenes
image = Image.open("interfas\Exit.png")
image = image.resize((50, 50))
salir = ImageTk.PhotoImage(image)

image = Image.open("interfas\compras.png")
image = image.resize((100, 100))
compras = ImageTk.PhotoImage(image)

image = Image.open("interfas\Acceso.png")
image = image.resize((1000, 500))
Acceso = ImageTk.PhotoImage(image)


image = Image.open("interfas\Menu.png")
image = image.resize((1000, 500))
menu = ImageTk.PhotoImage(image)

image = Image.open("interfas\Categoria.png")
image = image.resize((1000, 500))
categoria = ImageTk.PhotoImage(image)

image = Image.open("interfas\crearC.png")
image = image.resize((1000, 500))
crearCategoria = ImageTk.PhotoImage(image)

image = Image.open("interfas\plantillaModificar.png")
image = image.resize((1000, 500))
plantillaModificar = ImageTk.PhotoImage(image)

image = Image.open("interfas\BorrarCategoria.png")
image = image.resize((1000, 500))
BorrarCategoria = ImageTk.PhotoImage(image)

image = Image.open("interfas\Borrar.png")
image = image.resize((100, 100))
BotonBorrar = ImageTk.PhotoImage(image)

image = Image.open("interfas\mostrarCategoriasMenu.png")
image = image.resize((1000, 500))
enseñamenuCategoria = ImageTk.PhotoImage(image)

image = Image.open("interfas\MenuDeCLiente.png")
image = image.resize((1000, 500))
MenuDeCLiente = ImageTk.PhotoImage(image)

image = Image.open("interfas\RegistrarCLiente.png")
image = image.resize((1000, 500))
RegistrarCLiente = ImageTk.PhotoImage(image)

image = Image.open("interfas\ModificarCLiente.png")
image = image.resize((1000, 500))
ModificarCLiente = ImageTk.PhotoImage(image)

image = Image.open("interfas\MostrarCliente.png")
image = image.resize((1000, 500))
MostrarCliente = ImageTk.PhotoImage(image)

image = Image.open("interfas\BorrarCliente.png")
image = image.resize((1000, 500))
BorrarCliente = ImageTk.PhotoImage(image)

image = Image.open("interfas\MenuProveedores.png")
image = image.resize((1000, 500))
MenuProveedores = ImageTk.PhotoImage(image)

image = Image.open("interfas\AgregarProveedor.png")
image = image.resize((1000, 500))
AgregarProveedor = ImageTk.PhotoImage(image)

image = Image.open("interfas\ModificarProveedor.png")
image = image.resize((1000, 500))
ModificarProveedor = ImageTk.PhotoImage(image)

image = Image.open("interfas\BorrarProveedor.png")
image = image.resize((1000, 500))
BorrarProveedor = ImageTk.PhotoImage(image)

image = Image.open("interfas\ListaProveedor.png")
image = image.resize((1000, 500))
ListaProveedor = ImageTk.PhotoImage(image)

image = Image.open("interfas\MenudeProducto.png")
image = image.resize((1000, 500))
MenudeProducto = ImageTk.PhotoImage(image)

image = Image.open("interfas\MenuCrearProductos.png")
image = image.resize((1000, 500))
MenuCrearProductos = ImageTk.PhotoImage(image)

image = Image.open("interfas\LiataDEProducto.png")
image = image.resize((1000, 500))
LiataDEProducto = ImageTk.PhotoImage(image)

image = Image.open("interfas\MenudeProducto.png")
image = image.resize((1000, 500))
MenudeProducto = ImageTk.PhotoImage(image)

image = Image.open("interfas\VerProductoTotal.png")
image = image.resize((1000, 500))
VerProductoTotal = ImageTk.PhotoImage(image)

image = Image.open("interfas\VerProductoTotal.png")
image = image.resize((1000, 500))
VerProductoTotal = ImageTk.PhotoImage(image)

image = Image.open("interfas\ProductoEspecifico.png")
image = image.resize((1000, 500))
ProductoEspecifico = ImageTk.PhotoImage(image)

image = Image.open("interfas\SeModificaProducto.png")
image = image.resize((1000, 500))
SeModificaProducto = ImageTk.PhotoImage(image)

image = Image.open("interfas\Menudeordendecompra.png")
image = image.resize((1000, 500))
Menudeordendecompra = ImageTk.PhotoImage(image)

image = Image.open("interfas\FacturaDeOrdenCompra.png")
image = image.resize((1000, 500))
FacturaDeOrdenCompra = ImageTk.PhotoImage(image)

image = Image.open("interfas\Anular.png")
image = image.resize((1000, 500))
Anular = ImageTk.PhotoImage(image)

image = Image.open("interfas\quienEres.png")
image = image.resize((1000, 500))
quienEres = ImageTk.PhotoImage(image)

image = Image.open("interfas\carritoCompras.png")
image = image.resize((1000, 500))
carritoCompras = ImageTk.PhotoImage(image)

image = Image.open("interfas\FacturaDeCompra.png")
image = image.resize((1000, 500))
FacturaDeCompra = ImageTk.PhotoImage(image)

image = Image.open("interfas\listaFacaturas.png")
image = image.resize((1000, 500))
listaFacaturas = ImageTk.PhotoImage(image)

image = Image.open("interfas\AnulacionFactura.png")
image = image.resize((1000, 500))
AnulacionFactura = ImageTk.PhotoImage(image)

#===================================================================================================================
"""
Interfas
Nombre:ninguno
Entrada:ninguna
Salida: el acceso
Restricciones: los parametros no deben de estra vacio
"""
label = tk.Label(ventana, image =Acceso)
label.pack()

usuario = StringVar()
usuario = Entry(ventana, textvariable=usuario, font=("Times New Roman", 11))
usuario.config(bg=color)
usuario.place(x=350, y=240)


contra = StringVar()
contraseña = Entry(ventana, textvariable=contra,  font=("Times New Roman", 11))
contraseña.config(bg=color)
contraseña.place(x=400, y=300)

ingre = Button(ventana, text="Ingresar", command=lambda: ingreso(usuario.get(), contra.get()),  font=("Times New Roman", 15), bd=0,relief="groove",image=compras)
ingre.config(bg=color)
ingre.place(x=600, y=230)

SalirB = Button(ventana,image=salir, command=lambda: ventana.destroy())
SalirB.config(bg=salida)
SalirB.place(x=40, y=390)

ventana.config(width=1000, height=500)
ventana.resizable(False, False)
ventana.config(bg=color)

ventana.mainloop()