from tkinter import messagebox
from fpdf import FPDF
import datetime


mensajes=False
subtotal=0
total=0
iva=0
code=1
code2=1
code3=1
#codigos clase###################################################################################################################################################
###################################################################################################################################################
class Administración:
    
    def __init__(self):
        self.listacategoria=[]
        self.listaproductos=[]
        self.listaprovedor=[]
        self.listacliente=[]
        self.facturacion=[]
        self.listaorden=[]


        self.borrador=[]
        self.borradordecomprar=[]
        self.productosca=[]
        
        """
        nombre:facturasreport
        entrada: none
         salida: pdf  con el reporte de facturas 
         restriccion: que la lista con la informacion no este vacia"""
    def facturasreport(self):
     
        global code2
        if not  self.facturacion!=[]:
            return messagebox.showerror(title="Error",message=("No se encuentran facturas generadas"))
        #------------------------------
        #crea la hoja
        pdf=FPDF(orientation="p",unit="mm",format="A4")
        pdf.add_page()
        pdf.set_font("Arial","",12)
        #tabla
        pdf.text(x=80, y=18, txt="Reporte  de facturas ")
        pdf.line(x1=30,y1=20,x2=180,y2=20)
        pdf.text(x=32, y=30, txt=" factura" )  # factura
        pdf.text(x=70, y=30, txt="Producto ")  # código
        pdf.text(x=102, y=30, txt=" Cantidad")  # encabezado
        pdf.text(x=132, y=30, txt=" PrecioU ")  # encabezado
        pdf.text(x=162, y=30, txt=" Total")  # encabezado
     
        #nombre,codigoPD,cantidad,precio,cat,"",total,subtotal2]
   
        mm = 32
        stotal = 0
        for elemento in self.facturacion:
            pdf.text(x=35, y=mm + 5, txt=(str(elemento.codigoFC)))  # factura
            for caracter in elemento.caracteristicas:
                pdf.text(x=70, y=mm + 5, txt=str(caracter[0]))  # cantidad
                pdf.text(x=108, y=mm + 5, txt=str(caracter[2]))  
                pdf.text(x=135, y=mm + 5, txt=str(caracter[3]))  
                stotal+=caracter[3] * caracter[2]
                
                pdf.text(x=164, y=mm + 5, txt=str(caracter[2] * caracter[3]))  
                mm += 7  # Aumentar el valor de mm después de cada iteración
            #pdf.dashed_line(x1=30,y1=mm,x2=180,y2=mm,dash_length=2,space_length=3)
        pdf.line(x1=30,y1=mm,x2=180,y2=mm)
        pdf.text(x=145, y=mm + 5, txt="subtotal: "+str(stotal))
        pdf.text(x=145, y=mm + 10, txt="Iva: "+str(int(stotal*0.13)))
        pdf.text(x=145, y=mm + 15, txt="Total: "+str(int(stotal+stotal*0.13)))
        pdf.output("Reporte de facturas "+str(code2)+".pdf")
        code2+=1
        return messagebox.showinfo(title="Aviso",message=("Se ha descargado el reporte"))
        """
        nombre:listadeorden
        entrada: none
         salida: pdf  con el reporte de facturas de orden 
         restriccion: que la lista con la informacion no este vacia"""
    def listadeorden(self):
        global code
        if not  self.listaorden!=[]:
            return messagebox.showerror(title="Error",message=("No se encuentran ordenes generadas"))
        #------------------------------
        #crea la hoja
        pdf=FPDF(orientation="p",unit="mm",format="A4")
        pdf.add_page()
        pdf.set_font("Arial","",12)
        #tabla
        pdf.text(x=80, y=18, txt="Reporte lista de orden")
        pdf.line(x1=30,y1=20,x2=180,y2=20)
        pdf.text(x=32, y=30, txt=" Orden" )  # factura
        pdf.text(x=70, y=30, txt="Producto ")  # código
        pdf.text(x=102, y=30, txt=" Cantidad")  # encabezado
        pdf.text(x=132, y=30, txt=" PrecioU ")  # encabezado
        pdf.text(x=162, y=30, txt=" Total")  # encabezado
     
    
        mm = 32
        stotal = 0
        for elemento in self.listaorden:
            pdf.text(x=35, y=mm + 5, txt=(str(elemento.codigo)))  # orden
            for caracter in elemento.caracteristicas:
                pdf.text(x=70, y=mm + 5, txt=str(caracter[2]))  # código
                pdf.text(x=108, y=mm + 5, txt=str(caracter[1]))  # encabezado
                pdf.text(x=135, y=mm + 5, txt=str(caracter[0]))  # encabezado
                stotal+=caracter[0] * caracter[1]
                pdf.text(x=164, y=mm + 5, txt=str(caracter[0] * caracter[1]))  # encabezado
                mm += 7  # Aumentar el valor de mm después de cada iteración
            #pdf.dashed_line(x1=30,y1=mm,x2=180,y2=mm,dash_length=2,space_length=3)
        pdf.line(x1=30,y1=mm,x2=180,y2=mm)
        pdf.text(x=145, y=mm + 5, txt="subtotal: "+str(stotal))
        pdf.text(x=145, y=mm + 10, txt="Iva: "+str(int(stotal*0.13)))
        pdf.text(x=145, y=mm + 15, txt="Total: "+str(int(stotal+stotal*0.13)))
        pdf.output("Reporte de orden "+str(code)+".pdf")
        code+=1
        return messagebox.showinfo(title="Aviso",message=("Se ha descargado el reporte"))
    """
        nombre:facturapdf
        entrada: codigo
        salida: pdf  la factura segun el codigo que entre
        restriccion: que la lista con la informacion no este vacia"""
    def facturapdf(self,codigo):
        global code3
        mm=57
        if not (  self.facturacion!=[]):
            return messagebox.showerror(title="Error",message="No se encuentran facturas aun,asegurese de haber hecho compras")   
        
        go =False
        for elemento in self.facturacion:
            if str(codigo)==str(elemento.codigoFC):
                go=True
                facturan=str(elemento.codigoFC)
                fecha=str(elemento.fecha)
                total=elemento.total
                subtotal=elemento.subtotal
                iva=elemento.iva
                cliente=str(elemento.nombre)
                codigo1=str(elemento.codigoCL)
                
        if go!=False:        
            pdf=FPDF(orientation="p",unit="mm",format="A4")
            pdf.add_page()
            pdf.line(x1=40,y1=57,x2=160,y2=57)# se usa para lineas
            #texto
            pdf.set_font("Arial","",12)
            #pdf.text(x=80, y=33, txt="Factura")  # título
            pdf.text(x=15, y=39, txt="Fecha: " + fecha)  # fecha
            pdf.text(x=170, y=20, txt="Factura#" + facturan)  # factura
            pdf.text(x=15, y=45, txt="Cliente: " + str(cliente))  # código
            pdf.text(x=40, y=55, txt=" Producto")  # encabezado
            pdf.text(x=75, y=55, txt=" Cantidad")  # encabezado
            pdf.text(x=110, y=55, txt=" Precio unitario")  # encabezado
            pdf.text(x=145, y=55, txt=" Total")  # encabezado 
            
            for caracter in elemento.caracteristicas:
                        mm+=5
                        producto=str(caracter[0])
                        cantidad=str(caracter[2])
                        totalpd=str(caracter[-2])
                        precio=str(caracter[3])
                                #informacion 
                        pdf.text(x=41, y=mm, txt= producto)  
                        pdf.text(x=76, y=mm, txt= cantidad)   
                        pdf.text(x=111, y=mm, txt=precio)  
                        pdf.text(x=146, y=mm, txt=totalpd)
            
            mm+=4
            pdf.line(x1=40,y1=mm,x2=160,y2=mm)# se usa para lineas
            pdf.text(x=130, y=mm+5, txt=" Subtotal: "+str(subtotal))  # encabezado
            pdf.text(x=130, y=mm+10, txt=" Iva: "+str(iva))  # encabezado
            pdf.text(x=130, y=mm+15, txt=" Total: "+str(total)) 
            
                    #genera la salida
            pdf.output("factura"+str(code3)+".pdf")
            code3+=1
            return messagebox.showinfo(title="Aviso",message="Se genero su factura")
            
        else:
            return messagebox.showerror(title="Error",message="No se encuentran facturas relacionadas al codigo")    
    """
    Nombre: crearcat
    Entrada:nombrecat
    salida : none
    restriccion: que no hayan valores vacios, y que no se haya creado previamente
    funcion: ingresa nuevas categorias """ 
    def crearcat(self,nombrecat):
        if not (nombrecat!=""):
             return messagebox.showerror( message= "ERROR:Debe ingresar un nombre de categoria valido")
        if self.listacategoria!=[]:
            for elemento in self.listacategoria:# valida que no se escriba 2 veces la misma categoria
                cat=elemento.categoria
                if cat ==(str(nombrecat)):
                    return messagebox.showerror( message= "ERROR: esta categoria ya fue registrada")
        nuevacat=Categoria(nombrecat)    
        self.listacategoria+=[nuevacat]
        if mensajes!=False:
            return messagebox.showinfo (title="Aviso", message= "Se he ingresado la categoria en el sistema")



    """
    Nombre: modificarcat
    Entrada:codigo,nuevonombre
    salida : none
    restriccion: que no hayan valores vacios, y que no se haya creado previamente
    funcion: modifica el nopmbre de categorias nuevas categorias """

    def modificarcat(self,referencia,nombre):
        
        if not referencia!="":
            return messagebox.showerror( message= "ERROR: debe ingresar un codigo valido")
        lista=self.listacategoria
       
        busqueda=Administración.codes(lista,referencia)
     
        if not nombre!="":
          return messagebox.showerror( message= "ERROR: debe ingresar un nuevo nombre valido")
        
        for elemento in self.listacategoria:#verifica que no se vaya a repetir el nombre de categoria
            if elemento.categoria==nombre:
                return messagebox.showerror( message= "ERROR:  Este nombre de categoria ya fue utilizado")
            
        for elemento in self.listacategoria:#realiza el cambio en el codigo
            if str(elemento.codigocat)==busqueda:
                elemento.categoria=nombre
                if mensajes!=False:
                    return messagebox.showinfo (title="Aviso", message= "Se he modificado la categoria en el sistema")
        
   

        

    """
    Nombre: borrarcat
    Entrada:codigo
    salida : none
    restriccion: que no hayan valores vacios, y que no se haya sido facturado previamente
    funcion: busca y borra la categoria segun el codigo """

    def borrarcat(self,selector):
        lista=[]
        if not selector!="":
            return messagebox.showerror( message= "ERROR: El nombre o codigo no se ingreso")
      
      
        busqueda=""
    
        
        try: 
            selector=int(selector)
            busqueda= str(selector)
        except:
            long=len(selector)
            for elemento in self.listacategoria:
               
                var=elemento.categoria
                
                while var!="": 
                    if var[0:long]==str(selector):
                        busqueda= str(elemento.codigocat)
                        break
                    else:
                        var=var[1:]
       
              
        for elemento in self.facturacion:#revisa que no haya nada facturado con la clase
            if str(elemento.codigocat)!=busqueda:
                    continue
            else:
                return messagebox.showerror( message= "ERROR: Ya hay productos facturados ligados a esta categoria")
        for elemento in self.listaproductos:#revisa que no haya nada facturado con la clase
            if str(elemento.codigocat)!=busqueda:
                    continue
            else:
                return messagebox.showerror( message= "ERROR: Ya hay productos facturados ligados a esta categoria")

        for elemento in self.listacategoria:
            if str( elemento.codigocat)!=busqueda:
                lista+=[elemento]
            
            
        self.listacategoria=lista
        if mensajes!=False:
            return messagebox.showinfo (title="Aviso", message= "Se he eliminado la categoria en el sistema") 
    
    def codes(Lista,selector):
        busq=""
        
        try: 
            selector=int(selector)
            busq= str(selector)
        except:
            long=len(selector)
            for elemento in Lista:
               
                var=elemento.categoria
                
                while var!="": 
                    if var[0:long]==str(selector):
                        return str(elemento.codigocat)
                    else:
                        var=var[1:]
       
        return busq 
        
    #====================PRODUCTOS===============================================================================================================================
    """
    Nombre: crearProducto
    Entrada:nombre,provedor,codigocat,precioU
    salida : creacion de nuevos productos
    restriccion: que no hayan valores vacios, y que no se haya sido ingresado previamente
    funcion:ingresa nuevos productos al sistema """
    
    def crearProducto(self,nombre,codigoPV,codigocat,precioU): 
        #verificaciones
        existeprov=False
        existenom=False #este tiene que permanecer false o si no se va a generar mensaje de error
        existecode=False
        if not nombre!="":
            return messagebox.showerror( message= "ERROR: debe ingresar un nombre")
        
        if not codigoPV!="":
            return messagebox.showerror( message= "ERROR: debe ingresar un provedor")
        
        if not codigocat!="":
            return messagebox.showerror( message= "ERROR: debe ingresar un codigo de categoria valido")
        
        if not precioU!="":
            return messagebox.showerror( message= "ERROR: debe ingresar un precio unitario para el producto")
        
        for elemento in self.listacategoria:#Verifica que la categoria exista
            if str(elemento.codigocat)==str(codigocat):
                nombrecat=elemento.categoria
                codigo=elemento.codigocat
                existecode=True
        for elemento in self.listaprovedor:
            if str(elemento.codigoPV)==str(codigoPV):
                nombrePV=elemento.nombre
                existeprov=True
        for elemento in self.listaproductos:
            if str(elemento.nombre)==str(nombre):
                existenom=True
        if not existeprov:
             return messagebox.showerror( message= "ERROR: No se encontraron provedores relacionados al codigo que se ingreso")         
        if not existecode:
             return messagebox.showerror( message= "ERROR: No se encontraron categorias relacionadas al codigo que se ingreso")     
        if not existenom==False:
             return messagebox.showerror( message= "ERROR:Ya existe un produicto con este nombre") 
        producto=Productos(codigoPV,nombrecat,precioU,nombre,0,codigo)
        self.listaproductos+=[producto] 
        if mensajes!=False:
            return messagebox.showinfo (title="Aviso", message= "Se he creado el producto en el sistema")     
    """
    Nombre: modificarproducto
    Entrada:referencia,nombre,codigoPV,codigocat,precioU
    salida : modificacion de  productos
    restriccion: que no hayan valores vacios, y que no se haya sido ingresado previamente
    funcion:ingresa nuevas actualizaciones al sistema de productos """
             
    def modificarproducto(self,referencia,nombre,codigoPV,codigocat,precioU):    
        existeprov=False
        existenom=False #este tiene que permanecer false o si no se va a generar mensaje de error
        existecode=False
       
        if nombre!="":
            for elemento in self.listaproductos:
                if str(elemento.nombre)==str(nombre):
                    existenom=True
        
        for elemento in self.listacategoria:
            if str(elemento.codigocat)==str(codigocat):
                existecode=True
            if codigocat=="":
                existecode=True
        if precioU!=0:
            if not precioU>0:
                 return messagebox.showerror( message= "ERROR: debe ingresar un precio mayor a 0") 
        if codigoPV!="":
            for elemento in self.listaprovedor:
                if str(elemento.codigoPV)==str(codigoPV):
                    existeprov=True
        else:
              existeprov=True
        if not existeprov:
             return messagebox.showerror( message= "ERROR: No se encontraron provedores relacionados al codigo que se ingreso")         
        if not existecode:
             return messagebox.showerror( message= "ERROR: No se encontraron categorias relacionadas al codigo que se ingreso")     
        if not existenom==False:
             return messagebox.showerror( message= "ERROR:Ya existe un produicto con este nombre") 
        codigo=Administración.codigoproductos(self,referencia) 
        for elemento in self.listaproductos:
            if str(elemento.codigoPD)==codigo:
                if nombre!="":
                    elemento.nombre=nombre
                if codigocat!="":
                    elemento.codigocat=codigocat
                if precioU!="":
                    elemento.precio=precioU
                if codigoPV!="":
                    elemento.codigoPV=codigoPV
        if mensajes!=False:
            return messagebox.showinfo (title="Aviso", message= "Se he modificado el producto en el sistema")
    
    
    """
    Nombre: borrarProducto
    Entrada:referencia
    salida : nueva lista de productos editada
    restriccion: que no hayan valores vacios, y que no se haya sido facturado previamente
    funcion:ingresa nuevas actualizaciones al sistema de productos """
    def borrarProducto (self,referencia):
        lista=[]
        if not referencia!="":
            return messagebox.showerror( message= "ERROR: El nombre o codigo no se ingreso")
    
        busqueda=Administración.codigoproductos(self,referencia)#sirve para solo buscar por codigo
       
      
        for elemento in self.facturacion:
            cd=elemento.caracteristicas
            for x in cd:
                if str(x[1])!=busqueda:
                        continue
                else:
                    return messagebox.showerror( message= "ERROR: Ya hay productos facturados ligados a esta categoria")


        for elemento in self.listaproductos:
            if str(elemento.codigoPD)==str(busqueda):
                continue
            else:
                lista+=[elemento]
            
            
        self.listaproductos=lista 
        if mensajes!=False:
            return messagebox.showinfo (title="Aviso", message= "Se he elimino el producto del sistema")
    
    def codigoproductos(self,selector):
        busq=""
        
        try: 
            selector=int(selector)
            busq= str(selector)
        except:
            long=len(selector)
            for elemento in self.listaproductos:
                var=str(elemento.nombre)
                while var!="": 
                    if var[0:long]==str(selector):
                        busq=str(elemento.codigoPD)
                        var=""
                    else:
                        var=var[1:]
        return busq  
    #===========clientes======================================================================================================
        
      
    """
    Nombre: crearcliente
    Entrada:nombre,apellido1,apellido2,telefono,provincia,email
    salida : ingreso de cliente a lista clientes
    restriccion: que no hayan valores vacios, y que no se haya facturado previamente
    funcion:ingresa nuevos clientes a la lista de clientes """
    def crearcliente(self,nombre,apellido1,apellido2,telefono,cedula,provincia,email):
        veri=Correo(email)
        existecliente=False#verifica que el cliente no exista
        if not nombre !="":
            return messagebox.showerror( message= "ERROR: no puede ingresar valores vacios")
        if not apellido1 !="":
            return messagebox.showerror( message= "ERROR: no puede ingresar valores vacios")
        if not apellido2 !="":
            return messagebox.showerror( message= "ERROR: no puede ingresar valores vacios")
        if not telefono !="":
            return messagebox.showerror( message= "ERROR: no puede ingresar valores vacios")
        if not provincia !="" and len(telefono)!=8:
            return messagebox.showerror( message= "ERROR: no puede ingresar valores vacios ademas el largo de el nuemro de telefono debe ser 8")
        if not email !="" and veri!=False:
            return messagebox.showerror( message= "ERROR: no puede ingresar valores vacios")
        if self.listacliente==[]:
            existecliente=False
        else:
            for elemento in self.listacliente:
                if str(elemento.cedula)!=str(cedula):
                    continue
                else:
                    existecliente=True
        if existecliente!=True:
            nuevocliente=Cliente(nombre,apellido1,apellido2,telefono,cedula,provincia,email)
            self.listacliente+=[nuevocliente]
            if mensajes!=False:
                return messagebox.showinfo (title="Aviso", message= "Se ingreso el cliente en el sistema")
        else:
            return messagebox.showerror( message= "ERROR: El cliente ya se encuentra registrado")
        
    """
        Nombre: modificarcliente
        Entrada:nombre,apellido1,apellido2,telefono,provincia,email
        salida : ingreso de cliente a lista clientes
        restriccion: que no hayan valores vacios, y que no se haya facturado previamente
        funcion:modifica  clientes en la lista de clientes """
    def modificarcliente(self,selector,nombre,apellido1,apellido2,telefono,cedula,provincia,email):
        repite=False
        if email!="":
            veri=Correo(email)
        else:
            veri=True
        busq=""
        if selector=="":
             return messagebox.showerror( message= "ERROR: Debe ingresar una nombre o parte de este si no el codigo de cliente o su cedula")
      
           
        else:
            try: 
                selector=int(selector)
                busq= str(selector)
            except:
                long=len(str(selector))
                for elemento in self.listacliente:
                
                    var=elemento.nombre
                    if len(str(selector))==9:
                        if str(elemento.cedula)==str(selector):
                            busq= str(elemento.codigoCL)
                        
                    else:        
                        while var!="": 
                            if var[0:long]==str(selector):
                                busq= str(elemento.codigoCL)
                                var=""
                            else:
                                var=var[1:]
        telefono=str(telefono)
        cedula=str(cedula)
        
        if busq!="":
            for elemento in self.listacliente:
                if elemento.cedula==cedula:
                       
                    repite=True#es para evitar que los nombres se repitan
                    return messagebox.showerror( message= "ERROR: La cedula ya se encuentra registrada")
            if repite!=True:
                if telefono!="" and len(telefono)==8:
                    for elemento in  self.listacliente:# evita que se repitan numeros o correos
                        if elemento.correo==email and veri!=False:
                            return messagebox.showerror( message= "ERROR: El correo ya se encuentra registrado")
                        if str(elemento.telefono)==telefono:
                            return messagebox.showerror( message= "ERROR: El numero de telefono ya se encuentra registrado")
            for elemento in self.listacliente:
                if str(elemento.codigoCL)==busq:
                    if nombre!="":
                        elemento.nombre=nombre
                    if apellido1!="":
                        elemento.apellidos=apellido1
                    if apellido2!="":
                        elemento.apellido2=apellido2
                    if telefono!="":
                        elemento.telefono=telefono
                    if email!="":
                        elemento.correo=email
                    if provincia!="":
                        elemento.provincia=provincia
                    if cedula!="":
                        elemento.cedula=cedula
            if mensajes!=False:        
                return messagebox.showinfo (title="Aviso", message= "Se he modificado el cliente en el sistema")
        else:
             return messagebox.showerror( message= "ERROR:No se encontro un cliente que concida con la referencia ingresada")               


    """
        Nombre: borrarcliente
        Entrada:selector
        salida : se borra cliente a lista clientes
        restriccion: que no hayan valores vacios, y que no se haya facturado previamente
        funcion: elimina  clientes en la lista de clientes """                
    def borrarcliente(self,selector):
        go=True
        busq=""
        lista=[]
        if selector=="":
            
             return messagebox.showerror( message= "ERROR: Debe ingresar una nombre o parte de este si no el codigo de cliente o su cedula")
           
        else:
            try: 
                selector=int(selector)
                busq= str(selector)
            except:
                long=len(selector)
                for elemento in self.listacliente:
                
                    var=elemento.nombre
                    if len(selector)==10:
                        if elemento.cedula==selector:
                            busq= str(elemento.codigoCL)
                     
                        
                    else:        
                        while var!="": 
                            if var[0:long]==str(selector):
                                busq= str(elemento.codigoCL)
                                var=""
                            else:
                                var=var[1:]
        for elemento in self.facturacion:
            if str(elemento.codigoCL)!=busq:
                    continue
            else:
                go=False
                return messagebox.showerror( message= "ERROR: Ya hay productos facturados ligados a este cliente")
    
                    
        if go!=False:
            for elemento in self.listacliente:
                if elemento.codigoCL==busq:
                    continue
                    
                else:
                    lista+=[elemento]
                     
            
            self.listacliente=lista
            if mensajes!=False:
                return messagebox.showinfo (title="Aviso", message= "Se he eliminado el cliente del sistema")
    #==============provedores===============================================================================================================================
    
    """
        Nombre: crearProvedor
        Entrada:cedula,empresa,telefono,correo
        salida :crea nuevos provedores
        restriccion: que no hayan valores vacios, y que no se haya registrado previamente
        funcion: ingresa provedores en la lista de provedores """    
    def crearProvedor(self,cedula,empresa,telefono,correo):
        veri=Correo(correo)
        if not cedula !="" and len(cedula)==9:
            return messagebox.showerror( message= "ERROR: Debe ingresar una cedula")
        if not empresa !="":
            return messagebox.showerror( message= "ERROR: Debe ingresar una empresa")
        if not correo !="" and correo!=False :
            return messagebox.showerror( message= "ERROR:Debe ingresar un correo electronico")
        if not telefono !="" and len(telefono)==8:
            return messagebox.showerror( message= "ERROR: Debe ingresar un numero de telefono")
            
        
        for elemento in self.listaprovedor:
            if not elemento.cedula!=cedula:
                return messagebox.showerror( message= "ERROR: Esta cedula ya se encuetra registrada")
            if not elemento.nombre!=empresa:
                return messagebox.showerror( message= "ERROR: Esta empresa ya se encuetra registrada")  
            if not elemento.telefono!=telefono: 
                 return messagebox.showerror( message= "ERROR: El numero de telefono ya se encuetra registrado")
            if not elemento.correo!=correo:
                return messagebox.showerror( message= "ERROR: El correo electronico  ya se encuetra registrado")
        provedor=Provedor(cedula,empresa,telefono,correo)  
        self.listaprovedor+=[provedor]
        if mensajes!=False:
            return messagebox.showinfo (title="Aviso", message= "Se he ingresado el provedor al sistema")
    """
        Nombre: modificarprovedor
        Entrada:cedula,empresa,telefono,correo
        salida :modifica nuevos provedores
        restriccion: que no hayan valores vacios, y que no se haya registrado previamente
        funcion: modifica provedores en la lista de provedores """
    def modificarprovedor(self,selector,cedula,empresa,telefono,correo):
        repite=False
         
        busq=""
        if selector=="":
             return messagebox.showerror( message= "ERROR: Debe ingresar una nombre o parte de este si no el codigo de provedor o su cedula")
      
           
        else:
            try: 
                selector=int(selector)
                busq= str(selector)
            except:
                long=len(selector)
                for elemento in self.listaprovedor:
                
                    var=elemento.nombre
                    if len(selector)==9:
                        if elemento.cedula==selector:
                            busq= str(elemento.codigoPV)
                        
                    else:        
                        while var!="": 
                            if var[0:long]==str(selector): 
                                busq= str(elemento.codigoPV)
                                var=""
                            else:
                                var=var[1:]
        
        if busq!="":
            for elemento in self.listaprovedor:
                
                if not elemento.nombre!=empresa:
                        repite=True
                        return messagebox.showerror( message= "ERROR: El provedor ya se encuentra registrado")
                if not elemento.cedula!=cedula:
                        repite=True
                        return messagebox.showerror( message= "ERROR: La cedula ya se encuentra registrada")
                if not elemento.correo!=correo:
                            return messagebox.showerror( message= "ERROR: El correo ya se encuentra registrado")
                if not str(elemento.telefono)!=telefono:
                            return messagebox.showerror( message= "ERROR: El numero de telefono ya se encuentra registrado")
                 
            for elemento in self.listaprovedor:
                if str(elemento.codigoPV)==busq:
                    if empresa!="":
                        elemento.nombre=empresa
                    if cedula!="":
                        elemento.cedula=cedula
                    if telefono!="":
                        elemento.telefono=telefono
                    if correo!="":
                        elemento.correo=correo
            if mensajes!=False:
                return messagebox.showinfo (title="Aviso", message= "Se he modificado el provedor en el sistema")
        """
        Nombre: eliminarprovedor
        Entrada:selector
        salida : se borra provedor a lista provedor
        restriccion: que no hayan valores vacios, y que no se haya facturado previamente
        funcion: elimina  provedores en la lista de provedores """ 
    def eliminarprovedor(self,selector):
        go=True
        busq=""
        lista=[]
        if selector=="":
            
             return messagebox.showerror( message= "ERROR: Debe ingresar una nombre o parte de este si no el codigo de cliente o su cedula")
           
        else:
            try: 
                selector=int(selector)
                busq= str(selector)
            except:
                long=len(selector)
                for elemento in self.listaprovedor:
                
                    var=elemento.nombre
                    if len(selector)==9:
                        if elemento.cedula==selector:
                            busq= str(elemento.codigoPV)
                        
                    else:        
                        while var!="": 
                            if var[0:long]==str(selector):
                                busq= str(elemento.codigoPV)
                                var=""
                            else:
                                var=var[1:]
        for elemento in self.listaorden:#si la categoria ya se ingreso a una orden no se puede eliminar
            if str( elemento.codigoPV)!=busq:
                    continue
            else:
                go=False
                return messagebox.showerror( message= "ERROR: Ya hay productos facturados ligados a este provedor")
    
        for elemento in self.listaproductos:# en caso de haber productos relacionados al provedor no se puecde
            if str(elemento.codigoPV)!=busq:
                continue
            else:
                go=False
                return messagebox.showerror( message= "ERROR: Ya hay productos facturados ligados a este provedor")
                
        if go!=False:
            for elemento in self.listaprovedor:
                if str(elemento.codigoPV)==busq:
                    continue
                    
                else:
                    lista+=[elemento]
            self.listaprovedor=lista
            if mensajes!=False:
                return messagebox.showinfo (title="Aviso", message= "Se he eliminado el provedor del sistema")
    """
        Nombre: Ordenesdecompra
        Entrada:,provedor,precioU,cantidad,producto
        salida : se compra al provedor a productos
        restriccion: que no hayan valores vacios, y que no se se repita nada ingresado previamente
        funcion:ingresa cantidad de productos a la lista """ 
    def Ordenesdecompra(self,provedor,precioU,cantidad,producto):
        produ=[]
        fecha = datetime.datetime.now().strftime("%d/%m/%Y")
        if not provedor!="":
            return messagebox.showerror(title="Error",message="Debe ingresar un provedor ")   
        if not precioU!="" and precioU>0:
            return messagebox.showerror(title="Error",message="Debe ingresar un precio unitario para el producto ")
        if not cantidad!="" and cantidad>0:
            return messagebox.showerror(title="Error",message="Debe ingresar un precio unitario para el producto ")
        if not producto!="":
            return messagebox.showerror(title="Error",message="Debe ingresar un producto")
        
        
        for elemento in self.listaproductos:#verifica que el producto ya exista
            name=elemento.nombre
            name=name.lower()
            producto=producto.lower()
            cat=elemento.codigocat
            codigoPD=elemento.codigoPD
            if name==producto:
                for elemento in self.listaprovedor:#verifica que el provedor exista
                    nombreprovedor=elemento.nombre
                    if str(elemento.codigoPV)==str(provedor):
                        for elemento in self.listacategoria:# verifica que la categoria de producto exista
                            if str(elemento.codigocat)==str(cat):
                                produ=[precioU,cantidad,producto,codigoPD] 
                                self.borrador+=[Objetos(nombreprovedor,provedor,precioU,cantidad,producto,cat,produ)]#en caso de matriz extraña eliminar uno
                                                            
    def ordenescompraaux(self):
        if self.borrador==[]:
            return messagebox.showerror(title="Error",message="Aun no se han ingresado productos a la orden de compra")
        subtotal=0
        total=0
        iva=0
        lista=[]     
        for elemento in self.borrador:
            #nombreprovedor,provedor,precioU,cantidad,producto,cat,produ)
                
            categoria=elemento.categoria
            provedor=elemento.provedor
            cdprovedor=elemento.codigoPV
            previo=int(elemento.precio)*int(elemento.cantidad) 
                
            lista+=[elemento.detalles+[categoria]]#almcena la matriz de prodcutos y precios de la orden

            subtotal+=previo
        iva=subtotal*0.13
        total=subtotal+iva
        objeto=Ordencompra(cdprovedor,provedor,subtotal,iva,total,categoria,lista)
        self.listaorden+=[objeto]
       
        self.borrador=[]
       
        ingreso=objeto.caracteristicas # es el objeto que contitiene el acceso a los productos
   
        for elemento in self.listaproductos:#modifica la cantidad del producto en la lista de productos
            for produ in ingreso:
                if str(elemento.codigoPD)==str(produ[-2]):
                    elemento.cantidad+=produ[1]
        if mensajes!=False:
            return messagebox.showinfo(title="Aviso",message="Se ingreso la cantidad indicada a los productos")

     
    """
    Nombre: anularorden
    Entrada:codigodeorden
    salida : se anula una factura
    restriccion: que no hayan valores vacios
    funcion: anula ordenes """                    
    def anularorden(self,codigodeorden):
        
        if not codigodeorden!="" and codigodeorden>0:
            return messagebox.showerror(title="Error",message="Debe ingresar un codigo de orden de compra")
        if not self.listaorden!=[]:
             return messagebox.showerror(title="Error",message="No se encuentran ordenes de compra en el sistema")
        try: 
            selector=int(codigodeorden)
            codigodeorden= str(selector)
        except:
            long=len(selector)
            for elemento in self.listaorden:
                
                var=elemento.provedor
                  
                while var!="": 
                    if var[0:long]==str(selector): 
                        busq= str(elemento.codigoPV)
                        var=""
                    else:
                        var=var[1:]
       
        for info in self.listaorden:#busca la orden que se va a eliminar
            if str(info.codigo)==str(codigodeorden):
                caracteristicas=info.caracteristicas# es una matriz
                for elemento in self.listaproductos:#resta las cantidades a la lista de productos   produ=[precioU,cantidad,producto,codigoPD] 
                    producto=str(elemento.codigoPD)
                
                    for detalle in caracteristicas:
                        if producto== str(detalle[-2]):
                            if int(elemento.cantidad)<int(detalle[1]):
                                return messagebox.showerror(title="Aviso", message="No se encuentran productos suficientes para realizar la devolucion")
                                

                            else:
                                elemento.cantidad= int(elemento.cantidad)-int(detalle[1])
        if mensajes!=False:
            return messagebox.showinfo(title="Aviso", message="Se anulo con exito la  orden de compra")

    """
    Nombre: facturar
    Entrada:codigocliente,producto,cantidad
    salida : nueva factura
    restriccion: que no hayan valores vacios y todos lo datos sean existentes
    funcion: factura nuevas ordenes """                   
    def facturar(self,codigocliente,producto,cantidad):#esta funcion es solo para montar el machote
       
        if not codigocliente!="":
            return messagebox.showerror(title="Error",message="Debe ingresar un cliente, en caso de no tener puede agregar uno nuevo ")   
        if not cantidad!="" and cantidad>0:
            return messagebox.showerror(title="Error",message="Debe ingresar la cantidad que desee del producto producto ")
        if not producto!="":
            return messagebox.showerror(title="Error",message="Debe ingresar un producto")
        global subtotal
        iva=0
        total=0
    
        try: 
            selector=int(producto)
            producto= str(selector)
        except:
            long=len(producto)
            for elemento in self.listaproductos:
                
                var=elemento.nombre
                  
                while var!="": 
                    if var[0:long]==str(producto): 
                        producto= str(elemento.codigoPD)
                        var=""
                    else:
                        var=var[1:]
        if self.listacliente==[]:
            return messagebox.showerror(title="Error",message=("No se encuentran clientes en el sistema asegurese de haber ingesado uno"))
        for caracter in self.listacliente:
            if str(caracter.codigoCL)==str(codigocliente):
                cliente=str(caracter.nombre)+" " + str(caracter.apellidos)+ " "+str(caracter.apellido2)
        for elemento in self.listaproductos:#identifica el producto que se esta facturando
            codigoPD=elemento.codigoPD
            nombre=elemento.nombre
            cat=elemento.codigocat
            precio=elemento.precio
            if str(codigoPD)==producto:
                if elemento.cantidad < cantidad or cantidad > elemento.cantidad:
                    messagebox.showinfo(title="Cantidad insuficiente", message="No hay productos suficientes en el inventario para cumplir su orden")

                else:
                    subtotal+=precio*cantidad
                    subtotal2=precio*cantidad
                    #iva=subtotal2*0.13
                    total=subtotal2
       
                    elemento.cantidad-=cantidad
                    self.productosca+=[[nombre,codigoPD,cantidad,precio,cat,"",total,subtotal2]]
        
        self.borradordecomprar=[subtotal,cliente,self.productosca,codigocliente] 
      

    def finalizarfactura(self):
        
        global subtotal
        producto=self.borradordecomprar

        
        iva=subtotal*0.13
        total=subtotal+iva
        detalles=producto[-2]
        codigocliente=producto[-1]
        cliente=producto[1]
        cat=detalles[-1]

        ingreso=Facturacion(cat,total,subtotal,iva,detalles,codigocliente,cliente)
        self.borradordecomprar=[]
        self.facturacion+=[ingreso]
    
        self.productosca=[]
        subtotal=0
        if mensajes!=False:
             return messagebox.showinfo(title="Aviso",message=("Se ingreso al sistema la factura"))
        
    """
    Nombre: anularfactura
    Entrada:codigocliente,producto,cantidad
    salida : elimina factura de la lista
    restriccion: que no hayan valores vacios y todos lo datos sean existentes
    funcion: elimina ordenes de facturacion"""    
    def anularfactura(self,codigo):
        stop=False
        nueva=[]
        if  not codigo!="":
            messagebox.showerror(title="Error ", message="Debe ingresar un codigo valido")
        for elemento in self.facturacion:# aparece la factura que se va a eliminar
            if str(elemento.codigoFC)==str(codigo):
                caracteristicas=elemento.caracteristicas
                
                for detalle in caracteristicas:
                    
                    if (detalle,list):
                        codigoproducto=detalle[1]
                        cantidad=detalle[2]
                    
                    else:
                        stop=True
                        codigoproducto=caracteristicas[1]
                        cantidad=caracteristicas[2]
                    
                    for caracter in self.listaproductos:#termianr
                        if (caracter,list):
                                if str(caracter.codigoPD)==codigoproducto:
                                    caracter.cantidad=int(caracter.cantidad)+int(cantidad) #[producto,codigoPD,cantidad,precio] 
                                    codigoproducto=0
                                    cantidad=0
                        if str(caracter.codigoPD)==codigoproducto:
                                caracter.cantidad=int(caracter.cantidad)+int(cantidad) #[producto,codigoPD,cantidad,precio] 
                                                    
        for objeto in self.facturacion:
            if str(objeto.codigoFC)!=str(codigo):
                nueva+=[objeto]
        self.facturacion=nueva
        if mensajes!=False:
             return messagebox.showinfo(title="Aviso",message="Se ha anulado la factura")
def Correo(correo):
    for elmento in correo:
        if elmento=="@":
            return True
    return False
#codigos clases secundarias###################################################################################################################################################
###################################################################################################################################################
    
class Objetos:
            
            
          def __init__(self,nombreprovedor,provedor,precioU,cantidad,producto,cat,produ):
              self.provedor=nombreprovedor
              self.codigoPV=provedor
              self.precio=precioU
              self.cantidad=cantidad
              self.producto=producto
              self.categoria=cat
              
              self.detalles=produ#tiene matriz de productos y detalles  de los mismos
                           
class Facturacion:
   codigo=1
   def __init__(self,cat,total,subtotal,iva,detalles,codigocliente,cliente):
        fecha = datetime.datetime.now().strftime("%d/%m/%Y")
        self.fecha=str(fecha)
        self.total=total
        self.subtotal=subtotal
        self.iva=iva
        self.caracteristicas=detalles
        self.codigoCL=codigocliente
        self.nombre=cliente
        self.codigoFC=Facturacion.codigo
        self.codigocat=cat
        Facturacion.codigo+=1

class Ordencompra:
    codigoCompra=1
    def __init__(self,cdprovedor,provedor,subtotal,iva,total,categoria,lista):
   
        fecha = datetime.datetime.now().strftime("%d/%m/%Y")
        self.fecha=str(fecha)
        self.provedor=provedor
        self.codigoPV=str(cdprovedor)
        
        self.subtotal=str(subtotal)
        self.iva=str(iva)
        self.total=str(total)
        self.codigocat=categoria
        self.caracteristicas=lista
        self.codigo=Ordencompra.codigoCompra
        Ordencompra.codigoCompra+=1
          
class Provedor:
    codigo=1
    def __init__(self,cedula,empresa,telefono,correo):
         self.nombre=empresa
         self.cedula=str(cedula)
         self.telefono=str(telefono)
         self.correo=correo
         self.codigoPV=str(Provedor.codigo)
         Provedor.codigo+=1
class Cliente:
     ContCL=1
     def __init__(self,nombre,apellido1,apellido2,telefono,cedula,provincia,email):
         self.nombre=nombre
         self.apellidos=apellido1
         self.apellido2=apellido2
         self.telefono=telefono
         self.provicia=provincia 
         self.correo=email
         self.cedula=cedula
         self.codigoCL=str(Cliente.ContCL)
         Cliente.ContCL+=1
         
class Categoria:
    codecat=0
    def __init__(self,Nombre):
        Categoria.codecat+=1
        codigo=Categoria.codecat
        self.categoria=Nombre
        self.codigocat=str(codigo)
    
class Productos:
    codigoPD=1
    def __init__(self,codigoPV,codigocat,precioU,nombre,cantidad,code):
        self.nombre=str(nombre)
        self.codigocat=code
        self.nombrecat=codigocat
        self.codigoPV=codigoPV
        self.precio=precioU
        self.codigoPD=str(Productos.codigoPD)
        self.cantidad=cantidad
        Productos.codigoPD+=1


inicio = Administración()
inicio.crearcat("Bebida")
inicio.crearcat("lacteos")
inicio.crearcat("Fruta")
inicio.crearcliente("Elder","leon","perez",719502012,703080520,"Limon","Elder")
inicio.crearProvedor("777777777","cocacola",27634740,"gelp@gg")
inicio.crearProducto("PAPA","1","1",100)
inicio.crearProducto("coca","1","1",200)
inicio.crearProducto("Arroz","1","1",500)
inicio.Ordenesdecompra(1,100,5,"PAPA")
inicio.ordenescompraaux()
inicio.Ordenesdecompra(1,100,5,"coca")
inicio.ordenescompraaux()
inicio.facturar(1,"PAPA",5)
inicio.facturar(1,"coca",2)
inicio.finalizarfactura()



mensajes=True