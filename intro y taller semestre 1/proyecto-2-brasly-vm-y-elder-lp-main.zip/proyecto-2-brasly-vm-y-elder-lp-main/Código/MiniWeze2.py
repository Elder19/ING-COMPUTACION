from tkinter import *
from tkinter import messagebox as mb
import tkinter as tk
import csv
from tkinter import ttk
#ventana principal___________________________________________________
ventana = Tk()
ventana.title("registro")
ventana.geometry("400x250")
ventana.resizable(False, False)
ventana.config(bg="MediumPurple1")
#globales______________________________________________________
usuario=""
Usuario=""
matriz=[]

IconoWaze=tk.PhotoImage(file="waze5.png")
fondodecrear = tk.PhotoImage(file="fondo1.png")
abajo=tk.PhotoImage(file="abajo.png")
arriba= tk.PhotoImage(file="arriba.png")
cruce= tk.PhotoImage(file="cruce.png")
izquierda=tk.PhotoImage(file="izquierda.png")
derecha=tk.PhotoImage(file="derecha.png")
cuadra=tk.PhotoImage(file="cuadra.png")
horizontal=tk.PhotoImage(file="di.png")
verticales=tk.PhotoImage(file="N,S.png")
city=tk.PhotoImage(file="city1.png")
iconoflag=tk.PhotoImage(file="flag.png")
hospital=tk.PhotoImage(file="hospitall.png")
parque=tk.PhotoImage(file="parque.png")
notransito=tk.PhotoImage(file="notransitar.png")
deportes=tk.PhotoImage(file="gym.png")
colegios=tk.PhotoImage(file="escuelas.png")
zonaf=tk.PhotoImage(file="empresas.png")


#cambio de color__________________________________________
def cambiar_color(event):
    label.configure(activebackground="MediumPurple1")

#verificador de usuaruio__________________________________________
def comparar():
    global usuario

    archivo = open("Usuario.txt", mode= "r")
    leer = archivo.readlines()
    archivo.close()
    lista=[]
    usuario2 = txt1.get()
    usuario2 =str(usuario2)
    usuario= usuario2
    contraseña = txt2.get()
    contraseña =str(contraseña)
    
    
    
    for line in leer:
        lista = line.split(";")
        if lista[0] == usuario2:
            if lista[1][0:4] == contraseña:
                usuario=usuario2

                return menu()
    mb.showwarning(title="Error", message="usuario o contraseña incorrecta ")
#menu___________________________________________
def menu():
    menu = Tk()
    menu.title="Menu"
    menu.geometry("400x400")
    menu.config(bg="MediumPurple1")
    menu.resizable(False, False)
    def destruir():
        menu.destroy()
        ventana.destroy()


    btn1=Button(menu,text="Cargar mapa ",command=Cargarmapa)
    btn2=Button(menu,text="Seleccionar destino ")
    btn7=Button(menu,text="Planificar destino")
    btn3=Button(menu,text="Guardar destino ",command=guardardestino )
    btn4=Button(menu,text="Borrar destino",command=eliminardestino )
    btn5=Button(menu,text="Modificar mapa",command=modificarmapas )
    btn6=Button(menu,text="Salir ", command=destruir)

    btn1.place(x=125,y=50,width=150, height=30)
    btn2.place(x=125,y=100,width=150, height=30)
    btn7.place(x=125,y=150,width=150, height=30)
    btn3.place(x=125,y=200,width=150, height=30)
    btn4.place(x=125,y=250,width=150, height=30)
    btn5.place(x=125,y=300, width=150, height=30)
    btn6.place(x=125,y=350, width=150, height=30)

    menu.mainloop()
"""
Nombre:modificar mapas
entrada: matriz
salida: modificacion
Restriccion: La matriz no puede ser vacia
"""

def modificarmapas():
    global matriz
    global Usuario
    if Usuario == "":
        return mb.showwarning(title="Error", message="debes cargar un mapa primeramente")
    
    matriz=leerCSV(Usuario)
    
    matriz2=matriz
    cont=-1
    
    cargarmapa = Toplevel()
    cargarmapa.geometry("875x595")
    cargarmapa.resizable(False, False)
    negro = tk.Label(cargarmapa,bg="gray25")
    negro .place(x=0,y=0,width=665, height=820)
    morado = tk.Label(cargarmapa,bg="MediumPurple1")
    morado .place(x=665,y=0,width=665, height=820)
    city1 = tk.Label(cargarmapa,image=city,bg="MediumPurple1")
    city1 .place(x=675,y=100)     
    
    for y in range(len(matriz2)):#   vactores
        cont+=1
        cont2=-1
        for x in range(len(matriz2[0])):#COLUNMA}
           
            cont2+=1
            contenido=""
            contenido=matriz2[cont][cont2]
            if (contenido=="O"):
                button = tk.Button(cargarmapa, image=cuadra,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="F"):
                button = tk.Button(cargarmapa, image=iconoflag,borderwidth=0)
            elif (contenido=="S"):
                button = tk.Button(cargarmapa, image=abajo,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="N"):
                button = tk.Button(cargarmapa, image=arriba,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="C"):
                button = tk.Button(cargarmapa, image=cruce,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="L"):
                button = tk.Button(cargarmapa, image=izquierda,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="R"):
                button = tk.Button(cargarmapa, image=derecha,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="ND"):
                button['command'] = lambda arg=button:on_click(arg)       
                button = tk.Button(cargarmapa, image=verticales,borderwidth=0)
                 
            elif (contenido=="P"):
                button = tk.Button(cargarmapa, image=parque,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="E"):
                button = tk.Button(cargarmapa, image=colegios,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="H"):
                button = tk.Button(cargarmapa, image=hospital,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="Z"):
                button = tk.Button(cargarmapa, image=deportes,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="B"):
                button = tk.Button(cargarmapa, image=notransito,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)       
            elif (contenido=="T"):
                button = tk.Button(cargarmapa, image=zonaf,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)       
                    
            else: 
                button = tk.Button(cargarmapa, image=horizontal,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            button.grid(row=y, column=x)
            
            
  
            def on_click(widget):
                    global matriz
                    mitupla=("pyimage9","pyimage10","pyimage3","pyimage4","pyimage5","pyimage12")
                    tupla2=("pyimage13","pyimage14","pyimage15","pyimage16","pyimage17","pyimage18","pyimage8")
                    if widget["image"]=="pyimage15":
                        mb.showwarning(title="Error", message="Para eliminar un bloqueo debe hacerlo en la opcion (eliminar bloqueo).")
                        return""
                    for elemento in tupla2:
                        if  widget["image"]==elemento:
                            return parte(widget)# cambia a los extras
                        
                    for elemento in mitupla:
                        if  widget["image"]==elemento:
                            return parte3(widget)#pone el bloqueo de calle
            def escribir(datos):

                # Ruta y nombre del archivo CSV
                archivo_csv = Usuario
                with open(archivo_csv, 'w', newline='') as archivo:
                    archivo.write("")
                    archivo.close()           
                  
                with open(archivo_csv, 'w', newline='') as archivo:
                   
                    for fila in datos:
                        for celda in fila:
                            linea_csv= str(celda) 
                            archivo.write(linea_csv)
                            archivo.write(" ")
                        archivo.write("\n")
            def parte3(widget):  
                global matriz
                if widget["image"]=="pyimage1":
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"B")
                        widget["image"]=notransito # SUR
                elif widget["image"]=="pyimage2":
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"B")
                        widget["image"]=notransito # SUR 
                elif widget["image"]=="pyimage3":
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"B")
                        widget["image"]=notransito # SUR 
                                
                elif widget["image"]=="pyimage4":
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"B")
                        widget["image"]=notransito # SUR 
                elif widget["image"]=="pyimage5":
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"B")
                        widget["image"]=notransito # SUR 
                elif widget["image"]=="pyimage7":
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"B")
                        widget["image"]=notransito # SUR 
                     
                escribir(nmatriz)           
                matriz=nmatriz                  
            def parte(widget):
                global matriz
               
               
                       
                if widget["image"]=="pyimage8":
                    widget["image"]=parque# CUADRA
                    numero=extrae(widget,10)
                    nmatriz=change(numero,matriz,"P")
                        
                        
                elif widget["image"]=="pyimage13":
                    widget["image"]=colegios # ESTE
                    numero=extrae(widget,10)
                    nmatriz=change(numero,matriz,"E")
                            
                                
                                
                elif widget["image"]=="pyimage14":
                    widget["image"]=hospital #OESTE
                    numero=extrae(widget,10)
                    nmatriz=change(numero,matriz,"H")        
                            
                elif widget["image"]=="pyimage17":
                    widget["image"]=deportes # DOBLE SENTIDO NS
                    numero=extrae(widget,10)
                    nmatriz=change(numero,matriz,"Z")      
                             
                elif widget["image"]=="pyimage18":
                    widget["image"]=cuadra # DOBLE SENTIDO NS
                    numero=extrae(widget,10)
                    nmatriz=change(numero,matriz,"O")        
                else:# widget["image"]=="pyimage16":
                    widget["image"]=zonaf# CUADRA
                    numero=extrae(widget,10)
                    nmatriz=change(numero,matriz,"T")
                escribir(nmatriz)
               
                matriz=nmatriz    
        def change(num,matrizz,parametro):# PARAMETRO ES EL VALOR DE UNA CASA O LO QUE SEA, NUM VIENE DE DEF EXTRAE
            global matriz
            matriz=[]
            contador=-1 
            pos=0
            nmatriz=[]
            vec=1
            for elemento in matrizz:
                contador=-1# SE NECESITA ASI PARA QUE EL PRIMERO SEA 0
                        
                for caracter in elemento:
                            
                    if pos==num and vec!=0: # son contadores se ubican las posiciones por contador hasta que pos==botton num
                        contador+=1
                        long=len(elemento)
                        pos+=1
                        vec=0
                        if contador==long:# es para que no de index error
                            contador-=1
                        elemento[contador]=parametro
                                
                    else:
                        pos+=1
                        contador+=1
                                
                        continue
                        
                nmatriz+=[elemento]
                
                
            return nmatriz                   
                    
          
                    
    
    guardar= Button(cargarmapa,text="Guardar",command=cargarmapa.destroy)
    guardar.place(x=725,y=350, width=100, height=30)
                
    cargarmapa.mainloop()                

# eliminar destino---------------------------------------

def extraedest(wid,n):# n== numero de vectores
    global matriz
    
    wid=str(wid)# Wid es el botton que se preciona
    if wid==".!toplevel.!button":
        return 0 
    elif wid==".!toplevel.!button1":
        return 1            
    wid=wid[11:]
    num=0           
    for elemento in wid:
        x=elemento 
        try:
           
           x=int(x)
           num=num*10+x
        except: 
            continue

    return num-1# si se deja positivo se mueve una columna de mas
def leerCSV(nombre):
        global matriz
        global Usuario
        
        archivo_csv = Usuario
        with open(archivo_csv, 'r') as archivo:
            lector_csv =csv.reader(archivo)

            # Lee los datos línea por línea
            for linea in lector_csv: 
                    
                linea=linea[0]
                linea= linea.split(" ")
                matriz+=[linea[:-1]]
            return matriz
              
def change(num,matrizz,parametro):# PARAMETRO ES EL VALOR DE UNA CASA O LO QUE SEA, NUM VIENE DE DEF EXTRAE
        global matriz
        matriz=[]
        contador=-1 
        pos=0
        nmatriz=[]
        vec=1
        for elemento in matrizz:
            contador=-1# SE NECESITA ASI PARA QUE EL PRIMERO SEA 0
                    
            for caracter in elemento:
                        
                if pos==num and vec!=0: # son contadores se ubican las posiciones por contador hasta que pos==botton num
                    contador+=1
                    long=len(elemento)
                    pos+=1
                    vec=0
                    if contador==long:# es para que no de index error
                        contador-=1
                    elemento[contador]=parametro
                            
                else:
                    pos+=1
                    contador+=1
                            
                    continue
                    
            nmatriz+=[elemento]
            
              
        return nmatriz
"""
Nombre:eliminardestino
entrada: matriz,usuario
salida: modificacion de mapas
Restriccion: La matriz no puede ser vacia
"""   
def eliminardestino():
    global Usuario
    global matriz
    if Usuario == "":
        return mb.showwarning(title="Error", message="debes cargar un mapa primeramente")
    matriz=leerCSV(Usuario)
    matriz2=matriz
    
    if not matriz2!=[]:
        mb.showwarning(title="Error", message="ERROR: Asegurese de haber creado un mapa!!")
        return""# esto evita que abra la ventana vacia
    else:
        return eliminardestino2(matriz2)
def eliminardestino2(matriz2):
   
    global matriz
    global Usuario
    
    cargarmapa = Toplevel()
    cargarmapa.geometry("875x595")
    cargarmapa.resizable(False, False)
    negro = tk.Label(cargarmapa,bg="gray25")
    negro .place(x=0,y=0,width=665, height=820)
    morado = tk.Label(cargarmapa,bg="MediumPurple1")
    morado .place(x=665,y=0,width=665, height=820)
    city1 = tk.Label(cargarmapa,image=city,bg="MediumPurple1")
    city1 .place(x=675,y=100)    
    
    cont=-1
    
    for y in range(len(matriz2)):#   vactores
        cont+=1
        cont2=-1
        for x in range(len(matriz2[0])):#COLUNMA}
           
            cont2+=1
            contenido=""
            contenido=matriz2[cont][cont2]
            if (contenido=="O"):
                button = tk.Button(cargarmapa, image=cuadra,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
            elif (contenido=="F"):
                button = tk.Button(cargarmapa, image=iconoflag,borderwidth=0)
                button['command'] = lambda arg=button:on_click(arg)
                
            elif (contenido=="S"):
                button = tk.Button(cargarmapa, image=abajo,borderwidth=0)
                
            elif (contenido=="N"):
                button = tk.Button(cargarmapa, image=arriba,borderwidth=0)
                
            elif (contenido=="C"):
                button = tk.Button(cargarmapa, image=cruce,borderwidth=0)
            
            elif (contenido=="L"):
                button = tk.Button(cargarmapa, image=izquierda,borderwidth=0)
        
            elif (contenido=="R"):
                button = tk.Button(cargarmapa, image=derecha,borderwidth=0)
        
            elif (contenido=="ND"):
                    
                button = tk.Button(cargarmapa, image=verticales,borderwidth=0)
            
            else: #DI Sin direccion derecha izquierda
                button = tk.Button(cargarmapa, image=horizontal,borderwidth=0)
            button.grid(row=y, column=x)
  
            def on_click(widget):
                numero=0
                global matriz
                
                if widget["image"]=="pyimage12":
                        widget["image"]=cuadra #OESTE
                        numero=extraedest(widget,10)
                   
                        nueva=change(numero,matriz,"O")
                        escribir(nueva)
                        matriz=leerCSV(Usuario)
                        
                elif widget["image"]!="pyimage12":
                    mb.showwarning(title="Error", message="Solo es posible eliminar los destinos previamente establecidos. ")
               
            def escribir(datos):
                global Usuario

                # Ruta y nombre del archivo CSV
                archivo_csv = Usuario
                     
                  
                with open(archivo_csv, 'w', newline='') as archivo:
                   
                    for fila in datos:
                        for celda in fila:
                            linea_csv= str(celda) 
                            archivo.write(linea_csv)
                            archivo.write(" ")
                        archivo.write("\n")
                    
    
    guardar= Button(cargarmapa,text="Guardar",command=cargarmapa.destroy)
    guardar.place(x=725,y=350, width=100, height=30)
    cargarmapa.mainloop()        
# guardar destino----------------------------------------
"""
Nombre: guardardestino
entrada: matriz,usuario
salida: modificacion de mapas, y nuevas rutas guardadas
Restriccion: La matriz no puede ser vacia
"""      
def guardardestino():
    global Usuario
    global matriz
    if Usuario == "":
        return mb.showwarning(title="Error", message="debes cargar un mapa primeramente")
    print(usuario)
    matriz2=matriz# lee el cs
   
    cargarmapas = tk.Toplevel()
    cargarmapas.geometry("875x595")
    cargarmapas.resizable(False, False)
    negro = tk.Label(cargarmapas,bg="gray25")
    negro .place(x=0,y=0,width=665, height=820)
    morado = tk.Label(cargarmapas,bg="MediumPurple1")
    morado .place(x=665,y=0,width=665, height=820)
    city1 = tk.Label(cargarmapas,image=city,bg="MediumPurple1")
    city1 .place(x=675,y=100)
    cont=-1
    for y in range(len(matriz2)):#   vactores
        cont+=1
        cont2=-1
        for x in range(len(matriz2[0])):#COLUNMA
            cont2+=1
            contenido=""
            contenido=matriz2[cont][cont2]
           
            if (contenido=="O"):
                button = tk.Button(cargarmapas, image=cuadra,borderwidth=0)
                button['command'] =lambda arg=button:on_click(arg)
                button.grid(row=y, column=x)
            elif (contenido=="F"):
                button = tk.Button(cargarmapas, image=iconoflag,borderwidth=0)
                button['command'] =lambda arg=button:on_click(arg)
                button.grid(row=y, column=x)
                
                
            elif (contenido=="S"):
                button = tk.Button(cargarmapas, image=abajo,borderwidth=0)
                button.grid(row=y, column=x)
                
            elif (contenido=="N"):
                button = tk.Button(cargarmapas, image=arriba,borderwidth=0)
                button.grid(row=y, column=x)
                
            elif (contenido=="C"):
                button = tk.Button(cargarmapas, image=cruce,borderwidth=0)
                button.grid(row=y, column=x)
            
            elif (contenido=="L"):
                button = tk.Button(cargarmapas, image=izquierda,borderwidth=0)
                button.grid(row=y, column=x)
        
            elif (contenido=="R"):
                button = tk.Button(cargarmapas, image=derecha,borderwidth=0)
                button.grid(row=y, column=x)
        
            elif (contenido=="ND"):
                    
                button = tk.Button(cargarmapas, image=verticales,borderwidth=0)
                button.grid(row=y, column=x)
            
            else: #DI Sin direccion derecha izquierda
                button = tk.Button(cargarmapas, image=horizontal,borderwidth=0)
                button.grid(row=y, column=x)
            
            
            
            def on_click(widget):
            
                global matriz


                if widget["image"]=="pyimage8":
                        widget["image"]=iconoflag 
                        numero=extrae(widget,10)
                        xmatriz=change(numero,matriz,"F")
                        
                        
                else: 
                    widget["image"]=cuadra
                    numero=extrae(widget,10)
                    xmatriz=change(numero,matriz,"O")
                escribir(xmatriz)
                matriz=xmatriz
                     
    guardar= Button(cargarmapas,text="Guardar",command=cargarmapas.destroy)
    guardar.place(x=725,y=350, width=100, height=30)       
    cargarmapas.mainloop()
def escribir(datos):
    global Usuario

    # Ruta y nombre del archivo CSV
    archivo_csv = Usuario
    archivo_csv+=".csv"
    with open(archivo_csv, 'w', newline='') as archivo:
        archivo.write("")
        archivo.close()        
        
    with open(archivo_csv, 'w', newline='') as archivo:
        for fila in datos:
            for celda in fila:
                linea_csv= str(celda) 
                archivo.write(linea_csv)
                archivo.write(" ")
            archivo.write("\n")
       
       
            
            
def leerCSV(nombre):
        global matriz
        
        archivo_csv = nombre
        with open(archivo_csv, 'r') as archivo:
            lector_csv =csv.reader(archivo)

            # Lee los datos línea por línea
            for linea in lector_csv:
                    
                linea=linea[0]
                linea= linea.split(" ")
                matriz+=[linea[:-1]]
            #matriz=matriz
         
            return matriz
def extrae(wid,n):# n== numero de vectores
                wid=str(wid)# Wid es el botton que se preciona
                
                wid=wid[11:]
            
                if wid==".!button2":
                   
                    return 0
                num=0
                
                for elemento in wid:
                    x=elemento 
                    try:
                        x=int(x)
                        num=num*10+x
                    except: 
                        continue
              
                return num-1 # si se deja positivo se mueve una columna de mas
            
def change(num,matrizz,parametro):# PARAMETRO ES EL VALOR DE UNA CASA O LO QUE SEA, NUM VIENE DE DEF EXTRAE
                global matriz
                matriz=[]
                contador=-1 
                pos=0
                nmatriz=[]
                vec=1
                for elemento in matrizz:
                    contador=-1# SE NECESITA ASI PARA QUE EL PRIMERO SEA 0
                    
                    for caracter in elemento:
                        
                        if pos==num and vec!=0: # son contadores se ubican las posiciones por contador hasta que pos==botton num
                            contador+=1
                            long=len(elemento)
                            pos+=1
                            vec=0
                            if contador==long:# es para que no de index error
                                contador-=1
                            elemento[contador]=parametro
                            
                        else:
                            pos+=1
                            contador+=1
                            
                            continue
                    
                    nmatriz+=[elemento]
            
              
                return nmatriz     
# cargarMapa ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""
Nombre: Cargarmapa
entrada: seleccion de un csv
salida: matriz global es igual a lo que se leyo
Restriccion: debe existir el csv
"""      
def Cargarmapa():
    cargar = Tk()
    cargar.title=("Cargar")
    cargar.geometry("400x250")
    cargar.config(bg="MediumPurple1")
    cargar.resizable(False, False)
    
        #------------------------------------------------------------------------------------------------------------------------------   
        #SE USAN PARA CARGAR A LA GLOBAL UN CSV   
    def escribir(datos):
                # Ruta y nombre del archivo CSV
                archivo_csv = Usuario
                archivo_csv+=".csv"
                with open(archivo_csv, 'w', newline='') as archivo:
                    archivo.write("")
                    archivo.close()        
                    
                with open(archivo_csv, 'w', newline='') as archivo:
                    for fila in datos:
                        for celda in fila:
                            linea_csv= str(celda) 
                            archivo.write(linea_csv)
                            archivo.write(" ")
                        archivo.write("\n")
    def leerCSV(nombre):
            global matriz
                
            archivo_csv = nombre
            with open(archivo_csv, 'r') as archivo:
                lector_csv =csv.reader(archivo)

                # Lee los datos línea por línea
                for linea in lector_csv:
                        
                    linea=linea[0]
                    linea= linea.split(" ")
                    matriz+=[linea[:-1]]
                #matriz=matriz
                return matriz
            
                
    def mostrarCSV():# esta funcion solamente se encarga de mostrar al usuario una representacion grafica de el mapa cargado
        window = Tk()
        window.title("cargar")
        window.geometry("400x150")
        window.resizable(False, False)
        window.config(bg="MediumPurple1")
        global Usuario

        def mapaEscoger():
            global usuario
            archivo =open("Mapas.txt", mode= "r")
            lineas = archivo.readlines()
            
            archivo.close()
            for linea in lineas:
                lista = linea.split(",")
                if lista[0]==usuario:
                    lista=lista[1:]
                    lista= [elemento.strip() for elemento in lista]
                    
                    return lista

        def obtener_valor():
            global Usuario
            valor = combobox.get()
            Usuario=valor
            print(Usuario)
         
            window.destroy()
            

        opciones = mapaEscoger()

        combobox = ttk.Combobox(window, values=opciones)
        combobox.pack(pady=10)
                                                                                                                                          
        obtener_valor = tk.Button(window, text="cargar", command=obtener_valor)
        obtener_valor.pack(pady=10)

        window.mainloop()
    def crear():
        
        crear2 = tk.Toplevel()
        crear2.title("Creaccion")
        crear2.geometry("400x250")
        crear2.resizable(False, False)
        label = tk.Label(crear2, image =fondodecrear, bd=0)
        label.pack()
        espacioX=Entry(crear2,borderwidth=0)
        espacioX.place(x=155,y=125,width=40, height=15)
        espacioY=Entry(crear2,borderwidth=0)
        espacioY.place(x=155,y=180,width=40, height=15)
        def agregaraltxt():
            global usuario
            archivo =open("Mapas.txt", mode= "r")
            lineas = archivo.readlines()
            archivo.close()
            largo=largoLetra(usuario)
            for linea in lineas:
                lista = linea.split(",")
                if lista[0]==usuario:
                    x=lista[-1][largo:]
                    x=int(x)
                    x+=1
                    x=str(x)
                    archivo =open("Mapas.txt", mode= "r")
                    leer = archivo.readlines()
                    archivo.close()
                    y=rest()
                    for usuarios in leer:
                        mapas = usuarios.split(",")
                        if mapas[0]==usuario:
                            ultimos=mapas[-1][:-1] 
                            mapas=mapas[:-1]
                            mapas+=[ultimos]
                            agregar=usuario+x+"\n"
                            mapas+=[agregar]
                        escribir=(escribirMapas(mapas))
                        
                    
                    
                else:
                    continue
            usuarionuevo=agregar[:-1]
            return usuarionuevo

        # escribe todo de nuevo a la lista
        def escribirMapas(lista):
            archivo=open("Mapas.txt", mode= "a")
            contador=0
            for elemento in lista:
                if contador==0:
                    contador+=1
                    archivo.write(elemento)
                else:
                    archivo.write(",")
                    archivo.write(elemento)
            archivo.close()
            return ("")
        # resetea la lista
        def rest():
            nombreArchivo="Mapas.txt"
            if (isinstance(nombreArchivo,str)):
                if (nombreArchivo!=""):
                    archivo=open (nombreArchivo,mode="w" )
                    #archivo.write(codigo)
                    archivo.write("")
                    archivo.close()
        #un largostr
        def largoLetra(palabra):
            contador=0
            for elemento in palabra:
                contador+=1
            return contador
        
        #______________________________
        def creacciondematriz(): # maximo 27*30

            largoV=espacioX.get()
            anchoC=espacioY.get()
            try:
                largoV=int(largoV)
                anchoC=int(anchoC)
            except:
                mb.showwarning(title="Error", message="Los diametros deben ser numeros mayores a 0")
            if  largoV < 10:
                return mb.showwarning(title="Error", message="El largo y el ancho deben ser mayor a 10")
            elif  anchoC< 10:
                return mb.showwarning(title="Error", message="El largo y el ancho deben ser mayor a 10")
            elif anchoC>30:
                return mb.showwarning(title="Error", message="el ancho exede el diametro de 30")
            elif largoV>27:
                return mb.showwarning(title="Error", message="el largo exede el diametro de 27")

            crear2.destroy()
            global matriz
            global Usuario
            escribir=agregaraltxt()
            Usuario=escribir
            


            root = tk.Toplevel()
            root.geometry("875x595")
            root.resizable(False, False)
            negro = tk.Label(root,bg="gray25")
            negro .place(x=0,y=0,width=665, height=820)
            morado = tk.Label(root,bg="MediumPurple1")
            morado .place(x=665,y=0,width=665, height=820)
            city1 = tk.Label(root,image=city,bg="MediumPurple1")
            city1 .place(x=675,y=100)
            
            
        # --- main ---
            cont=-1
            
            for y in range(largoV):#   vectores
                matriz+=[[]]# gerera l matriiz 
                cont+=1
                for x in range(anchoC):#COLUNMA
                    
                    matriz[cont]+=["O"]
                
                    button = tk.Button(root, image=cuadra,borderwidth=0,bg="gray3")
                    button['command'] = lambda arg=button:on_click(arg)
                    button.grid(row=y, column=x)
                    
                """ 
                nombre on click 
                se encarga de cambiar el aspecto en la interfaz y envia los valores para editar matriz
                """
                def on_click(widget):
                    global matriz
                    if widget["image"]=="pyimage8":
    
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"S")
                        widget["image"]=abajo # SUR
                            
                    elif widget["image"]=="pyimage3":
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"N")
                        widget["image"]=arriba  #NORTE
                        
                    elif widget["image"]=="pyimage4":
                        widget["image"]=cruce # CRUCE
                        numero=extrae(widget,10)
                        
                        nmatriz=change(numero,matriz,"C")
                        
                        
                    elif widget["image"]=="pyimage5":
                        widget["image"]=izquierda # ESTE
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"L")    
                        
                        
                    elif widget["image"]=="pyimage6":
                        widget["image"]=derecha #OESTE
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"R")        
                    
                    elif widget["image"]=="pyimage7":
                        widget["image"]=horizontal # DOBLE SENTIDO NS
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"DI")   
                    
                    elif widget["image"]=="pyimage9":
                        widget["image"]=verticales # DOBLE SENTIDO EO
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"NS")    
                    
                    else:
                        widget["image"]=cuadra# CUADRA
                        numero=extrae(widget,10)
                        nmatriz=change(numero,matriz,"O")
                   
                    matriz=nmatriz
                    escribir(matriz)
                # Datos que se van a escribir en el archivo CSV
                
            def escribir(datos):
                global Usuario

                # Ruta y nombre del archivo CSV
                archivo_csv = Usuario
                with open(archivo_csv, 'w', newline='') as archivo:
                    for fila in datos:
                        for celda in fila:
                            linea_csv= str(celda) 
                            archivo.write(linea_csv)
                            archivo.write(" ")
                        archivo.write("\n")
                
            """se encarga de el numero de botton para poder editar la matriz
            """
            def extrae(wid,n):# n== numero de vectores
                wid=str(wid)# Wid es el botton que se preciona
                
                wid=wid[11:]
            
                if wid==".!button2":
                    
                    return 0
                num=0
                
                for elemento in wid:
                    x=elemento 
                    try:
                        x=int(x)
                        num=num*10+x
                    except: 
                        continue
          
                return num-2 # si se deja positivo se mueve una columna de mas
            

            def largo(n):
                cont=0
                for elemento in n:
                    cont+=1
                
                return cont
                """
                nombre:change
                se encarga de cambiar los valores en matriz
                """
            def change(num,matrizz,parametro):# PARAMETRO ES EL VALOR DE UNA CASA O LO QUE SEA, NUM VIENE DE DEF EXTRAE
                global matriz
                matriz=[]
              
                contador=-1 
                pos=0
                nmatriz=[]
                vec=1
                for elemento in matrizz:
                    contador=-1# SE NECESITA ASI PARA QUE EL PRIMERO SEA 0
                    
                    for caracter in elemento:
                        
                        if pos==num and vec!=0: # son contadores se ubican las posiciones por contador hasta que pos==botton num
                            contador+=1
                            long=largo(elemento)
                            pos+=1
                            vec=0
                            if contador==long:# es para que no de index error
                                contador-=1
                            elemento[contador]=parametro
                            
                        else:
                            pos+=1
                            contador+=1
                            
                            continue
                    
                    nmatriz+=[elemento]
                long=largo(nmatriz)
              
             
                return nmatriz
            def destruir_ventana():
                root.destroy()
            guardar= Button(root,text="Guardar",command=destruir_ventana)
            guardar.place(x=725,y=350, width=100, height=30)
                
            root.mainloop()
            
        crearbutton=Button(crear2,text="crear",command=creacciondematriz)
        crearbutton.place(x=250,y=175,width=100, height=30)
        crear2.mainloop()
    
    btn1=Button(cargar,text="crear mapa", command=crear )
    btn2=Button(cargar,text="cargar mapa", command= mostrarCSV)
    btn3=Button(cargar,text="Salir ", command=cargar.destroy)

    btn1.place(x=125,y=50,width=150, height=30)
    btn2.place(x=125,y=100,width=150, height=30)
    btn3.place(x=125,y=150,width=150, height=30)
    cargar.mainloop()
#CREAR Mapa______________________________________________________


#BOTONESS__________________________________________________________________________________
label =Button(ventana, image=IconoWaze,command=comparar, bg="MediumPurple1",borderwidth=0)
label.bind('<Button-1>', cambiar_color)  # Vincula el evento 'Button-1' (clic izquierdo) a la función 'cambiar_color'
label.place(x=250, y=75)

inicio=Label(ventana,text="Iniciar Sesión",bg="MediumPurple1",font=("Verdana",12,"italic"))
inicio.place(x=20,y=30,width=120, height=30)

espa1=Label(ventana,text="Usuario:",bg="MediumPurple1")
espa1.place(x=20,y=90,width=80, height=15)
espa1.config(font=("Verdana",9,"italic"))

raya=Label(ventana,text="______________",bg="gray10")
raya.place(x=110,y=110,width=100, height=1)

txt1=Entry(ventana,relief=tk.SUNKEN,borderwidth=0)
txt1.config(bg="MediumPurple1",font=("Arial", 8))
txt1.place(x=110,y=80,width=100, height=30)

espa2=Label(ventana,text="Contraseña:",bg="MediumPurple1")
espa2.place(x=20,y=150,width=80, height=20)
espa2.config(font=("Verdana",9,"italic"))

raya=Label(ventana,text="______________",bg="gray10")
raya.place(x=110,y=170,width=100, height=1)

txt2=Entry(ventana, show="*",relief=tk.SUNKEN,borderwidth=0)
txt2.config(bg="MediumPurple1")
txt2.place(x=110,y=140,width=100, height=30)

ventana.mainloop()

