
"""
Nombre Menú Principal
Funcion: imprime "Bienvenidos a su punto de ventas"
a la hora de iniciciar el programa, y retorna la funcion de menu
"""

import datetime
def menú():
       
       txt="Bienvenidos a su punto de ventas"
   
       print("------------------------------------------")
       print(txt)
       print("------------------------------------------")
       return menu()

"""
Nombre menu
Funcion: indica las funciones disponibles
Entrada: pregunta la opcion que el usuaro desee usar
Restriccion: Que la opcion no sea vacia
"""
     
def menu():
         txtmenu="""Menu de actividades   

       (I) Inventario            
       (F) Facturar              
       (R) Reportes              
       (S) Salir          
       """
        
         txtmenu=txtmenu.center(10)
         print("------------------------------------------")
         print(txtmenu)
         print("------------------------------------------")   
         opcion=input("Digite una de las opciones anteriores: ")
         opcion=opcion.upper()
         
                
        
         if opcion!="":
            if opcion=="I":
                    return GestióndeInventarios()
            if opcion=="F":
                    return Facturar()
            if opcion=="R":
                    return Reportes()
            if opcion=="S":
                    return Salir()
            else:
                  print("*****Debe ingresar una opcion valida****" )
                  return menú()
        
         else:
                print( "***Error: Debe digitar una opcion***")
                return menú()

"""
Nombre: Gestion de inventarios
Funcion: analiza el acceso de usuarios y muestra el menu correspondiente
Entradas, usuario y clave de acceso
Restricciones: que las opciones no sean vacias
"""

def GestióndeInventarios():
        txt="""
        (A) Agregar producto 
        (M) Modificar producto 
        (B) Borrar producto 
        (I) Agregar inventario 
        (R) Reporte de productos 
        (S) Salir
                                    
         """
        contador=0
        contraseñas=[]
        bienvenida="Gestion de inventarios"
       
      
        print("------------------------------------------") 
        print(bienvenida)
        print("------------------------------------------") 
       
        acceso=input("digite su usuario: ")
        clave=input("Digite su clave de acceso: ")
        clavesdeaccceso=leerArchivox("Acceso.txt")
        #clavesdeaccceso=clavesdeaccceso.split("\n")
        if clave!="":
              if acceso!="":
                for linea in clavesdeaccceso:
                        if contador==2:
                               continue
                        contraseñas+= [linea.split(" ")]
                        for caracter in contraseñas:
                                
                                if contador<=2:
                                    if caracter[0]==acceso:
                                        contador+=1
                                        if caracter[1]==clave:
                                                contador+=1
                                        else:
                                               contador=0
                                    else:
                                           contador=0
                                           continue
    
                if contador==2:
                             print("------------------------------------------") 
                             print(txt)
                             print("------------------------------------------")
                             opcion=input("Digite una de las opcionesa anteriores: ")
                             if opcion!="":
                                    opcion=opcion.upper()
                                    if opcion=="A":
                                          return Agregar_producto()
                                    if opcion=="M":
                                          return  Modificar_producto()
                                    if opcion=="B":
                                          return Borrar_producto()
                                    if opcion=="I":
                                          return  Agregar_inventario()
                                    if opcion =="R":
                                          return Reportes_productos()
                                    if opcion=="S":
                                          return Salir()
                                    else:
                                       print("*****Debe ingresar una opcion valida****" )
                                       return  GestióndeInventarios()
                             else:
                                   print("***Debe ingresar uno de los valores disponibles***")
                                   return GestióndeInventarios()
               
                                       
                                        
                else:
                                       
                     print("Error su contraseña o usuario no es correcta vuelva a intentarlo" )
                     return GestióndeInventarios()
                     
              else:
                    print( "Error: debe ingresar un nombre de usuario")
                    return GestióndeInventarios()
                     
        else:  
              print( "Error: debe ingresar una clave")
              return GestióndeInventarios()

            
"""
Nombre:Agregar producto
funcion: ingresa productos al inventario
Entradas: productos y caracteristicas
Restricciones:no debe repetirse el producto
"""
def  Agregar_producto():
    print("================================================")
    print("=           Agregar producto                   =")
    print("================================================")
    
    cantidad="0"
    codigo=gencod("Inventario.txt")
    barra="/"
    nombreproducto= input("Ingrese el nombre del producto: ")
    categoria =input("Ingrese la categoria correspondiente: ")
    preciounitario=input("Ingrese el precio de el producto: ")
    existencia=Buscanombre(nombreproducto,"inventario.txt")
    if existencia==1:
           print("El produto ya existe en el inventario")
           opcion=input("Digite (1) si desea agregar otro producto, (2) para salir al menu principal: ")
           if opcion!="":
              if opcion=="1":
                     return  Agregar_producto()
              if opcion=="2":
                     return  menú()
           else:
                  print("Debe ingresar una de las opciones validas")
                  return  Agregar_producto()
    else:
           try:
                  codigo=str(codigo)
           except:
                  ""
           
           if isinstance (codigo,str):
                 if nombreproducto!="":
                      if categoria!="":
                            if isinstance(preciounitario,str):
                                    Registraractividad_aux(codigo,nombreproducto,categoria, preciounitario,cantidad) #retorna codigo encargado de cargar la informacion
                                    opcion=input("Digite (1) si desea agregar otro producto, (2) para salir al menu principal: ")
                                    if opcion!="":
                                          if opcion=="1":
                                                 return  Agregar_producto()
                                          if opcion=="2":
                                                 return  menú()
                                    else:
                                           print("Debe ingresar un valor valido")
                                           return GestióndeInventarios()

                            else:
                                  print( "Error:debe ingresar caracteres numericos")
                                  return GestióndeInventarios()
                      else:
                            print( "Error:Debe ingresar una categoria ")
                            return GestióndeInventarios()
                 else:
                      print( "Error:debe ingresar un nombre de producto" )
                      return GestióndeInventarios()
                      
"""
Nombre: registrar actividad
Funcion:recoge la informacion y la ingresa al archivo ("Inventario.txt)
restricciones: infromacion no vacia

"""
def Registraractividad_aux(codigo,nombreproducto,categoria, preciounitario,cantidad):
       

    name= "Inventario.txt"
    codigo=codigo
    contenido=()
    mode="a"
  
    
    print ("Se esta ejecuntado el registro de la actividad")
    contenido=codigo,nombreproducto,categoria, preciounitario,cantidad#se vulve str en escribir archivo
    existencias=buscarporproducto(nombreproducto)
    print(codigo,nombreproducto,categoria,preciounitario,cantidad)
  

    if existencias==2:

       if (isinstance(name,str)):
              if (name!=""):
                     if(contenido!=""):
                            archivo=open (name,mode="a" )
                            archivo.write(codigo)

                            archivo.write(" ")
                            archivo.write(nombreproducto)
                            archivo.write(" ")
                            archivo.write(categoria)

                            archivo.write(" ")
                            archivo.write(preciounitario)

                            archivo.write(" ")
                            archivo.write(cantidad)
                            archivo.write(" \n")
                            
                            archivo.close()
       print ("El codigo de el producto es: ",codigo)
       opcion=input("Digite (1) si desea ingresar otro producto, (2) para salir al menu principal")
       if opcion!="":
              try:
                     opcion=int(opcion)
              except:
                     return"Hubo un error con la aplicacion por favor vuelva a intentar"
              if isinstance (opcion,int):
                     if opcion<=2 and opcion>0:

                            if opcion==1:
                                   return Agregar_producto()
                            if opcion==2:
                                  return  menú()        
    else:
          print("Este producto ya existe")
          opcion=input("Digite (1) si desea ingresar otro producto, (2) para salir al menu principal")
          if opcion!="":
              try:
                     opcion=int(opcion)
              except:
                     return"Hubo un error con la aplicacion por favor vuelva a intentar"
              if isinstance (opcion,int):
                     if opcion<=2 and opcion>0:

                            if opcion==1:
                                   return Agregar_producto()
                            if opcion==2:
                                  return  menú()     
"""
nombre:  Modificar_producto(
Funcion: recoge informacion y modifia el inventario segun el codigo de producto
Restricciones: informacion no vacia

"""
def Modificar_producto():
       
       print("================================================")
       print("=            Modificar producto                =")
       print("================================================")

       
       cantidad="0"
       nombre= "Inventario.txt"
       lista = []
       contador=0
   
       listaN= []
       nuevotxt=[]
       salto="\n"
      
       
       
              
       codigo=input("Digite el codigo de el mensaje que desea editar: ")
       texto= Buscacodigo(codigo,nombre)
     
       if texto==None:
            print("El codigo no se encuentra en el inventario")
            print()
            opcion= input("Digite (1) para volver al menu (2) para menu principal")
            if opcion!="":
                   if opcion=="1":
                         return  GestióndeInventarios()
                   if opcion=="2":
                         return menú()
       
       
       else: 
              
              print("A continuacion se muestra como se ve actualmente el producto en inventario")
              print (texto[0] ,texto[1], texto[2], texto[3], texto[4])
              #print(texto)
              print("Por favore ingrese las modificiaciones")

              nombreproducto= input("Ingrese el nombre del producto: ")
              categoria =input("Ingrese la categoria correspondiente: ")
              preciounitario=input("Ingrese el precio de el producto: ")
              
              if nombreproducto=="":
                     print("No puede ingresar caracteristicas vacias")
                     print()
                     return Modificar_producto()
              elif categoria=="":
                     print("No puede ingresar caracteristicas vacias")
                     print()
                     return Modificar_producto()
              elif preciounitario=="":
                     print("No puede ingresar caracteristicas vacias")
                     print()
                     return Modificar_producto()
         
              existencias=Buscanombre(nombreproducto,nombre)
              if existencias==0:

              
                     nombreArchivo= "Inventario.txt"
                     miLista=leerArchivox(nombreArchivo)
                     archivo=open(nombreArchivo,"w")
                     archivo.write("")
                     archivo.close
                     #Validar nombreArchivo no sea vacío
                     if(nombreArchivo != ""):
                            for linea in miLista:
                                   lista += [linea.split(" ")]
                                   if lista[contador][0] != codigo:
                                          listaN+=[lista[contador]]
                                   if lista[contador][0] == codigo:
                                          nuevotxt=[codigo,nombreproducto,categoria,preciounitario,cantidad,salto]
                                                               
                                                        
                                          listaN+=[ nuevotxt]
                                   contador += 1
                                                        
                                                        
                            for elemento in listaN:
                                   for palabra in elemento:
                                          escribirArchivoa(palabra,nombreArchivo)
                            opcion= input("Digite (1) para volver al menu (2) para menu principal")
                            
                            if opcion!="":
                               if opcion=="1":
                                    return  GestióndeInventarios()
                               if opcion=="2":
                                    return menú()
              else: 
                      print ("Error: no se puede ingresar su actualizacion debido a que ya existe en el inventario")
                      opcion= input("Digite (1) para volver al menu (2) para menu principal")
                            
                      if opcion!="":
                               if opcion=="1":
                                    return  GestióndeInventarios()
                               if opcion=="2":
                                    return menú()
                      else:
                                   return menú()
                        
"""
Nombre: Borrar producto
Entrada:codigo
Funcion:elimina la coicidencia con el codigo  
"""                                  
def Borrar_producto():    #ELIMINAR SI SE FACTURO?
    print("================================================")
    print("=            Borrar producto                   =")
    print("================================================")
    codigo=input("Ingrese el codigo de el producto que desea eliminar: ")
    facturado= Buscanombre(codigo,"FacturasDetalle.txt")

  
    if codigo=="":
           print("Debe ingresar un codigo")
           return Borrar_producto()

    if facturado==0:
           
           
           lista = []
           contador=0
           respuesta=0
           listaN= []
           nombreArchivo= "Inventario.txt"
           miLista=leerArchivox(nombreArchivo)
          

           archivo=open(nombreArchivo,"w")
           archivo.write("")
           archivo.close
              #Validar nombreArchivo no sea vacío
           if(nombreArchivo != ""):
               for linea in miLista:
                   lista += [linea.split(" ")]
                   #print(lista)
                   if lista[contador][0] != codigo:
                       listaN+=lista[contador]
                      # print(listaN,"LN")
                   contador += 1
               validacion=input("¿Esta seguro de eliminar este producto? (si)/(no)")
               if validacion=="si":
                   for elemento in listaN:
                      
                       escribirArchivoa(elemento,nombreArchivo)
                       
                   opcion=input("Digite (1) si desea eliminar otro producto, (2) para salir al menu principal: ")
                   if opcion!="":
                             if opcion=="1":
                                   return Borrar_producto()
                             if opcion=="2":
                                   return  menú()

                   return Vertodaslasactividades("Inventario.txt")
                   
               if validacion=="no":
                     opcion=input("Digite (1) si desea eliminar otro producto, (2) para salir al menu principal: ")
                     if opcion!="":
                            try:
                                   opcion=int(opcion)
                                  
                            except:
                                   print("Debe ingresar una de las opciones disponibles")
                                   print()
                                   return menú()
                            opcion=str(opcion)
                            if opcion=="1":
                                   return Borrar_producto()
                            if opcion=="2":
                                   return  menú()
    else:
            print("No se puede eliminar un producto ya facturado")
            print()
            print()
            opcion=input("Digite (1) si desea eliminar otro producto, (2) para salir al menu principal: ")
            if opcion!="":
                      try:
                            opcion=int(opcion)
                                  
                      except:
                             print("Debe ingresar una de las opciones disponibles")
                             return menú()
                      opcion=str(opcion)
                      if opcion=="1":
                            return Borrar_producto()
                      if opcion=="2":
                            return  menú()

            
"""
Nombre: Agregar_inventario
Entrada:modificaciones 
Funcion:agrega cantidad de productos deseados al inventario
restricciones: cantidad mayor a 0 codigo existente
"""   
def Agregar_inventario():
       nombre= "Inventario.txt"
       lista = []
       contador=0
       respuesta=0
       listaN= []
       nuevotxt=[]
       salto="\n"
       listax=[]
       moditxt=[]
       largo=0
       longitud=0
       codigo=input("Digite el codigo de el producto que va a ingresar: ")
       texto= Buscacodigo(codigo,nombre)
      
       
       print("A continuacion se muestra como se ve actualmente el producto en inventario")
       print(texto[0],texto[1],texto[2],texto[3],texto[4])
       print("")
       print("")
       print("Por favore ingrese las modificiaciones")
       nombreArchivo= "Inventario.txt"
       miLista=leerArchivox(nombreArchivo)
       for linea in miLista:
              #print (linea)
              
      
      
        cantidad=input("Ingrese la cantidad de el producto: ")

       
        if cantidad!="":
             try:
              cantidad=int(cantidad)
             except:
              print("Debe ingresar una cantidad ayor a 0 y no vacia")
              print()
              return GestióndeInventarios()
             if isinstance(cantidad,int):
              if cantidad>0:
                    try:
                         cantidad=str(cantidad)
                    except:
                        ""
                    for elemento in miLista:
                        
                      
                        spt=elemento.split(" ")
                        #print(spt)
                        
                      
                        lista=spt[0:]
                        listax=[cantidad,salto]
                        if elemento[0]==codigo:
                              
                               for i in spt:
                                      nuevotxt+=[i]
                           
                                                                          
                               longitud=6
                                     
                                    
                               while longitud!=2: #elimina elementos 
                                    moditxt+=[nuevotxt[contador]]#crea nueva lista sin las ultimas posiciones 
                                    #print([nuevotxt[contador]])
                                    contador+=1
                                    longitud-=1
                               nuevotxt=moditxt
                           
                               nuevotxt+=listax
                               listaN+=[ nuevotxt]
                          
                        else: 
                            listaN+=[spt]
                          
                            #print(listaN)
                    archivo=open("Inventario.txt","w")
                    archivo.write("")
                    archivo.close()
                    for elemento in listaN:
                          for palabra in elemento:
                              escribirArchivoa(palabra,nombreArchivo)
                    opcion=input("Digite (1) si desea agregar otro producto, (2) para salir al menu principal: ")
                    if opcion!="":
                       try:
                              opcion=int(opcion)

                       except:
                              print("Debe ingresar una opcion valida,por favor intetelo de nuevo")
                              opcion="2"
                       opcion=str(opcion)
                       if opcion=="1":
                            return  Agregar_inventario()
                       if opcion=="2":
                            return  menú()   


              
"""
Nombre: Reporte
Funcion:imprime el menu de reportes
"""            
def Reportes_productos():
       tex="""
       (1)Reporte de Productos
       (2)Reporte por Categoría
       (3)Reporte por Existencia
                         """
       print("================================================")
       print("=                 Reporte                      =")
       print("================================================")

 
       print(tex)
           
       opcion=input("Digite una de las anteriores opciones anteriores: ")
       if opcion!="":
              try:
                     opcion=int(opcion)
              except:
                     return "no se convirtio"
              
              if opcion==1:
                     return Reporte_Productos()
              if opcion==2:
                     return Reporte_Categoría()
              if opcion==3:
                     return Reporte_Existencia()
       else:
           print("*****Debe ingresar una opcion valida****" )
           return  Reportes_productos()
       """
Nombre: Reporte_Productos
Funcion:imprime todos los productos del inventario
"""

def Reporte_Productos():
      reportes=[]
      reporte=[]
      txt=[]
      texto=leerArchivoread("Inventario.txt")
      texto=texto.split(" \n")
      for elemento in texto:
             txt+=[elemento.split(" ")]
      for elemento in txt:
              if elemento=="":
                     continue
              if elemento=="\n":
                     continue
              if elemento!=['']:
                   
                     reporte+=["\n",elemento[0],elemento[1],elemento[3],elemento[4],"\n"]
                    
                    
      
      encabezado=["código","nombre","precio", "cantidad","\n"]
      encabezadoRPV(encabezado,"lista de compra.txt")
      escribecenter(reporte,"lista de compra.txt")
      leer=leerArchivoread("lista de compra.txt")
     
      print("------------------------------------------")
      print("           Reporte por productos          ")
      print("------------------------------------------")


      print("------------------------------------------")
      print(" A continuacion se muestra el inventario  ")
      print("------------------------------------------")
      print(leer)
      archivo=open("lista de compra.txt","w")
      archivo.write("")
      archivo.close()

      opcion=input("Digite (1) para volver al menu principal,(2)para menu de reportes,(3) para descargar informacion") 
      if opcion!="":
            try:
                opcion=int(opcion)
            except:
                print("Debe ingresar una de las opciones disponibles")
                return Reportes()
                
            if opcion<4 and opcion>0:
                    if opcion==1:
                        return menú()
                    if opcion==2:
                        return Reportes_productos()
                    if opcion==3:
                           #print(reporte)
                           return archivoexterno(encabezado,"",reporte)
            else:
                   print("Debe ingresar una de las opciones disponibles")
                   return Reportes_productos()
      else:
           print( "Error: debe ingresar un caracter")
           return Reportes_productos()
"""
Nombre: Reporte por categoriabienvenida.upper
Funcion:imprime todos los productos del inventario que coincidan con la categoria
"""       
def Reporte_Categoría():
      rep=[]
      txt=[]
      encabezado=["código", "nombre","precio","cantidad","\n"]
      
      print("------------------------------------------")
      print("           Reporte por categoria          ")
      print("------------------------------------------")
      categoria=input("Digite la categoria que desea buscar: ")
      if categoria!="":
        producto=buscarreporte(categoria,"inventario.txt")
        #print(producto)
       
        
      
        if producto!="":
                print("------------------------------------------")
                print(    "     Categoria: ",categoria                   )
                print("------------------------------------------")
                for line in producto:
                       #print(line)
                 
                    
                       if line=="":
                            continue
                       if line=="\n":
                            continue
                       if line!=['']:
                              rep+="\n",line[0],line[1],line[3],line[4],"\n"
                           
                encabezadoRPV(encabezado,"lista de compra.txt")
                escribecenter(rep,"lista de compra.txt")
                txt=leerArchivoread("lista de compra.txt")
                print(txt)
                archivo=open("lista de compra.txt","w")
                archivo.write("")
                archivo.close()

                opcion=input("Digite (1) para volver al menu principal,(2)para menu de reportes,(3) para descargar la informacion") 
                if opcion!="":
                       try:
                              opcion=int(opcion)
                       except:
                              print()
                              print("Debe ingresar una opcion valida")
                              print()
                              return menú()
                       if opcion==1:
                            return menú()
                       if opcion==2:
                            return Reportes_productos()
                       if opcion==3:
                             # print(rep)
                              return archivoexterno(encabezado,"",rep)
                     
        else:
             print( "No hay coincidencias con la categoria ingresada")
             opcion=("Digite (1) para volver al menu principal,(2)para menu de reportes") 
             if opcion!="":
                    if opcion==1:
                            return menú()
                    if opcion==2:
                            return Reportes()
      else:
           return "Error: debe ingresar una categoria"
"""
Nombre: Reporte por categoria
Funcion:imprime todos los productos del inventario que coincidan con la categoria
"""     
def Reporte_Existencia():
    print("------------------------------------------")
    print("           Reporte por existencia         ")
    print("------------------------------------------")
    listaN=[]
    lista = []
    contador=0
    txt=[]
    encabezado=["código", "nombre", "precio", "cantidad","\n"]
     
    nombreArchivo= "Inventario.txt"
    miLista=leerArchivoread(nombreArchivo)
    miLista=miLista.split("\n")
       
    if(nombreArchivo != ""):
        for linea in miLista:
          
        
            
            lista+= [linea.split(" ")]
           
            
                
            listaN+=[(lista[contador][:5])]
            contador+=1
        for caracter in listaN:
            
               if caracter=="":
                            continue
               if caracter=="\n":
                            continue
               if caracter!=['']:
                      try:
                             numero=int(caracter[4])
                      except:
                             continue
              
               
               
                      if numero>0:
                             txt+= "\n",caracter[0],caracter[1],caracter[3],caracter[4],"\n"
                      else:
                             continue
        encabezadoRPV(encabezado,"lista de compra.txt")
        escribecenter(txt,"lista de compra.txt")
        txt=leerArchivoread("lista de compra.txt")
        print(txt)
        archivo=open("lista de compra.txt","w")
        archivo.write("")
        archivo.close()

        opcion=input("Digite (1) para volver al menu principal,(2)para menu de reportes,(3) para descargar la informacion") 
        if opcion!="":
              try:
                  opcion=int(opcion)
              except:
                     print()
                     print("Debe ingresar una opcion valida")
                     print()
                     return menú()
              if opcion==1:
                     return menú()
              if opcion==2:
                    return Reportes_productos()
              if opcion==3:
                   return archivoexterno(encabezado,"",txt)
 #-----------------------------------------------------------------------------------------------------
 #      facturas
 #----------------------------------------------------------------------------------------------------       
"""
Nombre:Facturacion
Funcion:lee lor productos a comprar y genera facturas"""

def Facturar():
    FacturasDetalle=[]
    Nfactura=gencod("Facturas.txt")
    encabe=0
    listadecompra=[]
    preciofinal=0
    costo=0
    txt=[]
    subtotal=0
    impuestos=0
    texto=str
    subimpuesto=0
    x=[]
    contador=0
    restart=0
    prin=""
    print("============================================") 
    print("                Facturas                    ")
    print("============================================") 
    print("==================================================================")


    nombrecliente=input("Ingrese su nombre y apellido por favor: ")
    

    if nombrecliente=="":
           nombrecliente="Anonimo"
 
    opcion=1
    #encabezado=["codigo","Cantidad", "Producto", "Precio Unitario","Impuesto 13% ","Total","\n"]
    #for elemento in encabezado:
        #escribirArchivoa(elemento,"lista de compra.txt")
    while opcion==1:
           
        menu=leerArchivoread("Inventario.txt")
        print("Productos disponibles")
        print(menu)
        codigo=input("Ingrese el codigo que desea agregar al carrito: ")
        try:
             codigo=int(codigo)
            
        except:
             print("Debe ingresar solo el numero de la opcion ")
             codigo=int(input("Ingrese el codigo que desea agregar al carrito: "))
                   
        if isinstance(codigo,int):
               codigo=str(codigo)
        
               
               if codigo!="":
                          producto =Buscacodigo(codigo,"Inventario.txt")# retorna el codigo que se ingreso
                          produ=Buscaexistencia(codigo)#verifica que el producto este disponible
                          existencia=produ
                          cantidad=input("Digite la cantidad que desea comprar")
                          try:
                                 cantidad=int(cantidad)
                          except:
                                 "Debe ingresar un caracter valido"
                                 cantidad=int(input("Digite la cantidad que desea comprar"))
                                 
                          if isinstance(cantidad,int):
                                 if cantidad<= existencia:
                                      
                                      compra=productos(codigo,"inventario.txt")#es una lista con producto/cantidad
                                      preciounitario=int(producto[3])
                                 
                                      sub_total=preciounitario*cantidad#total a pagar sin IVA
                                      
                                      impuestos=int(sub_total*0.13)#calculo de el IVA
                                      
                                      total=sub_total+impuestos
                                     
                                      restainv=existencia-cantidad#resta la catidad que se compra
                                      
                                      nombre=producto[1]

                                      
                                      resta=modificar_inventario(codigo,restainv)
                                      listadecompra+=cantidad,nombre,preciounitario,impuestos,str(total),"\n"
                                      FacturasDetalle=[Nfactura,codigo,nombre,cantidad,preciounitario, sub_total,impuestos,total,"\n"]
                                      h2=0
                                      for palabra in FacturasDetalle:
                                          if palabra=="":
                                                 continue
                                          txt=str(palabra)
                                          txt.center(h2)
                                          h2=5 
                                          escribirArchivoa(txt,"FacturasDetalle.txt") 
                                      preciofinal=preciofinal+total
                                      subtotal+=sub_total
                                      subimpuesto+=impuestos
                                      archivo=open("lista de compra.txt","w")
                                      archivo.write("")
                                      archivo.close()
  
                                   
                                      encabezado=["Cantidad" ,"Producto" ,"PrecioU" ,"Impuesto-13%","total" ,"\n"]
                                      encabezadoRPV(encabezado,"lista de compra.txt")
                                      nlist=[]
                                      cont=0
                                      lis=""
                     
                               


                                   
                                      escribecenter(listadecompra,"lista de compra.txt")     

                                   
                                                     
                                           
                                      archivo=leerArchivoread("lista de compra.txt")
                                   
                                      print(archivo)
                                                      
                                      print ("total: ",preciofinal)# actualiza constantemente el precio a pagar y la lista de compras
                                                           

                                          
                                             

                                             
                                      opcion=input("DIgite (1) para continuar su compra (2) para finalizar: ")
                                      if opcion=="1":
                                            opcion=1
                                            
                                      if opcion=="2":
                                             """
                                             h2=0
                                  
                                             for palabra in FacturasDetalle:
                                                  if palabra=="":
                                                         continue
                                                  txt=str(palabra)
                                                  txt.center(h2)
                                                  h2=5 
                                                  escribirArchivoa(txt,"FacturasDetalle.txt")
                                      
                                             """
                                           
                                             return facturero (nombrecliente,subimpuesto,subtotal,preciofinal,codigo,cantidad,preciounitario,x,FacturasDetalle,Nfactura)


                                     
                              
                                 else:
                                     print("***No contamos con la catidad deseada***")
                                     opcion=1
                          else:
                              print("***Debe ingresar una catidad numerica***")
      
"""
Nombre: facturero
funcion auxiliar de facturar
"""                
def facturero (nombrecliente,impuesto,subtotal,total,codigo,cantidad,preciounitario,x,FacturasDetalle,Nfactura):
   FacturasDetalle=[]
   Facturas=[]
   texto=""
    
   
   fecha = datetime.datetime.now().strftime("%d/%m/%Y")
   hora = datetime.datetime.now().strftime("%I:%M %p")

   archivo=leerArchivoread("lista de compra.txt")

  

   
   cadena = nombrecliente
   cadena_capitalizada = cadena.capitalize()
 
   h=0
   print("===========================================") 
   print("Factura", Nfactura)
   print("Fecha",fecha,"Hora", hora)
   print("Cliente: ",cadena_capitalizada)
   print("===========================================") 

   print(archivo)
   print("Sub total: ",subtotal)
   print("Impuestos: ",impuesto)
   print("Total: ",total)
   print("===========================================") 


   archivo=open("lista de compra.txt","w")
   archivo.write("")
   archivo.close()
  
   
   print(    "(1) Efectivo"     )

   print(    "(2) Sinpe Movil"     )

   print(    "(3) Tarjeta de Crédito"     )
   fpago=formapago()
   #print(fpago)
   producto=productos2(codigo,"inventario.txt")
   #print(producto)
   pcomprado=producto[0]

   #print(pcomprado)
   for x in pcomprado:
        
        if x == "[":
             continue
        if x == "]":
             continue
        elif x !="]" and x !="[":
            x=str(x)
            texto=texto+x
            #print(texto)

        
   
   Facturas+=[Nfactura,nombrecliente,fecha,hora,subtotal,impuesto,total,fpago,"\n"]
   h=0
   for palabra in Facturas:
        txt=str(palabra)
        txt.center(h)
        h=5 
        escribirArchivoa(txt,"Facturas.txt")

   
   print("Gracias por su compra!!")
   return menú()
"""
Nombre reportes
funcion muestra y retorna hacia otra funcion de el menu"""
def Reportes():
     total=0
     x=[]
     print("======================================")
     print(           "Menu de reportes           ")
     print("======================================")
     print("(1).Reporte de facturas")

     print("(2).Reporte por producto vendidos")

     print("(3).Reporte por cliente")

     print("(4).Estado de utilidades")

     print("(5) Menu principal")

     opcion=input("Ingrese una de las anteriores opciones")
     if opcion!="":
          if opcion=="1":
               return Reporte_de_facturas()
          if opcion=="2":
               return Reporte_producto_vendido()
          if opcion=="3":
               return Reporte_cliente()
          if opcion=="4":
               return Estado_utilidades()
          if opcion=="5":
               return menú()
          else:
             print("*****Debe ingresar una opcion valida****" )
             return   Reportes()
               

"""
Nombre:Reporte_de_facturas
funcion:imprime en pantalla las facturas existentes"""
def Reporte_de_facturas():
     center=0
     contador=0
     NLIST=[]
     tot=[]
     CONT=0
     TOTAL=0
     texto=leerArchivoread("Facturas.txt")
     
     if texto=="":
            print("No se han ingresado facturas")
            return Reportes()
     text=[]

  
     sub=texto.split("\n")
     #print(sub)
     for linea in sub:
          if linea=="":
               continue
          Linea=linea.split(" ")
          tot+=[Linea]
         
   
                   
                   
              
                  
     encabezado=[ "#Factura","Fecha","Cliente","Total","\n"]
     encabezadoRPV(encabezado,"lista de compra.txt")
    
     contador=0         
     for palabra in tot:
         
          if palabra==['', '']:
               continue
          
          text=text+[palabra[0],palabra[2],palabra[1],palabra[7],"\n"]
          TOTAL+=int(palabra[7])
     escribecenter(text,"lista de compra.txt")         
              
 
     txt=leerArchivoread("lista de compra.txt")
     print(txt)
     print("Total: ",TOTAL)
     archivo=open("lista de compra.txt","w")
     archivo.write("")
     archivo.close()
  
     opcion= input("Digite (1) para volver al menu de reportes (2) para menu principal (3) para descargar la informacion: ")
     
     if opcion!="":
          try:
                 opcion=int(opcion)
          except:
                 print("Debe ingresar una opcion valida")
                 return Reportes()
                 
          if opcion==1:
               return Reportes()
          if opcion==2:
               return menú()
          if opcion==3:
                 return  archivoexterno(encabezado,TOTAL,text)
          

"""
Nombre:Reporte_producto_vendido()
Funcion: retorna los productos vendidos segun su categoria
"""

def Reporte_producto_vendido():
     
     categoria=input("Ingrese el producto que desea buscar: ")
     TOTAL=0
     x=0
     coincidenciadetalle=[]
     coincidencias=[]
     total=[]
     valorCol1=categoria
     lista = []
     contador=0
     respuesta=0
     largo=largoTXT(valorCol1)
     nombreArchivo="Facturas.txt"
     miLista=leerArchivox(nombreArchivo)
     
     if miLista==[' \n']:
            print("No se han ingresado facturas")
            return Reportes()
     codigos=[]
     
     encabezado=["#Factura", "Fecha" ,"Precio-Unitario", "Cantidad", "Impuesto" ," Total ","\n"]
     encabezadoRPV(encabezado,"lista de compra.txt")#escribe el encabezado
     codigos=buscarproductoCOD(valorCol1)
     #print (codigos)
     for elemento in codigos:
          coincidencias+=buscarreportes(elemento,"Facturas.txt")
          coincidenciadetalle+=buscarreportes(elemento,"FacturasDetalle.txt")
    
     if coincidencias=="":
            Print("No se ha facturado este producto")
     if coincidenciadetalle=="":
            Print("No se ha facturado este producto")

     for elemento in coincidencias:
   
          x+=1
          if x ==2:
            contador+=1
          if elemento=="":
                     continue
          if elemento=="\n":
                     continue
          if elemento!=['']:
            

                 precio=elemento[7]
                 precio=int(precio)
                 TOTAL+=precio
                 total+=[elemento[0],elemento[2],elemento[5],coincidenciadetalle[contador][1],elemento[6],elemento[7],"\n"]
          #print(total)
          
    
     #escribecenter(encabezado,"lista de compra.txt")   
     

     escribecenter(total,"lista de compra.txt")
     txt=leerArchivoread("lista de compra.txt")
     archivo=open("lista de compra.txt","a")
     TOTAL=str(TOTAL)
     TOTAL=TOTAL.center(0)
     T="   Total: "
     T=T.center(0)
     archivo.write( T)
     archivo.write( TOTAL)
     archivo.close()
     categoria=categoria.center(30)
     print("-------------------------------------------")
     print(categoria)
     print("-------------------------------------------")
     print(txt)
     print (T,TOTAL)
     
     archivo=open("lista de compra.txt","w")
     archivo.write("")
     archivo.close()


     print("¿ desea extraer los datos en otro archivo")
     
     Aexterno=input("(1)  =  Si (2) = No")
     
     if Aexterno=="1":
          
           return (encabezado,TOTAL,total)
     elif Aexterno=="2":
        
            return menú()
     
     else:
           print("Hubo un error aegurese de digitar bien la opcion")
           print("Asegurese de digitar solo el numero que se encuentra en el ()")
     
           Aexterno=input("(1)=Si (2)=No")
     
           if Aexterno=="1":
               encabezadoRPV(encabezado)
               return archivoexterno(encabezado,TOTAL,total)
           elif Aexterno=="2":
                return menú()
           
           else:
                
                 archivo=open("lista de compra.txt","w")
                 archivo.write("")
                 archivo.close()
                 return menú()
           
           

     
           
           
           
"""
 Nombre:.Reporte por cliente
 funcion: busca coicendencias con un cliente e imprime sus compras
 Restricciones: los datos ingresados no pueden ser vacios
"""
def Reporte_cliente():
     strr="Total: "
     strr=strr.center(0)
     reporte=[]
     cliente=input("Ingrese el nombre de cliente: ")
     total=0
     valorCol1=cliente
     lista = []
     contador=0
     largo=largoTXT(valorCol1)
     nombreArchivo="Facturas.txt"
     miLista=leerArchivox(nombreArchivo)
     if miLista==[' \n']:
            print("No se han ingresado facturas")
            return Reportes()
     
     encabezado=["#Factura", "Fecha" ,"Total_Facturado","\n"]
       #Validar nombreArchivo no sea vacío
     if cliente!="":
        #print(cliente)
        for linea in miLista:
            lista += [linea.split(" ")]
            if lista[contador][1][:largo] == valorCol1:
                cliente=lista[contador][1]
           
                reporte+= ("\n",lista[contador][0], lista[contador][2],  lista[contador] [7],"\n")
                X=lista[contador][7]
                total+=int(X)
            contador+=1      
     
                
            
        totales=[cliente,": ",total]
        encabezadoRPV(encabezado,"lista de compra.txt")
        escribecenter(reporte,"lista de compra.txt")
        print("-------------------------------------------")
        print("Cliente: ",cliente)
        print("-------------------------------------------")
        archivos=leerArchivoread("lista de compra.txt")
        print (archivos)
        print(strr,total)      
        archivo=open("lista de compra.txt","w")               
        archivo.write("")
        archivo.close()
      
        if total=="":
            print("No se encontraron coicidencias con el producto")
        opcion= input("Digite (1) para volver al menu (2) para menu principal,(3) para descargar la informacion: ")
           
           
            
        archivo=open("lista de compra.txt","w")
        archivo.write("")
        archivo.close()
        if opcion=="3":
              archivoexterno(encabezado,total,reporte)
        elif opcion=="1":
              return Reportes()
        elif opcion=="2":
              return menú()

     else:
            print("Debe ingresar el nombre de el cliente")
            return Reporte_cliente()
                
"""
Nombre: reporte_rango_fecha
Entrada: fechas
Salida:reporte de fechas 
Restricciones:
"""    
def reporte_rango_fecha():
      rango=[]
      inicio=input("Ingrese la fecha de inicio en formato  dd/mm/yy:  ")
      final=input("Ingrese la fecha final en formato  dd/mm/yy:  ")
      largo=largoTXT(inicio)
      largo2=largoTXT(final)
      # print(largo)
      f=cantidad_facturas ("Facturas.txt")
      if largo!=10:
             print("Indico la fecha de inicio mal por favor intente de nuevo" )
             return reporte_rango_fecha()
      if largo2!=10:
             print("Indico la fecha final, mal por favor intente de nuevo" )
             return reporte_rango_fecha()
      else:
             lista=[]
             milista=leerArchivoread("Facturas.txt")
             #print(milista)
             milista=milista.split("\n")
             for linea in milista:
                       #print(linea)
                       if linea=="":
                                   continue
                       if linea=="\n":
                                   continue
                       if linea!=['']:
                              lista+=[linea.split(" ")]
                              #print(lista)
             for elemento in lista:
                    
                    if elemento[2]==inicio:
                           while elemento[2]<final:
                                  rango+="\n",elemento[0],elemento[1],elemento[2],elemento[3],elemento[4],elemento[5],elemento[6],elemento[7],elemento[8],"\n"
                                 
                    elif elemento[2]==final:
                           rango+="\n",elemento[0],elemento[1],elemento[2],elemento[3],elemento[4],elemento[5],elemento[6],elemento[7],elemento[8],"\n"
             print(rango) 

                      
"""
Nombre: Estado_utilidades
Entrada:
Salida:texto en archivo y informe de contabilidad 
Restricciones:nombre de archivo valido y existente
"""      
def Estado_utilidades():
        print("-------------------------------------------")
        print("           Estado de utilidades")
        print("-------------------------------------------")
       
        facturas=nfaturas("FacturasDetalle.txt")
        facturas=str(facturas)
        facturas=facturas.center(0)
        txt=leerArchivoread("FacturasDetalle.txt")
        #print(txt)
        if txt==[' \n']:
            print("No se han ingresado facturas")
            return Reportes()
        txt=txt.split("\n")
        subtotal=0
        impuestos=0
        total=0
        lista=[]
        for x in txt:
               lista+=[x.split(" ")]

        
        #print (lista)
       
        for elemento in lista:
               #print (elemento)
               #print(elemento)
               if elemento=="":
                      continue
               
               if elemento=="\n":
                     continue
               if elemento!=['']:     
                      subtotal+=int(elemento[4])
                      impuestos+=int(elemento[6])
                      total+=int(elemento[5])
                     
                      cantidad=buscacantidad()
              
        opcion=input("Digite (1) para descargar la informacon (2) solo para ver la informacion: ")
        if opcion=="1":
              encabezado=["Estado de utilidades"]
           
              total=str(total)
              total=total.center(0)
              n=input("Ingrese el nombre del destino con el domino correspondiente: ")
              lista=["Total Facturas:",facturas,"\n"," Cantidad de productos facturados únicos:",facturas,"\n","SubTotal Facturado",subtotal,"\n"," Total Impuesto:",impuestos,"\n","Total Facturado",total]
              encabezadoRPV(encabezado,n)
              escribecenter(lista,n)
              txt=leerArchivoread(n)
              print(txt)
              archivo=open("lista de compra.txt","w")               
              archivo.write("")
              archivo.close()
              return menú()
        elif opcion=="2":
              total=str(total)
              total=total.center(0)
              encabezado=["Estado de utilidades"]
              encabezadoRPV(encabezado,"lista de compra.txt")
              lista=["Total Facturas:",facturas,"\n","Cantidad de productos facturados únicos:",cantidad,"\n","SubTotal Facturado",subtotal,"\n","Total Impuesto:",impuestos,"\n","Total Facturado",total]
              escribecenter(lista,"lista de compra.txt")
              txt=leerArchivoread("lista de compra.txt")
              print(txt)
              archivo=open("lista de compra.txt","w")               
              archivo.write("")
              archivo.close()

              return menú()
       



        
        
       
       
     
 
def Salir():

     print("--------------------------------------")
     print("Se cerro su punto de venta")
     print("--------------------------------------")
     return""
"""
Nombre: archivoexterno
Entrada:encabezado,TOTAL,archivo
Salida:texto en archivo
Restricciones:nombre de archivo valido y existente
"""

def archivoexterno(encabezado,TOTAL,archivo):
      name=input("Ingrese el nombre de el archivo externo")
      escribecenter(encabezado,name)
    
      
      escribecenter(archivo,name)
      archivo=open(name,"a")
      if TOTAL=="":
            ""
      else:
                    
             
             archivo.write("Total: ")
             TOTAL=str(TOTAL)
             archivo.write(TOTAL)
             archivo.close()
      return menú()
                  

#CODIGOS AUXILIARES de inventario
"""
Nombre: leerArchivos
Entrada:nombre de archivo
Salida:texto en archivo
Restricciones:nombre de archivo valido y existente
"""
def leerArchivox(nombreArchivo):
    #validar nombreArchivo debe ser string
    if (isinstance(nombreArchivo,str)):
        if (nombreArchivo != ""):
            archivo =open(nombreArchivo, mode= "r")
            contenido = archivo.readlines()
            archivo.close()
            return contenido
        else:
            return "ERROR EL ARRCHIVO NO DEBE SER VACIO"
    else:
        return" tipo no es texto"
def leerArchivoread(nombreArchivo):
    #validar nombreArchivo debe ser string
    if (isinstance(nombreArchivo,str)):
        if (nombreArchivo != ""):
            archivo =open(nombreArchivo, mode= "r")
            contenido = archivo.read()
            archivo.close()
            return contenido
        else:
            return "ERROR EL ARRCHIVO NO DEBE SER VACIO"
    else:
        return" tipo no es texto"
"""
Nombre:gencod
Funcion: genera el codigo automatico de productos
"""                    
def gencod(name):
    codigo=0
    name=name
    
    lineas=leerArchivoread(name)
    
    lineas=lineas.split("\n")
    for elemento in lineas:
          
           
           if elemento!="":
                  elemento=int(elemento[0])
                  codigo=0
                  codigo+=elemento
  
    codigo+=1
    codigo=str(codigo)
    if lineas==0:
           return 1

    return codigo

                     
"""
nombre:buscarporproducto
entrada: el nombre del producto
salida:true, false
""" 
def buscarporproducto(x):
    
    valorCol1=x
    
    lista = []
    contador=0
    respuesta=0
    largo=largoTXT(valorCol1)
    nombreArchivo= "Inventario.txt"
    miLista=leerArchivox(nombreArchivo)
    if miLista=="":
           return "No hay productos que mostrar en el inventario"
       #Validar nombreArchivo no sea vacío
    if(nombreArchivo != ""):
        if miLista=="":
               return 2
        for linea in miLista:
               if linea!="":
            
                      lista += [linea.split(" ")]
               else:
                      
               
                      if lista[contador][1][:largo] == valorCol1:
                             contador+=1
                                          
        if contador!=0:
              return 1
        if contador==0:
              return 2
        
"""
Nombre:buscarreporte
Funcion:busca segun largo o tipo de archivo enviado y retorna lista con coincidencias
"""             
def buscarreporte(x,n):
    long=0   
    valorCol1=x
    valorCol1=str(valorCol1)
    lista = []
    contador=0
    listaN=[]
    respuesta=0
    largo=largoTXT(valorCol1)
    nombreArchivo= n
    x=leerArchivoread(nombreArchivo)
    x=x.split("\n")
    miLista=[]
    for elemento in x:
           miLista+=[elemento.split(" ")]

    if(nombreArchivo != ""):
              for linea in miLista:
                   if linea=="":
                     continue
                   if linea=="\n":
                     continue
                   if linea!=['']:

                          if (linea[2][:largo])==valorCol1:
                         
                                listaN+=[linea[0:]]
                          contador+=1
               
              return listaN              
    else:
       return "Error: El nombre de archivo no debe ser vacío"
       
"""
Nombre:buscarreporte
Funcion:busca segun largo o tipo de archivo enviado y retorna lista con coincidencias
""" 
               
def buscarreportes(x,n):#se cambio para reporte por producto
    long=0   
    valorCol1=x
    valorCol1=str(valorCol1)
    lista = []
    contador=0
    listaN=[]
    respuesta=0
    largo=largoTXT(valorCol1)
    nombreArchivo= n
    x=leerArchivoread(nombreArchivo)
    x=x.split("\n")
    miLista=[]
    for elemento in x:
           miLista+=[elemento.split(" ")]

    if(nombreArchivo != ""):
              for linea in miLista:
                   if linea=="":
                     continue
                   if linea=="\n":
                     continue
                   if linea==['']:
                          continue
              
                   if linea!=['', '']:
                   
                   

                          if (linea[0][:largo])==valorCol1:#se modifico para leer p2 estaba en p0[contador]
                         
                                listaN+=[linea[0:]]
                          contador+=1
              return listaN              
    else:
       return "Error: El nombre de archivo no debe ser vacío"
       
"""
Nombre:largoTXT
Funcion:cuenta y retorna la cantidad de archivos en una lista o str
""" 
def largoTXT(name):
    contador=0
    name=str(name)
    for elemento in name:
        contador+=1
    return contador
def largolista(l):
  contador=0
  for elemento in l:
        contador+=1
  return contador
"""
nombre: Vertodaslasactividades
entrada: nombre de el txt
salida: el contenido del txt
""" 
    
def Vertodaslasactividades(nombre):
    name=nombre
    texto=leerArchivoread(name)
    print (texto)
    """
    Nombre: Escribir archivo a
    Funcion:escribe palabra por palabra en el texto
    Restricciones: el nombre del archivo debe ser str,el contenido ni el nombre puede estar vacio
    """
def escribirArchivoa(elemento,nombre):
  
    nombreArchivo=nombre
    
    if (isinstance(nombreArchivo,str)):
        if (nombreArchivo!=""):
            
                archivo=open (nombreArchivo,mode="a" )
                #archivo.write(codigo)
                if elemento=="\n":
                    archivo.write(" ")
                    archivo.write(elemento)
                else:
                    archivo.write(elemento)
                    archivo.write(" ")
                    archivo.close()
                
        else:
            return "debe ingresar el nombre de el documento"
"""
nombre: Buscacodigo
entrada: El codigo del producto
salida: retorna toda las linea que coinsida con el codigo
""" 
def Buscacodigo(codigo,nombre):
    variable=[]
    valorCol1=codigo
    lista = []
    contador=0
    respuesta=0
    largo=largoTXT(valorCol1)
    nombreArchivo=nombre
    miLista=leerArchivox(nombreArchivo)
       #Validar nombreArchivo no sea vacío
    if(nombreArchivo != ""):
        for linea in miLista:
            lista += [linea.split(" ")]
            if lista[contador][0] == valorCol1:
                variable=(lista[contador][0:5])
                if variable=="":
                       #print ("El codigo ingresado no existe")
                       return 0
                else:
                       return variable
            contador+=1
    else:
        return "Error: El nombre de archivo no debe ser vacío"
"""
nombre: Cantidaddemensajes
entrada: el nombre del archivo
salida: retorna la cantidad de msj
""" 
def Cantidaddemensajes(name):
    
    name=name
    lista= leerArchivox(name)
    contador=0
  
    for linea in lista:
        contador+=1
    return  contador
#Codigos auxiliares de facturas
"""
nombre: Buscacodigo
entrada: El codigo del producto
salida: retorna la cantidad que coincida con el codigo
""" 
def Buscaexistencia(codigo):
    valorCol1=codigo
    lista = []
    contador=0
    respuesta=0
    largo=largoTXT(valorCol1)
    nombreArchivo="Inventario.txt"
    miLista=leerArchivox(nombreArchivo)
       #Validar nombreArchivo no sea vacío
    if(nombreArchivo != ""):
        for linea in miLista:
            lista += [linea.split(" ")]
            #print(lista)
            if lista[contador][0][:largo] == valorCol1:
                respuesta=lista[contador][4]#estrae el elemento de lista
                #print(respuesta)
                respuesta=int(respuesta)
                return respuesta
               
            contador+=1
    else:
        return "Error: El nombre de archivo no debe ser vacío"
"""
nombre: producto
entrada: El codigo del producto
salida: retorna el producto que esta siendo facturado
""" 
def productos(codigo,nombre):
    valorCol1=codigo
    lista = []
    contador=0
    respuesta=0
    largo=largoTXT(valorCol1)

    miLista=leerArchivox(nombre)
       #Validar nombreArchivo no sea vacío
    if(nombre != ""):
        for linea in miLista:
            lista += [linea.split(" ")]
           # print(lista)
            if lista[contador][0][:largo] == valorCol1:
                #print(lista[contador])
                r1= str(lista[contador][1:2])
                respuesta=(lista[contador][4:5])
                #print(respuesta)
                respuesta2=(lista[contador][3:4])
                #print(respuesta2)
                
                for i in respuesta:
                     num1=int(i)
                     r2=num1
                for i in respuesta2:
                     num=int(i)
                     r3=num

                

                respuesta=[r1,r2,r3]
            contador+=1
        return respuesta        
    else:
       return "Error: El nombre de archivo no debe ser vacío"
       
"""
Nombre:modificar_inventario
Entrada:codigo,resta
Funcion:modifica la cantidad en inventario de un producto
restriccion: cantidad mayor a 0 y que sea str
""" 
def modificar_inventario(codigo,resta):
       time=0
       nombre= "Inventario.txt"
       lista = []
       contador=0
       txt=""
       listaN= []
       nuevotxt=[]
       salto="\n"
       codigo=codigo
       

       
      
       cantidad=str(resta)
       if cantidad!="":
             if isinstance(cantidad,str):
             
                        nombreArchivo= "Inventario.txt"
                        miLista=leerArchivox(nombreArchivo)
                        #Validar nombreArchivo no sea vacío
                        x=open(nombreArchivo,"w")
                        x.write("")
                        x.close()
                        if(nombreArchivo != ""):
                                for linea in miLista:
                                        listas=[linea]
                                        #print(listas,"1")
                                        lista += [linea.split(" ")]
                                        #print(lista,"2")
                                        if lista[contador][0] != codigo:
                                            listaN+=lista[contador]
                                        elif lista[contador][0] == codigo:
                                               nueval=lista[contador][0],lista[contador][1],lista[contador][2],lista[contador][3],cantidad,"\n"
                                               listaN+=nueval
                                        contador += 1
                                                            
                                                            
                                for elemento in listaN:
                                          if elemento=="":
                                                     continue

                                          else:
                                                 escribirArchivoa(elemento,nombreArchivo)
             
             else:
                    return "Error la cantidad debe ser un numero entero"
       
"""
Nombre:formapago
Entrada:
Funcion: retorna un str con la informacion que se solicita
restriccion: no ingresar uno de los datos solicitados 
""" 
def formapago():
     pago=input( "Ingrese la forma de pago: ")
  
     
   
     if pago!=("1","2","3"):
              if pago=="1":
                           formapago="Efectivo"
              elif pago=="2":
                           formapago="Simpe-Movil"
              elif pago=="3":
                           formapago="Targeta-de-Credito"

              return formapago
     else:
              print("Debe ingresar una opcion valida")        
              return formapago()
            
"""
Nombre:nfaturas
Entrada: name
Funcion: retorna el numero de codigo o factura

"""  
def nfaturas(name):
     
    name=name
    
    lineas= cantidad_facturas(name)
    contador=lineas+1
    return contador

            
"""
Nombre:cantidad_facturas 
Entrada: name
Funcion: retorna el numero de codigo o factura

"""  
def cantidad_facturas (name):
    
    name=name
    lista= leerArchivox(name)
    contador=0
  
    for linea in lista:
        contador+=1
        if linea=="":
             contador-=1
    return  contador
"""
Nombre: Escribir archivo c
Funcion:escribe palabra por palabra en el texto con un espacio largo
Restricciones: el nombre del archivo debe ser str,el contenido ni el nombre puede estar vacio
"""
def escribirArchivoc(elemento,nombre):
       
  
    nombreArchivo=nombre
    if (isinstance(nombreArchivo,str)):
        if (nombreArchivo!=""):
            
                archivo=open (nombreArchivo,mode="a" )
                #archivo.write(codigo)
                if elemento=="\n":
                    archivo.write(" ")
                    archivo.write(elemento)
                else:
                    archivo.write(elemento)
                    archivo.write("  ")
                    archivo.close()
                
        else:
            return "debe ingresar el nombre de el documento"
        
"""
nombre: producto
entrada: El codigo del producto
salida: retorna el producto que esta siendo facturado
""" 
def productos2(codigo,nombre):
    valorCol1=codigo
    lista = []
    contador=0
    respuesta=0
    largo=largoTXT(valorCol1)

    miLista=leerArchivox(nombre)
       #Validar nombreArchivo no sea vacío
    if(nombre != ""):
        for linea in miLista:
            lista += [linea.split(" ")]
           # print(lista)
            if lista[contador][0][:largo] == valorCol1:
                #print(lista[contador])
                r=lista[contador][1:2]
                r1=r
                     
                     
                respuesta=(lista[contador][4:5])
                #print(respuesta)
                respuesta2=(lista[contador][3:4])
                #print(respuesta2)
                for i in respuesta:
                     num1=int(i)
                     r2=num1
                for i in respuesta2:
                     num=int(i)
                     r3=num

                

                respuesta=[r1,r2,r3]
            contador+=1
        return respuesta        
    else:
       return "Error: El nombre de archivo no debe ser vacío"

"""
nombre: encabezadoRPV
entrada:encabezado,n
salida:escribe en algun destino un encabezado con espaciado agradeble a la vista
"""                            
def encabezadoRPV(encabezado,n):
        encabe=0
        contador=0
        x=0
        for h in encabezado:
              x+=1
        
    
        if isinstance(encabezado,list):
            if encabe == 0:
                    
                     for elemento in encabezado:
                            if contador==x:
                                   encabe=1
                            elif elemento=="":
                                    contador+=1
                                    continue
                                      
                            elif elemento=="\n":
                                    escribirArchivoa(elemento, n)
                                
                                
                            elif elemento == encabezado[0]:
                                    if elemento=="":
                                        continue

                                    elemento=str(elemento)
                                    elemento=elemento.center(0)

                                    elemento = str(elemento)

                                    contador+=1
                                    escribirArchivoa(elemento, n)
                            elif elemento == encabezado[1]:
                                    if elemento=="":
                                       continue
                                    elemento = str(elemento)
                                    elemento = elemento.center(10)
                                    escribirArchivoa(elemento, n)
                                    contador+=1
                            elif elemento == encabezado[2]:
                                        if elemento=="":
                                             continue
                                        elemento = str(elemento)
                                        elemento = elemento.center(15)
                                        escribirArchivoa(elemento, n)
                                        contador+=1
                            elif elemento == encabezado[3]:
                                        if elemento=="":
                                             continue
                                        elemento = str(elemento)
                                        elemento = elemento.center(15)
                                        escribirArchivoa(elemento, n)
                                        contador+=1
                            elif elemento == encabezado[4]:
                                        if elemento=="":
                                              continue
                                        elemento = str(elemento)
                                        elemento = elemento.center(5)
                                        encabe = 1
                                        contador+=1
                                        escribirArchivoa(elemento, n)
                            elif elemento == encabezado[5]:
                                        if elemento=="":
                                            continue
                                        elemento = str(elemento)
                                        escribirArchivoa(elemento, n)
                                        contador+=1
                          

       
"""
nombre: buscarproductoCOD
entrada: el nombre del producto
salida:Numero de factura por cada coincidencia
""" 
def buscarproductoCOD(x):
    facturas=[]
    n=0
    list=[]
    valorCol1=x
    #valorCol1=str(variable)
    long=0
    lista = []
    contador=0
    nfactura=[]
    largo=largoTXT(valorCol1)

    nombreArchivo= "FacturasDetalle.txt"
    miLista=leerArchivox(nombreArchivo)
    if miLista=="":
           return "No hay productos que mostrar en las facturas"
      
    if(nombreArchivo != ""):
        
        for linea in miLista:
               long+=1
               
               if linea!="":
                      list+=[linea.split("\n")]
            
                      lista += [linea.split(" ")]
               else:
                      continue
        
        while contador<=long:
             if lista!=" ":
                    if lista!="\n":
                      if lista[contador][2][:largo] == valorCol1:
                            nfactura=lista[contador][0]
                            reset=largoTXT(nfactura)
                            cont=0
                            for x in nfactura:
                                 if x !=" ":
                                   try:
                                       n=int(x)
                                       f=n+(10**cont)
                                       cont+=1
                                       if reset==1:
                                             n=int(x)
                                    
                                             f=n
                                             facturas+=[f]
                                             #print(facturas)
                                            
                                       elif cont==reset:
                                           facturas+=[f]
                                        
                                   except:
                                         ""
                      Facturas= facturas  
                      contador+=1          
                      if contador==long:
                           
                            return Facturas
"""
nombre: escribecenter
entrada:listadecompra,n
salida:escribe en algun destino un texto con espaciado agradeble a la vista
"""                                  
def escribecenter(listadecompra,n):
       
        contador=0
        for elemento in listadecompra:   
                if elemento=="":
                      continue
                elif elemento=="\n":
                      escribirArchivoa("\n", n)
                      contador=0
                      
                elif contador == 0:
                         if elemento=="":
                                continue
                         elemento = str(elemento)
                      
                         contador+=1
                         escribirArchivoc(elemento, n)
                elif  contador == 1:
                         if elemento=="":
                                continue
                         elemento = str(elemento)
                         elemento = elemento.center(20)
                         contador+=1
                         escribirArchivoc(elemento, n)
                elif  contador == 2:
                         if elemento=="":
                                continue
                         elemento = str(elemento)
                         elemento = elemento.center(5)
                         contador+=1
                                              
                         escribirArchivoc(elemento, n)
                elif contador == 3:
                         if elemento=="":
                                continue
                         elemento = str(elemento)
                         elemento = elemento.center(18)
                         contador+=1
                         escribirArchivoc(elemento, n)
                elif contador == 4:
                       if elemento=="":
                            continue
                       elemento = str(elemento)
                       elemento = elemento.center(7)
                       contador+=1
                       escribirArchivoc(elemento, n) 
                elif contador == 5:
                       if elemento=="":
                                continue
                       elemento = str(elemento)
                       elemento = elemento.center(8)
                       contador+=1
                       escribirArchivoc(elemento,n)
                 
                elif contador == 6:
                       if elemento=="":
                            continue
                       elemento = str(elemento)
                       elemento = elemento.center(7)
                       contador+=1
                       escribirArchivoc(elemento, n) 
                elif contador == 7:
                       if elemento=="":
                            continue
                       elemento = str(elemento)
                       elemento = elemento.center(7)
                       contador+=1
                       escribirArchivoc(elemento, n)
                elif contador == 8:
                       if elemento=="":
                            continue
                       elemento = str(elemento)
                       elemento = elemento.center(7)
                       contador+=1
                       escribirArchivoc(elemento, n) 
                elif contador == 9:
                       if elemento=="":
                            continue
                       elemento = str(elemento)
                       elemento = elemento.center(7)
                       contador+=1
                       escribirArchivoc(elemento, n) 
               
"""
nombre: buscacantidad

salida:cantidad de producto en inventarios
"""                 
def buscacantidad():
      cantidad=0
      largo=0
      txt=leerArchivoread("FacturasDetalle.txt")
      lista=txt.split("\n")
      inventario=leerArchivoread("Inventario.txt")
      inventario=inventario.split("\n")
      listacodigosf=[]
      listainve=[]
      contador=0
      for elemento in lista:
                    txt=elemento
                    txt=txt.split(" ")
                    h=txt[contador]
                   
                    if h!="":
                     
                           x=txt[1]
                          
                           listacodigosf+=[x]
                           contador-=1
                          
                           
                    contador+=1
      contador=0
      for elemento in inventario:
                            largo+=1
                            

      for elemento in inventario:
                             
                                   
                             txt=elemento
                             txt=txt.split(" ")
                             if txt=="":
                                 continue
                             if txt=="\n":
                                   continue
                             if txt!=['']:      
                                    h=txt[contador]
                                   
                             if h!="":
                                     listainve+=[txt[0]]
                                     contador-=1

                             contador+=1
                     
      for elemento in listainve:
             codigo=elemento
             for elemento in listacodigosf:
                    if elemento ==codigo:
                           cantidad+=1
                           break
      return cantidad
              
             
"""
nombre: Buscacodigo
entrada: El codigo del producto
salida: retorna toda las linea que coinsida con el codigo
""" 
def Buscanombre(name,nombre):
    largo=0
    variable=[]
    valorCol1=name
    lista = []
    contador=0
    respuesta=0
    largo=largoTXT(valorCol1)
    nombreArchivo=nombre
    miLista=leerArchivoread(nombreArchivo)
    miLista=miLista.split("\n")
    #print(miLista)
       #Validar nombreArchivo no sea vacío
    x=leerArchivoread(nombre)
    x=x.split(" ")
    for elemento in x:
          
           if elemento=="\n":
                  largo+=1
    largo-=2
   #print(largo)
    if(nombreArchivo != ""):
           while contador<=largo:
               for linea in miLista:
                   lista = linea.split(" ")
                   
                   
                   if lista=="":
                            continue
                   if lista=="\n":
                            continue
                   if lista!=['']:
                          if lista[1] == valorCol1:#[contador]
                              return 1
                   contador+=1
              
                              
               return 0
                      
                   
    else:
        return "Error: El nombre de archivo no debe ser vacío"             
print(menú())

