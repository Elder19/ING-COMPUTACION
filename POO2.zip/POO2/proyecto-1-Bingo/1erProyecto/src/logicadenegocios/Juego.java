package logicadenegocios;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.stream.*;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;


/**
 * Clase que representa un juego de Bingo.
 *
 * @author Brasly V
 * @author Eyden S
 * @author Elder L
 */
public class Juego {
    
  private ArrayList<CartonBingo> cartones;
  private ArrayList<Jugador> jugadores;
  private ArrayList<Integer> numerosCantados;
  private ArrayList<CartonBingo> ganadores; // guarda la cedula de la última partida
  private String identificador;
  private char modoJuego;
  private String premio;
  private int ganar = 0; // Inicialmente no se ha ganado
  private int contador1 = 0;
  private int contador2 = 0;
  private Map<Character, Set<String>> jugadoresGanadores = new HashMap<>();
  
  // Rutas de archivos y carpetas predeterminadas.
  private static final String ARCHIVO_JUGADORES= "Documentos\\Jugadores.csv";
  private static final String CARPETA_IMAGENES= "Imagenes\\";
  private static final String CARPETA_CARTONES= "Cartones\\";

  /**
   * Constructor de la clase Juego que inicializa las listas de cartones, jugadores, números cantados y ganadores.
   * También genera un identificador para el juego.
   */
  public Juego() {
    ganadores = new ArrayList<CartonBingo>();
    cartones = new ArrayList<CartonBingo>();
    jugadores = new ArrayList<Jugador>();
    numerosCantados = new ArrayList<Integer>();
    identificador = generarIdentificador();
  }
  
  /**
   * Genera y canta un número aleatorio para el juego de bingo.
   *
   * @return El número cantado o -1 si se han cantado todos los números.
   */
  public int cantarNumero() {
    Random random = new Random();
    
    if (numerosCantados.size() < 75){
      int numeroCantado;
    do {
        numeroCantado = random.nextInt(76);
    } while (numeroCantado == 0 || esNumeroCantado(numeroCantado));

    numerosCantados.add(numeroCantado);
    return numeroCantado;
    } else {
      return -1;
    }  
  }
  
  /**
   * Busca a los ganadores en los cartones de Bingo según las reglas del juego.
   * Si un jugador no ha ganado previamente en el modo de juego actual,
   * verifica si sus cartones son ganadores en función de los números cantados.
   * Si un cartón resulta ganador, lo agrega a la lista de ganadores y guarda los datos de la partida.
   */
  public void encontrarGanadores() {
        
    Stream<Integer> streamNumerosCantados = numerosCantados.stream();
    int[] pnumerosCantados = streamNumerosCantados.mapToInt(Integer::intValue).toArray();

    for (CartonBingo carton : cartones) {
      if (carton.getJugadorAsig() != null) {
        int[][] matriz = carton.getMatriz();
        boolean esGanador = false;

        // Verifica si el jugador ya ha ganado en este tipo de juego y cartón
        if (!jugadoresGanadores.containsKey(modoJuego)) {
          jugadoresGanadores.put(modoJuego, new HashSet<>());
        }

        if (!jugadoresGanadores.get(modoJuego).contains(carton.getJugadorAsig().getCedula())) {
          switch (modoJuego) {
            case 'X':
              esGanador = getjuegoEnX(matriz, pnumerosCantados);
              break;
            case 'L':
              esGanador = getJuegoL(matriz, pnumerosCantados);
              break;
            case 'E':
              esGanador = getjuegoEnE(matriz, pnumerosCantados);
              break;
            case 'Z':
              esGanador = getjuegoEnZ(matriz, pnumerosCantados);
              break;
            // Agregar otros tipos de juego si es necesario
          }
          if (esGanador) {
            ganadores.add(carton);
            String numeros=Arrays.toString(pnumerosCantados);
            GuardarPartida guardarPartida = new GuardarPartida();
            guardarPartida.guardarPartida(numeros, modoJuego, ganadores);
          }
        }
      }
    }
    streamNumerosCantados.close();
  }
  
  /**
   * Verifica si un número ya ha sido cantado durante el juego.
   *
   * @param pNum El número que se desea verificar si ha sido cantado.
   * @return true si el número ya ha sido cantado, false en caso contrario.
   */
  public boolean esNumeroCantado(int pNum) {
    for (int numeroCantado : numerosCantados) {
      if (numeroCantado == pNum) {
        return true;
      }
    }
    return false;
  }
  
  /**
   * Agrega un nuevo jugador al juego si su número de cédula no se encuentra registrado previamente.
   *
   * @param pNombre El nombre del jugador a agregar.
   * @param pCedula El número de cédula del jugador a agregar.
   * @param pEmail El correo electrónico del jugador a agregar.
   */
  public void agregarJugador(String pNombre, String pCedula, String pEmail) {
    for (Jugador jugador: jugadores) {
      if (buscarJugador(pCedula) != null) {
        return;
      }
    }
    jugadores.add(new Jugador(pNombre, pCedula, pEmail));
  }
  
  /**
   * Genera y agrega la cantidad especificada de cartones de bingo al juego, siempre que la cantidad
   * esté en el rango de 1 a 500 (inclusive). Cada cartón se crea y almacena en la lista de cartones,
   * y se genera una imagen PNG correspondiente para cada uno de ellos.
   *
   * @param pCantidad La cantidad de cartones que se desea generar y agregar al juego.
   */
  public void generarCartones(int pCantidad) {
    if (0 < pCantidad && pCantidad < 501) {
      for (int i = 0; i < pCantidad; i++) {
        CartonBingo nuevoCarton = new CartonBingo(identificador);
        cartones.add(nuevoCarton);
        new CrearImagen(nuevoCarton, CARPETA_CARTONES).crearPng();
      }
    }
  }
  /**
   * Establece el premio del juego con la descripción proporcionada.
   *
   * @param pPremio La descripción del premio que se asignará al juego.
   */
  public void setPremio(String pPremio) {
    premio = pPremio;
  }
  
  /**
   * Establece el modo de juego del bingo según una descripción proporcionada.
   *
   * @param pModo La descripción del modo de juego, como "Cuatro esquinas", "Jugar en X", "Cartón lleno" o "Jugar en Z".
   */
  public void setModoJuego(String pModo) {
    switch (pModo) {
      case "Cuatro esquinas":
        modoJuego = 'E';
        break;
      case "Jugar en X":
        modoJuego = 'X';
        break;
      case "Cartón lleno":
        modoJuego = 'L'; 
        break;
      case "Jugar en Z":
        modoJuego = 'Z';
        break;
      default:
        break;
    }
  }
  
  /**
   * Asigna una cantidad específica de cartones a un jugador y envía los cartones por correo electrónico.
   *
   * @param pCantidad La cantidad de cartones que se asignarán al jugador (de 1 a 5).
   * @param pCedula La cédula del jugador al que se asignarán los cartones.
   */
  public void asignarCartones(int pCantidad, String pCedula) {
    Jugador jugadorActual = buscarJugador(pCedula);
    ArrayList<String> ubicaciones = new ArrayList<String>();
    
    if (jugadorActual == null || 1 > pCantidad || pCantidad > 5) {
      return;
    }
    int contador = 0;
    
    for (CartonBingo carton: cartones) {
      if (carton.getJugadorAsig() == null && contador < pCantidad) {
        contador ++;
        carton.asignarAJugador(jugadorActual);
        ubicaciones.add(CARPETA_CARTONES + carton.getIdentificador() + ".png");
      }
    }
    enviarCartones(jugadorActual, ubicaciones);
  }
  
  /**
   * Envía un correo a los ganadores del bingo.
   *
   * @param pPremio El premio que se otorga a los ganadores.
   */
  public void enviarCorreoGanadores(String pPremio) {
    for (CartonBingo carton : ganadores) {
      new EnviarCorreo(carton.getJugadorAsig().getEmail(), "HA GANADO EL BINGO", "SU PREMIO: " + pPremio);
    }
  }
  
  /**
   * Envía los cartones asignados a un jugador por correo electrónico.
   *
   * @param pJugador El jugador al que se le enviarán los cartones por correo.
   * @param pUbicaciones Las ubicaciones de los archivos de cartones a enviar.
   */
  public void enviarCartones(Jugador pJugador, ArrayList<String> pUbicaciones) {
    String[] archivosAdjuntos = pUbicaciones.toArray(new String[0]);
    EnviarCorreo enviarCorreo = new EnviarCorreo(pJugador.getEmail(), archivosAdjuntos);
  }
  
  /**
   * Verifica si un jugador ya tiene asignado el número máximo de cartones permitidos.
   *
   * @param pJugador El jugador cuyos cartones se verificarán.
   * @return {@code true} si el jugador ya tiene asignado el número máximo de cartones, {@code false} en caso contrario.
   */
  public boolean cantidadCartonesMaxJugador(Jugador pJugador) {
    int contador = 0;
    
    for (CartonBingo carton : cartones) {
      if (carton.getJugadorAsig() != null) {
        if (contador == 4) {
          return true;
        }
        if (carton.getJugadorAsig().equals(pJugador)) {
          contador ++;
        }
      }
    }
    return false;
  }
  
  /**
   * Obtiene una lista de todos los cartones en el juego.
   *
   * @return Una lista de objetos CartonBingo que representan los cartones en el juego.
   */
  public ArrayList<CartonBingo> getCartones() {
    return cartones;
  }
  
  /**
   * Obtiene una lista de todos los jugadores en el juego.
   *
   * @return Una lista de objetos Jugador que representan a los jugadores en el juego.
   */
  public ArrayList<Jugador> getJugadores() {
    return jugadores;
  }
  
  /**
   * Verifica si hay algún cartón asignado a un jugador en el juego.
   *
   * @return true si al menos un cartón está asignado a un jugador, de lo contrario, false.
   */
  public boolean hayCartonAsignado() {
    for (CartonBingo carton : cartones) {
      if (carton.getJugadorAsig() != null) {
        return true;
      }
    }
    return false;
  }
  
  /**
   * Genera un identificador aleatorio de tres letras a partir del conjunto de letras permitidas.
   *
   * @return Un identificador de tres letras aleatorias.
   */
  public String generarIdentificador() {
    Random random = new Random();
    String resultado = "";
    String letrasPermitidas = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    
    for (int i = 0; i < 3; i++) {
      int indiceAleatorio = random.nextInt(letrasPermitidas.length());
      char letra = letrasPermitidas.charAt(indiceAleatorio);
      resultado += letra;
    }

    return resultado;
  }
  
  /**
   * Genera un archivo CSV que contiene los datos de los jugadores y los guarda en la ubicación especificada.
   * El archivo se crea en el formato estándar de CSV y contiene información sobre los jugadores, como nombre, cédula y correo electrónico.
   */
  public void generarCSV() {
    List<String[]> datos = new ArrayList<String[]>();

    for (Jugador jugador : jugadores) {
      datos.add(jugador.getDatos());
    }
    try {
      // Crear una instancia de FileWriter para abrir el archivo CSV en modo de escritura
      FileWriter fileWriter = new FileWriter(ARCHIVO_JUGADORES);

      // Crear una instancia de CSVPrinter con el formato CSV deseado
      CSVPrinter csvPrinter = new CSVPrinter(fileWriter, CSVFormat.DEFAULT);

      // Escribir los datos en el archivo CSV utilizando CSVPrinter
      for (String[] fila : datos) {
        csvPrinter.printRecord((Object[]) fila);
      }
      csvPrinter.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
  
  /**
   * Busca un jugador en la lista de jugadores por su número de cédula.
   *
   * @param pCedula El número de cédula del jugador que se desea buscar.
   * @return El jugador con el número de cédula especificado, o null si no se encuentra.
   */
  public Jugador buscarJugador(String pCedula) {
      
    for (Jugador jugador: jugadores) {
      if (pCedula.equals(jugador.getCedula())) {
        return jugador;
      }
    }
    return null;
  }
  
  /**
   * Busca un cartón en la lista de cartones por su identificador.
   *
   * @param pIdentificador El identificador del cartón que se busca.
   * @return El cartón correspondiente si se encuentra, o null si no se encuentra.
   */
  public CartonBingo buscarCarton(String pIdentificador) {
    
    for (CartonBingo carton: cartones) {
      if (pIdentificador.equals(carton.getIdentificador())) {
        return carton;
      }
    }
    return null;
  }

  /**
   * Carga los jugadores desde un archivo CSV y los agrega a la lista de jugadores.
   * Si el archivo no existe o ocurre un error de lectura, no se produce una excepción,
   * simplemente no se cargan jugadores.
   */
  public void cargarJugadores() {
    try {
        FileReader lector = new FileReader(ARCHIVO_JUGADORES);
        CSVParser csvParser = CSVParser.parse(lector, CSVFormat.DEFAULT);
      for (CSVRecord csvRecord : csvParser) {
        String nombre = csvRecord.get(0);
        String cedula = csvRecord.get(1);
        String email = csvRecord.get(2);
        
        
        Jugador jugador = new Jugador(nombre, cedula, email);
        jugadores.add(jugador);
      }
    } catch (IOException e){
    }
  }
  
  /**
   * Determina si un cartón gana en el modo "Jugar en X" (forma de equis).
   *
   * @param pMatriz          La matriz del cartón.
   * @param pNumeroCantado   La lista de números cantados.
   * @return `true` si el cartón gana en el modo "Jugar en X", de lo contrario, `false`.
   */
  public boolean getjuegoEnX(int[][] pMatriz, int[] pNumeroCantado) {
    contador1 = 0;
    contador2 = 4;
    for (int[] subfila : pMatriz) {
      setjuegoEnX2(subfila, pNumeroCantado);
      contador1 += 1;
      contador2 -= 1;
    }
    if (ganar == 9) {
      ganar = 0;
      return true;
    } 
    else {
      ganar = 0;
      return false;
    }
  }

  /**
   * Calcula si un cartón gana en el modo "Jugar en X" (forma de equis) de forma auxiliar.
   *
   * @param pfila            Una fila del cartón.
   * @param pNumeroCantado   La lista de números cantados.
   */
  public void setjuegoEnX2(int[] pfila, int[] pNumeroCantado) {
    int NUM = pfila[contador1];
    int NUM2 = pfila[contador2];
    for (int numero : pNumeroCantado) {
      if (NUM == numero) {
        ganar += 1;
      } else if (NUM2 == numero) {
        ganar += 1;
      }
    }
  }

  /**
   * Determina si un cartón gana en el modo "Cartón lleno".
   *
   * @param pMatriz          La matriz del cartón.
   * @param pNumeroCantado   La lista de números cantados.
   * @return `true` si el cartón gana en el modo "Cartón lleno", de lo contrario, `false`.
   */
  public boolean getJuegoL(int[][] pMatriz, int[] pNumeroCantado) {
    for (int[] pfila : pMatriz) {
      for (int elemento : pfila) {
        for (int numero : pNumeroCantado) {
          if (elemento == numero) {
            ganar += 1;
            break;
          }
        }
      }
    }
    
    if (ganar == 25) {
      ganar = 0;
      return true;
    }
    else {
      ganar = 0;
      return false;
    }
  }

  /**
   * Determina si un cartón gana en el modo "Jugar en E".
   *
   * @param pMatriz          La matriz del cartón.
   * @param pNumeroCantado   La lista de números cantados.
   * @return `true` si el cartón gana en el modo "Jugar en E", de lo contrario, `false`.
   */
  public boolean getjuegoEnE(int[][] pMatriz, int[] pNumeroCantado) {
    int contador1 = 0;
    for (int elemento : pNumeroCantado) {
      if (pMatriz[0][0] == elemento) {
        ganar += 1;
      } 
      else if (pMatriz[0][4] == elemento) {
        ganar += 1;
      }
      else if (pMatriz[4][0] == elemento) {
        ganar += 1;
      } 
      else if (pMatriz[4][4] == elemento) {
        ganar += 1;
      }
    }
    if (ganar == 4) {
      ganar = 0;
      return true;
    } 
    else {
      ganar = 0;
      return false;
    }
  }

  /**
   * Determina si un cartón gana en el modo "Jugar en Z".
   *
   * @param pMatriz          La matriz del cartón.
   * @param pNumeroCantado   La lista de números cantados.
   * @return `true` si el cartón gana en el modo "Jugar en Z", de lo contrario, `false`.
   */
  public boolean getjuegoEnZ(int[][] pMatriz, int[] pNumeroCantado) {
    contador1 = 0;
    contador2 = 0;
    int[] fila1 = pMatriz[0];
    int[] fila2 = pMatriz[4];
    for (int numero : pNumeroCantado) {
      if (pMatriz[1][3] == numero) {
        ganar += 1;
      } else if (pMatriz[2][2] == numero) {
        ganar += 1;
      } else if (pMatriz[3][1] == numero) {
        ganar += 1;
      }
       else if (pMatriz[0][4] == numero) {
        ganar += 1;
      }
       else if (pMatriz[4][0] == numero) {
        ganar += 1;
      }
    }

    for (int numero : pNumeroCantado) {
      contador2=0;
      if (numero == pMatriz[4][0]) {
          ganar += 1;
        }
        else if (numero == pMatriz[4][1]) {
          ganar += 1;
        }
        else if (numero == pMatriz[4][2]) {
          ganar += 1;
        }
        else if (numero == pMatriz[4][3]) {
          ganar += 1;
        }
        else if (numero == pMatriz[4][4]) {
          ganar += 1;
        }
    }
    for (int numero : pNumeroCantado) {
      contador1=0;
      if (numero == pMatriz[0][0]) {
        ganar += 1;
      }
      else if (numero == pMatriz[0][1]) {
        ganar += 1;
      }
      else if (numero == pMatriz[0][2]) {
        ganar += 1;
      }
      else if (numero == pMatriz[0][3]) {
        ganar += 1;
      }
      else if (numero == pMatriz[0][4]) {
        ganar += 1;
      }
    }
      if (ganar == 15) {
      ganar = 0;
      return true;
    } else {
      ganar = 0;
      return false;
    }
  }
  
  /**
   * Obtiene la lista de los cartones de Bingo ganadores en la partida actual.
   *
   * @return Una lista de objetos CartonBingo que representan los cartones ganadores.
   */
  public ArrayList<CartonBingo> getGanadores() {
    return ganadores;
  }
  
  /**
   * Obtiene la ruta de la carpeta que almacena las imágenes relacionadas con el juego.
   *
   * @return La ruta de la carpeta de imágenes.
   */
  public static String getCarpetaImagenes() {
    return CARPETA_IMAGENES;
  }
  
  /**
   * Obtiene la ruta de la carpeta que almacena los cartones generados para el juego.
   *
   * @return La ruta de la carpeta de cartones.
   */
  public static String getCarpetaCartones() {
    return CARPETA_CARTONES;
  }

  /**
   * Obtiene el modo de juego actual del objeto Juego.
   *
   * @return El modo de juego actual.
   */
  public char getModoJuego() {
    return modoJuego;
  }
  
  /**
   * Obtiene la lista de números que han sido cantados durante el juego.
   *
   * @return Una lista de números cantados.
   */
  public ArrayList<Integer> getNumerosCantados() {
    return numerosCantados;
  }
}
