package logicadenegocios;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * La clase CrearArchivoTexto se encarga de crear o actualizar un archivo de texto
 * con una lista de comentarios proporcionados. Los comentarios se escriben línea por línea.
 * 
 * @author Brasly V
 * @author Eyden S
 * @author Elder L
 */
public class CrearArchivoTexto {
  private String nombreArchivo = "Documentos\\WordCloud.txt";

  /**
   * Constructor de la clase CrearArchivoTexto.
   * 
   * @param pComentarios Lista de comentarios a escribir en el archivo de texto.
   */
  public CrearArchivoTexto(List<String> pComentarios) {
    try {
      // Verificar si el archivo existe, si no, crearlo
      File archivo = new File(nombreArchivo);
      if (!archivo.exists()) {
        archivo.createNewFile();
      }

      try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
        // Escribir contenido en el archivo
        for (String comentario : pComentarios) {
          System.out.println(comentario);
          writer.write(comentario);
          writer.newLine();
        }

        System.out.println("El archivo " + nombreArchivo + " ha sido creado o actualizado con éxito.");
      } catch (IOException e) {
        System.err.println("Error al escribir en el archivo: " + e.getMessage());
      }
    } catch (IOException e) {
      System.err.println("Error al crear o verificar el archivo: " + e.getMessage());
    }
  }
}
