package logicadenegocios;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * Clase para guardar la información de una partida.
 * 
 * @author Eyden S
 * @author Brasly V
 * @author Elder L
 */
public class GuardarPartida {
  private String configuracion;

  /**
   * Método para guardar una partida.
   *
   * @param todoNumero   La cadena de números del juego.
   * @param tipoJuego    El tipo de juego.
   * @param pGanadores   Lista de cartones ganadores.
   */
  public void guardarPartida(String todoNumero, char tipoJuego, ArrayList<CartonBingo> pGanadores) {
    String ganadores = "";
    
    // Obtener la fecha y hora actuales
    LocalDate fechaActual = LocalDate.now();
    LocalTime horaActual = LocalTime.now();

    // Formatear la fecha y la hora en cadenas (Strings)
    DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH:mm:ss");

    String fechaComoString = fechaActual.format(formatoFecha);
    String horaComoString = horaActual.format(formatoHora);

    for (CartonBingo carton : pGanadores) {
      if (!ganadores.equals("")) {
        ganadores += ", ";
      }
      ganadores += carton.getJugadorAsig().getCedula();
    }
    
    // Llamar a un método para agregar los datos al archivo XML (no se proporciona en el código actual)
    WriteXML.addXMLRecord(Character.toString(tipoJuego), todoNumero, ganadores, fechaComoString, horaComoString);
  }
}
