package logicadenegocios;

/**
 * Esta clase representa un jugador en el juego de Bingo.
 *
 * @author Brasly V
 * @author Eyden S
 * @author Elder L
 */
public class Jugador {
  private String nombre;
  private String cedula;
  private String email;

  /**
   * Constructor de la clase Jugador.
   *
   * @param pNombre El nombre del jugador.
   * @param pCedula La cédula del jugador.
   * @param pEmail  El correo electrónico del jugador.
   */
  public Jugador(String pNombre, String pCedula, String pEmail) {
    nombre = pNombre;
    cedula = pCedula;
    email = pEmail;
  }

  /**
   * Obtiene la cédula del jugador.
   *
   * @return La cédula del jugador.
   */
  public String getCedula() {
    return cedula;
  }

  /**
   * Obtiene el correo electrónico del jugador.
   *
   * @return El correo electrónico del jugador.
   */
  public String getEmail() {
    return email;
  }
  
  /**
   * Obtiene el nombre del jugador.
   *
   * @return El nombre del jugador.
   */
  public String getNombre() {
    return nombre;
  }

  /**
   * Devuelve una representación en forma de cadena de los datos del jugador.
   *
   * @return Una cadena que contiene el nombre, cédula y correo electrónico del jugador.
   */
  @Override
  public String toString() {
    String cadena = "";

    cadena += "Nombre del jugador: " + nombre + "\n";
    cadena += "Cédula            : " + cedula + "\n";
    cadena += "Email             : " + email + "\n";

    return cadena;
  }

  /**
   * Obtiene los datos del jugador en forma de arreglo de cadenas.
   *
   * @return Un arreglo de cadenas que contiene el nombre, cédula y correo electrónico del jugador.
   */
  public String[] getDatos() {
    String[] datos = {nombre, cedula, email};
    return datos;
  }
}
