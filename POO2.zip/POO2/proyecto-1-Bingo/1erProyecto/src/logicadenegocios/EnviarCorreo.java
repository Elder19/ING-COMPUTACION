package logicadenegocios;

import java.util.Properties;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.Session;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.io.IOException;

/**
 * Clase para enviar correos electrónicos con archivos adjuntos.
 *
 * Autores:
 * @author Brasly V
 * @author Eyden S
 * @author Elder V
 */
public class EnviarCorreo {

  private String usuario = "pruebatecpoo@gmail.com";
  private String clave = "dyolfedupjgjkhit";
  private String servidor = "smtp.gmail.com";
  private String puerto = "587";
  private Properties propiedades;

  /**
   * Constructor de la clase `EnviarCorreo`.
   *
   * @param pDestinatario       La dirección de correo electrónico del destinatario.
   * @param pTitulo
   * @param pCuerpo
   */
  public EnviarCorreo(String pDestinatario, String pTitulo, String pCuerpo) {

    CuentaCorreo();
    Session sesion = abrirSesion();
    try {
      Message message = new MimeMessage(sesion);
      message.setFrom(new InternetAddress(usuario));
      message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(pDestinatario));
      message.setSubject(pTitulo);
      MimeBodyPart mensajeParte = new MimeBodyPart();
      mensajeParte.setText(pCuerpo);
      Multipart multipart = new MimeMultipart();
      multipart.addBodyPart(mensajeParte);
      message.setContent(multipart);
      Transport.send(message);
    } catch (MessagingException e) {
      e.printStackTrace();
    }
  }
  
  public EnviarCorreo(String pDestinatario, String[] pArchivosAdjuntos) {
    String tituloCorreo = "BINGO";
    String cuerpo = "";
    
    if (pArchivosAdjuntos.length > 1) {
      cuerpo = "Se adjuntan sus cartones de juego";
    } else {
      cuerpo = "Se adjunta su cartón de juego";
    }

    CuentaCorreo();
    Session sesion = abrirSesion();
    try {
      Message message = new MimeMessage(sesion);
      message.setFrom(new InternetAddress(usuario));
      message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(pDestinatario));
      message.setSubject(tituloCorreo);
      MimeBodyPart mensajeParte = new MimeBodyPart();
      mensajeParte.setText(cuerpo);
      Multipart multipart = new MimeMultipart();
      multipart.addBodyPart(mensajeParte);
      if (pArchivosAdjuntos != null) {
        for (String archivoAdjunto : pArchivosAdjuntos) {
          MimeBodyPart adjuntoParte = new MimeBodyPart();
          File adjunto = new File(archivoAdjunto);
          adjuntoParte.attachFile(adjunto);
          multipart.addBodyPart(adjuntoParte);
        }
      }

      message.setContent(multipart);
      Transport.send(message);
    } catch (MessagingException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Configura las propiedades de la cuenta de correo.
   */
  public void CuentaCorreo() {
    propiedades = new Properties();
    propiedades.put("mail.smtp.host", servidor);
    propiedades.put("mail.smtp.port", puerto);
    propiedades.put("mail.smtp.auth", "true");
    propiedades.put("mail.smtp.starttls.enable", "true");
  }

  /**
   * Abre una sesión de correo.
   *
   * @return La sesión de correo configurada.
   */
  private Session abrirSesion() {
    Session sesion = Session.getInstance(propiedades, new javax.mail.Authenticator() {
      @Override
      protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(usuario, clave);
      }
    });
    return sesion;
  }
}
