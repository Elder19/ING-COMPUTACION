
package logicadenegocios;

import com.kennycason.kumo.CollisionMode;
import com.kennycason.kumo.WordCloud;
import com.kennycason.kumo.WordFrequency;
import com.kennycason.kumo.bg.CircleBackground;
import com.kennycason.kumo.font.scale.SqrtFontScalar;
import com.kennycason.kumo.nlp.FrequencyAnalyzer;
import com.kennycason.kumo.palette.ColorPalette;
import java.awt.Color;
import java.awt.Dimension;
import java.io.IOException;
import java.util.List;

/**
 * Esta clase genera una nube de palabras (WordCloud) a partir de un archivo de texto y guarda la imagen resultante.
 *
 * @author Brasly V
 * @author Eyden S
 * @author Elder L
 */

public class WordCloudGenerator {
  /**
   * Constructor de la clase WordCloudGenerator.
   * @throws IOException Si ocurre un error al crear la nube de palabras.
   */
  public WordCloudGenerator () throws IOException {
   crear();
  }
 
  /**
  * Crea una nube de palabras a partir de un archivo de texto y la guarda como una imagen.
  * @throws IOException Si ocurre un error al crear la nube de palabras o guardar la imagen.
  */
  public void crear() throws IOException {
    final FrequencyAnalyzer frequencyAnalyzer = new FrequencyAnalyzer();
    final List<WordFrequency> wordFrequencies = frequencyAnalyzer.load("Documentos\\WordCloud.txt");
    final Dimension dimension = new Dimension(600, 600);
    final WordCloud wordCloud = new WordCloud(dimension, CollisionMode.PIXEL_PERFECT);
    wordCloud.setPadding(2);
    wordCloud.setBackground(new CircleBackground(300));
    wordCloud.setColorPalette(new ColorPalette(new Color(0x4055F1), new Color(0x408DF1), new Color(0x40AAF1), new Color(0x40C5F1), new Color(0x40D3F1), new Color(0xFFFFFF)));
    wordCloud.setFontScalar(new SqrtFontScalar(10, 40));
    wordCloud.build(wordFrequencies);
    wordCloud.writeToFile("Imagenes\\WordCloud.png");
  }
}
