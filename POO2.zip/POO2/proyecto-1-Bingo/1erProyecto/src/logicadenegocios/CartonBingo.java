package logicadenegocios;

import java.util.Random;

/**
 * La clase CartonBingo representa un cartón de bingo con números aleatorios.
 * Cada cartón tiene un identificador único y se puede asignar a un jugador.
 *
 * @author Brasly V
 * @author Eyden S
 * @author Elder L
 */
public class CartonBingo {

  private int[][] matriz;
  private String identificador;
  private Jugador jugadorAsig;
  public static int NUM_CARTONES = 0;
  private static final int FILAS = 5;
  private static final int COLUMNAS = 5;
  private static int[] RANGOS = {15, 30, 45, 60, 75};

  /**
   * Constructor de la clase CartonBingo. Crea un nuevo cartón de bingo con un identificador único.
   * El cartón se genera con números aleatorios siguiendo ciertas reglas.
   *
   * @param pIdentificador El identificador del cartón.
   */
  public CartonBingo(String pIdentificador) {
    identificador = pIdentificador;
    matriz = new int[5][5];
    generarIdentificador();
    generarNumerosMatriz();
    jugadorAsig = null;
    NUM_CARTONES++;
  }

  /**
   * Asigna este cartón a un jugador específico.
   *
   * @param pJugador El jugador al que se asignará este cartón.
   */
  public void asignarAJugador(Jugador pJugador) {
    jugadorAsig = pJugador;
  }

  /**
   * Genera el identificador único del cartón basado en el número total de cartones creados.
   */
  public void generarIdentificador() {
    String numCarton = String.valueOf(NUM_CARTONES);

    for (int i = 0; i < (3 - numCarton.length()); i++) {
      identificador += "0";
    }

    identificador += numCarton;
  }

  /**
   * Obtiene el jugador al que se asignó este cartón.
   *
   * @return El jugador al que se asignó el cartón, o null si no se ha asignado.
   */
  public Jugador getJugadorAsig() {
    return jugadorAsig;
  }

  /**
   * Genera los números del cartón de bingo siguiendo ciertas reglas.
   */
  public void generarNumerosMatriz() {
    for (int i = 0; i < FILAS; i++) {
      for (int j = 0; j < COLUMNAS; j++) {
        matriz[i][j] = generarNumeroAleatorio(i);
      }
    }
  }

  /**
   * Obtiene el identificador único del cartón.
   *
   * @return El identificador del cartón.
   */
  public String getIdentificador() {
    return identificador;
  }

  /**
   * Obtiene la matriz de números del cartón de bingo.
   *
   * @return La matriz de números del cartón.
   */
  public int[][] getMatriz() {
    return matriz;
  }

  /**
   * Genera un número aleatorio dentro de un rango específico.
   *
   * @param pFila La fila en la que se generará el número.
   * @return El número aleatorio generado.
   */
  public int generarNumeroAleatorio(int pFila) {
    Random random = new Random();
    int numeroAleatorio = random.nextInt(RANGOS[pFila]) + 1;

    while (esRepetido(pFila, numeroAleatorio) || (numeroAleatorio <= (RANGOS[pFila] - 15))) {
      numeroAleatorio = generarNumeroAleatorio(pFila);
    }

    return numeroAleatorio;
  }

  /**
   * Verifica si un número ya ha sido utilizado en la misma fila del cartón.
   *
   * @param pFila La fila en la que se verifica la repetición.
   * @param pNum  El número que se verifica.
   * @return true si el número está repetido, false en caso contrario.
   */
  private boolean esRepetido(int pFila, int pNum) {
    for (int j = 0; j < COLUMNAS; j++) {
      if (matriz[pFila][j] == pNum) {
        return true;
      }
    }
    return false;
  }
  
  /**
   * Establece el número total de cartones creados.
   *
   * @param pNum El número total de cartones a establecer.
   */
  public static void setNumCartones(int pNum) {
    NUM_CARTONES = pNum;
  }
}
