package aplicacion;

import ventanas.*;

/**
 * La clase `AplBingo` representa la aplicación principal del juego de Bingo.
 * Este programa crea una interfaz gráfica de usuario y configura el aspecto de la aplicación.
 * Además, lanza la ventana de inicio del juego.
 * 
 * @author Brasly V
 * @author Eyden S
 * @author Elder L
 */
public class AplBingo {
  private static Interfaz menu;

  /**
   * Método principal de la aplicación.
   * @param args Los argumentos de línea de comandos (no se utilizan en este programa).
   */
  public static void main(String args[]) {
  
    try {
      for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          javax.swing.UIManager.setLookAndFeel(info.getClassName());
          break;
        }
      }
    } catch (ClassNotFoundException ex) {
      java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (InstantiationException ex) {
      java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (IllegalAccessException ex) {
      java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (javax.swing.UnsupportedLookAndFeelException ex) {
      java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
    //</editor-fold>

      /* Crear y mostrar la ventana principal del juego */
      java.awt.EventQueue.invokeLater(() -> {
      menu = new Interfaz();
      menu.setVisible(true);
    });
  }
}