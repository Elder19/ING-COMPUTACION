
package ventanas;

import java.awt.Color;
import javax.swing.JDialog;
import logicadenegocios.CartonBingo;
import logicadenegocios.Juego;

/**
 * La clase `VentanaInicioJuego` representa la ventana de inicio del juego de Bingo.
 * Desde esta ventana, los usuarios pueden configurar el juego, comenzar a cantar números y 
 * seguir el progreso del juego, incluyendo la identificación de los ganadores.
 * 
 * @author Eyden
 * @author Brasly V
 * @author Elder L
 */
public class VentanaInicioJuego extends JDialog {
  // Variables declaration
  private javax.swing.JButton jCantarNumButton;
  private javax.swing.JLabel jCartonesLabel;
  private javax.swing.JComboBox<String> jConfComBox;
  private javax.swing.JLabel jConfLabel;
  private javax.swing.JLabel jCongratsLabel;
  private javax.swing.JButton jEndGame;
  private javax.swing.JLabel jJugadoresLabel;
  private javax.swing.JTextArea jNumerosCantados;
  private javax.swing.JTextField jPrizeInput;
  private javax.swing.JLabel jPrizeLabel;
  private javax.swing.JScrollPane jScrollPane1;
  private javax.swing.JButton jStartButton;
  private javax.swing.JLabel jTitulo;
  private javax.swing.JLabel jWinnerLabel;
  private Juego juegoActual;
  // End of variables declaration

  /**
   * Crea una nueva instancia de la ventana de inicio del juego.
   *
   * @param pMenu La ventana de preparación del juego desde la cual se abre esta ventana.
   * @param pModal Un indicador booleano que establece si esta ventana es modal o no.
   * @param pJuego El juego actual que se está configurando y jugando.
   */
  public VentanaInicioJuego(VentanaPreJuego pMenu, boolean pModal, Juego pJuego) {
    super(pMenu, pModal);
    juegoActual = pJuego;
    initComponents();
    this.setLocationRelativeTo(null);
    
    jCantarNumButton.setVisible(false);
    jJugadoresLabel.setVisible(false);
    jCartonesLabel.setVisible(false);
    jNumerosCantados.setVisible(false);
    jWinnerLabel.setVisible(false);
    jEndGame.setVisible(false);
    jCongratsLabel.setVisible(false);
  }

  /**
   * Acción realizada al hacer clic en el botón "Iniciar".
   * Configura el juego y muestra los elementos necesarios para comenzar el juego.
   *
   * @param evt El evento de acción que desencadena esta función.
   */
  private void jStartButtonActionPerformed(java.awt.event.ActionEvent evt) {
    juegoActual.setModoJuego(jConfComBox.getSelectedItem().toString());
    juegoActual.setPremio(jPrizeInput.getText());
    
    jConfComBox.setVisible(false);
    jConfLabel.setVisible(false);
    jStartButton.setVisible(false);
    
    jCantarNumButton.setVisible(true);
    jJugadoresLabel.setVisible(true);
    jCartonesLabel.setVisible(true);
    jNumerosCantados.setVisible(true);
    jPrizeInput.setEditable(false);
    jPrizeInput.setFocusable(false);
   
    jTitulo.setText("Tipo de Juego:" + juegoActual.getModoJuego());
    jCartonesLabel.setText("Cantidad de cartones: " + juegoActual.getCartones().size());
    jJugadoresLabel.setText("Cantidad de jugadores: " + juegoActual.getJugadores().size());
    
  }

  /**
   * Acción realizada al obtener el enfoque en el campo de texto de premio.
   * Borra el texto de marcador de posición y cambia el color del texto.
   *
   * @param evt El evento de enfoque que desencadena esta función.
   */
  private void jPrizeInputFocusGained(java.awt.event.FocusEvent evt) {
    if (jPrizeInput.getText().equals("50 000 colones")) {
      jPrizeInput.setText("");
      jPrizeInput.setForeground(new Color(0,0,0));
    }
  }

  /**
   * Acción realizada al perder el enfoque en el campo de texto de premio.
   * Restaura el texto de marcador de posición si el campo está vacío.
   *
   * @param evt El evento de enfoque que desencadena esta función.
   */
  private void jPrizeInputFocusLost(java.awt.event.FocusEvent evt) {
    if (jPrizeInput.getText().equals("")) {
      jPrizeInput.setText("50 000 colones");
      jPrizeInput.setForeground(new Color(153,153,153));
    }
  }

  /**
   * Acción realizada al hacer clic en el botón "Cantar número".
   * Realiza la acción de cantar un número, identifica a los ganadores y actualiza la interfaz.
   *
   * @param evt El evento de acción que desencadena esta función.
   */
  private void jCantarNumButtonActionPerformed(java.awt.event.ActionEvent evt) {
    int numeroActual = juegoActual.cantarNumero();
    juegoActual.encontrarGanadores();
    if ("".equals(jNumerosCantados.getText())) {
      jNumerosCantados.setText(""+numeroActual);
    } else {
      jNumerosCantados.setText(jNumerosCantados.getText() + ", " + numeroActual);
      
    }
    
    if (juegoActual.getGanadores().size() >= 1) {
      
      String identificadores = "";
      for (CartonBingo carton : juegoActual.getGanadores()) {
        if (!identificadores.equals("")) {
            identificadores += ", ";
        }
        identificadores += carton.getIdentificador();
      }
      jCantarNumButton.setVisible(false);
      jJugadoresLabel.setVisible(false);
      jCartonesLabel.setVisible(false);
      
      jWinnerLabel.setVisible(true);
      jEndGame.setVisible(true);
      jCongratsLabel.setVisible(true);
      jNumerosCantados.setText(identificadores);
      juegoActual.enviarCorreoGanadores(jPrizeInput.getText());
      
    }
  }

  /**
   * Acción realizada al hacer clic en el botón "Terminar Juego".
   * Cierra la ventana actual y muestra la interfaz principal.
   *
   * @param evt El evento de acción que desencadena esta función.
   */
  private void jEndGameActionPerformed(java.awt.event.ActionEvent evt) {
    this.dispose();
    new Interfaz().setVisible(true);
  }

  /**
   * This method is called from within the constructor to initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is always
   * regenerated by the Form Editor.
   */
  @SuppressWarnings("unchecked")
  private void initComponents() {

    jTitulo = new javax.swing.JLabel();
    jConfLabel = new javax.swing.JLabel();
    jConfComBox = new javax.swing.JComboBox<>();
    jPrizeLabel = new javax.swing.JLabel();
    jPrizeInput = new javax.swing.JTextField();
    jStartButton = new javax.swing.JButton();
    jCartonesLabel = new javax.swing.JLabel();
    jCantarNumButton = new javax.swing.JButton();
    jJugadoresLabel = new javax.swing.JLabel();
    jScrollPane1 = new javax.swing.JScrollPane();
    jNumerosCantados = new javax.swing.JTextArea();
    jWinnerLabel = new javax.swing.JLabel();
    jEndGame = new javax.swing.JButton();
    jCongratsLabel = new javax.swing.JLabel();

    setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    setResizable(false);

    jTitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    jTitulo.setText("Iniciar juego de Bingo");

    jConfLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jConfLabel.setText("Configuración:");

    jConfComBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jConfComBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jugar en X", "Cuatro esquinas", "Cartón lleno", "Jugar en Z" }));
    jConfComBox.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

    jPrizeLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jPrizeLabel.setText("Premio:");

    jPrizeInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jPrizeInput.setForeground(new java.awt.Color(153, 153, 153));
    jPrizeInput.setText("50 000 colones");
    jPrizeInput.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(java.awt.event.FocusEvent evt) {
        jPrizeInputFocusGained(evt);
      }
      public void focusLost(java.awt.event.FocusEvent evt) {
        jPrizeInputFocusLost(evt);
      }
    });

    jStartButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jStartButton.setText("Iniciar");
    jStartButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jStartButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jStartButtonActionPerformed(evt);
      }
    });

    jCantarNumButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jCantarNumButton.setText("Cantar numero");
    jCantarNumButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jCantarNumButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jCantarNumButtonActionPerformed(evt);
      }
    });

    jNumerosCantados.setEditable(false);
    jNumerosCantados.setBackground(new java.awt.Color(255, 255, 255));
    jNumerosCantados.setColumns(20);
    jNumerosCantados.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jNumerosCantados.setLineWrap(true);
    jNumerosCantados.setRows(5);
    jScrollPane1.setViewportView(jNumerosCantados);

    jWinnerLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jWinnerLabel.setText("Cartones ganadores:");

    jEndGame.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
    jEndGame.setText("Terminar Juego");
    jEndGame.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jEndGame.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jEndGameActionPerformed(evt);
      }
    });

    jCongratsLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
    jCongratsLabel.setForeground(new java.awt.Color(0, 204, 255));
    jCongratsLabel.setText("Felicidades!");

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
      layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(layout.createSequentialGroup()
        .addContainerGap()
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
              .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPrizeLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPrizeInput, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
              .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jCartonesLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                  .addGroup(layout.createSequentialGroup()
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jCongratsLabel)
                    .addGap(49, 49, 49))
                  .addGroup(layout.createSequentialGroup()
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jEndGame, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jJugadoresLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
              .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jConfLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                  .addComponent(jCantarNumButton)
                  .addComponent(jConfComBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(152, 152, 152)))
            .addContainerGap())
          .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
              .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jWinnerLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jStartButton, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(213, 213, 213))
              .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65))))))
    );
    layout.setVerticalGroup(
      layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(layout.createSequentialGroup()
        .addContainerGap()
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jTitulo)
          .addComponent(jPrizeInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jPrizeLabel))
        .addGap(18, 18, 18)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jConfComBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jConfLabel))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(jCantarNumButton)
        .addGap(4, 4, 4)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jStartButton)
          .addComponent(jWinnerLabel))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(jCongratsLabel)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addComponent(jCartonesLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jJugadoresLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jEndGame))
        .addContainerGap())
    );

    pack();
  }
}
