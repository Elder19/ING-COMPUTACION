/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ventanas;

import java.awt.Color;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import logicadenegocios.Juego;

/**
 * La clase `RegistrarJugador` representa una ventana que permite al usuario registrar un jugador para un juego. El usuario debe proporcionar un nombre, una cédula válida y una dirección de correo electrónico válida para registrar al jugador. La cédula debe tener 9 dígitos y el correo electrónico debe tener uno de los dominios permitidos (gmail.com, hotmail.com, estudiantec.cr o itcr.ac.cr).
 *
 * @author Eyden
 * @author Brasly V
 * @author Elder L
 */
public class RegistrarJugador extends JDialog {
  // Variables declaration
  private javax.swing.JLabel jCedula;
  private javax.swing.JTextField jCedulaInput;
  private javax.swing.JTextField jCorreoInput;
  private javax.swing.JLabel jEmail;
  private javax.swing.JButton jExit;
  private javax.swing.JLabel jNombre;
  private javax.swing.JTextField jNombreInput;
  private javax.swing.JButton jRegistrar;
  private javax.swing.JLabel jTitulo;
  private Juego juegoActual;
  // End of variables declaration

  /**
   * Crea una nueva instancia de la ventana de registro de jugador.
   *
   * @param pMenu   La ventana de menú principal.
   * @param pModal  Un indicador de si la ventana es modal o no.
   * @param pJuego  El juego al que pertenecerá el jugador.
   */
  public RegistrarJugador(VentanaPreJuego pMenu, boolean pModal, Juego pJuego) {
    super(pMenu, pModal);
    juegoActual = pJuego;
    initComponents();
    this.setLocationRelativeTo(null);
  }

  /**
   * Acción realizada cuando el campo de entrada de texto del nombre gana el enfoque. Limpia el texto de sugerencia si es igual al valor por defecto.
   *
   * @param evt El evento de enfoque que desencadena esta función.
   */
  private void jNombreInputFocusGained(java.awt.event.FocusEvent evt) {
    if (jNombreInput.getText().equals("Ejemplo: Eyden Su")) {
      jNombreInput.setText("");
      jNombreInput.setForeground(new Color(0,0,0));
    }
  }

  /**
   * Acción realizada cuando el campo de entrada de texto del nombre pierde el enfoque. Restaura el texto de sugerencia si el campo está vacío.
   *
   * @param evt El evento de enfoque que desencadena esta función.
   */
  private void jNombreInputFocusLost(java.awt.event.FocusEvent evt) {
    if (jNombreInput.getText().equals("")) {
      jNombreInput.setText("Ejemplo: Eyden Su");
      jNombreInput.setForeground(new Color(153,153,153));
    }
  }

  /**
   * Acción realizada cuando el campo de entrada de texto de la cédula gana el enfoque. Limpia el texto de sugerencia si es igual al valor por defecto.
   *
   * @param evt El evento de enfoque que desencadena esta función.
   */
  private void jCedulaInputFocusGained(java.awt.event.FocusEvent evt) {
    if (jCedulaInput.getText().equals("Ejemplo: 123456789")) {
      jCedulaInput.setText("");
      jCedulaInput.setForeground(new Color(0,0,0));
    }
  }

  /**
   * Acción realizada cuando el campo de entrada de texto de la cédula pierde el enfoque. Restaura el texto de sugerencia si el campo está vacío.
   *
   * @param evt El evento de enfoque que desencadena esta función.
   */
  private void jCedulaInputFocusLost(java.awt.event.FocusEvent evt) {
    if (jCedulaInput.getText().equals("")) {
      jCedulaInput.setText("Ejemplo: 123456789");
      jCedulaInput.setForeground(new Color(153,153,153));
    }
  }

  /**
   * Acción realizada cuando el campo de entrada de texto del correo electrónico pierde el enfoque. Restaura el texto de sugerencia si el campo está vacío.
   *
   * @param evt El evento de enfoque que desencadena esta función.
   */
  private void jCorreoInputFocusGained(java.awt.event.FocusEvent evt) {
    if (jCorreoInput.getText().equals("Ejemplo: esd@gmail.com")) {
      jCorreoInput.setText("");
      jCorreoInput.setForeground(new Color(0,0,0));
    }
  }

  /**
   * Acción realizada al hacer clic en el botón "Regresar". Cierra la ventana actual.
   *
   * @param evt El evento de acción que desencadena esta función.
   */
  private void jCorreoInputFocusLost(java.awt.event.FocusEvent evt) {
    if (jCorreoInput.getText().equals("")) {
      jCorreoInput.setText("Ejemplo: esd@gmail.com");
      jCorreoInput.setForeground(new Color(153,153,153));
    }
  }

  /**
   * Acción realizada al hacer clic en el botón "Registrar". Valida y registra un jugador con los datos proporcionados por el usuario.
   *
   * @param evt El evento de acción que desencadena esta función.
   */
  private void jRegistrarActionPerformed(java.awt.event.ActionEvent evt) {
    
    String regex = ".*@(gmail\\.com|hotmail\\.com|estudiantec\\.cr|itcr\\.ac\\.cr)$";
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(jCorreoInput.getText());
     
    if (jCedulaInput.getText().length() != 9 || jCedulaInput.getText().equals("Ejemplo: 123456789")) {
      JOptionPane.showMessageDialog(null, "Error: Digite una cédula verdadera.", "Error", JOptionPane.ERROR_MESSAGE);
      jCedulaInput.setText("");
    } else if (juegoActual.buscarJugador(jCedulaInput.getText()) != null) {
      JOptionPane.showMessageDialog(null, "Error: La cedula ya ha sido registrada.", "Error", JOptionPane.ERROR_MESSAGE);
      jCedulaInput.setText("");
    } else if (jNombreInput.getText().equals("") || jNombreInput.getText().equals("Ejemplo: Eyden Su")) {
      JOptionPane.showMessageDialog(null, "Error: Digite un nombre.", "Error", JOptionPane.ERROR_MESSAGE);
      jNombreInput.setText("");
    } else if (jCorreoInput.getText().equals("") || jCorreoInput.getText().equals("Ejemplo: esd@gmail.com")) {
      JOptionPane.showMessageDialog(null, "Error: Digite un correo.", "Error", JOptionPane.ERROR_MESSAGE);
      jCorreoInput.setText("");
    } else if (!matcher.matches()){
      JOptionPane.showMessageDialog(null, "Error: El correo no es válido o no tiene uno de los dominios deseados al final", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
      juegoActual.agregarJugador(jNombreInput.getText(), jCedulaInput.getText(), jCorreoInput.getText());
      JOptionPane.showMessageDialog(null, "Jugador registrado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
      juegoActual.generarCSV();
      jCorreoInput.setText("");
      jNombreInput.setText("");
      jCedulaInput.setText("");
    }
  }

  private void jExitActionPerformed(java.awt.event.ActionEvent evt) {
    dispose();
  }

  /**
   * This method is called from within the constructor to initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is always
   * regenerated by the Form Editor.
   */
  @SuppressWarnings("unchecked")
  // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
  private void initComponents() {

    jTitulo = new javax.swing.JLabel();
    jNombre = new javax.swing.JLabel();
    jCedula = new javax.swing.JLabel();
    jEmail = new javax.swing.JLabel();
    jNombreInput = new javax.swing.JTextField();
    jCedulaInput = new javax.swing.JTextField();
    jCorreoInput = new javax.swing.JTextField();
    jRegistrar = new javax.swing.JButton();
    jExit = new javax.swing.JButton();

    setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
    setResizable(false);

    jTitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    jTitulo.setText("Registrar jugador");

    jNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jNombre.setText("Nombre:");

    jCedula.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jCedula.setText("Cedula:");

    jEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jEmail.setText("Correo:");

    jNombreInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jNombreInput.setForeground(new java.awt.Color(153, 153, 153));
    jNombreInput.setText("Ejemplo: Eyden Su");
    jNombreInput.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(java.awt.event.FocusEvent evt) {
        jNombreInputFocusGained(evt);
      }
      public void focusLost(java.awt.event.FocusEvent evt) {
        jNombreInputFocusLost(evt);
      }
    });

    jCedulaInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jCedulaInput.setForeground(new java.awt.Color(153, 153, 153));
    jCedulaInput.setText("Ejemplo: 123456789");
    jCedulaInput.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(java.awt.event.FocusEvent evt) {
        jCedulaInputFocusGained(evt);
      }
      public void focusLost(java.awt.event.FocusEvent evt) {
        jCedulaInputFocusLost(evt);
      }
    });

    jCorreoInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jCorreoInput.setForeground(new java.awt.Color(153, 153, 153));
    jCorreoInput.setText("Ejemplo: esd@gmail.com");
    jCorreoInput.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(java.awt.event.FocusEvent evt) {
        jCorreoInputFocusGained(evt);
      }
      public void focusLost(java.awt.event.FocusEvent evt) {
        jCorreoInputFocusLost(evt);
      }
    });

    jRegistrar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jRegistrar.setText("Registrar");
    jRegistrar.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jRegistrarActionPerformed(evt);
      }
    });

    jExit.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    jExit.setText("Regresar");
    jExit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jExitActionPerformed(evt);
      }
    });

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
      layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(layout.createSequentialGroup()
        .addContainerGap()
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addGroup(layout.createSequentialGroup()
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
              .addComponent(jTitulo)
              .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                  .addComponent(jNombre)
                  .addComponent(jCedula)
                  .addComponent(jEmail))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                  .addComponent(jCorreoInput, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                  .addComponent(jCedulaInput)
                  .addComponent(jNombreInput))))
            .addGap(0, 82, Short.MAX_VALUE))
          .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
            .addComponent(jExit)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jRegistrar)))
        .addContainerGap())
    );
    layout.setVerticalGroup(
      layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(layout.createSequentialGroup()
        .addContainerGap()
        .addComponent(jTitulo)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jNombre)
          .addComponent(jNombreInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(18, 18, 18)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jCedula)
          .addComponent(jCedulaInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(18, 18, 18)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jEmail)
          .addComponent(jCorreoInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jRegistrar)
          .addComponent(jExit))
        .addContainerGap())
    );

    pack();
  }
}
