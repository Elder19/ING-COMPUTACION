package logicadenegocios;
public class Administrativo extends Funcionario {
  private int horasExtraQuincenales;
  private double montoPorHoraExtra; 
  public Administrativo (String pNombre, String pIdentificacion, Double pSalarioBase,int pDiaContratacion, int pMesContratacion,
                  int pAnoContratacion,int pHorasExtra) {
    super (pNombre, pIdentificacion,pSalarioBase,pAnoContratacion,pMesContratacion,pDiaContratacion);
    horasExtraQuincenales = pHorasExtra;
    montoPorHoraExtra = 0.0;
   }
} 