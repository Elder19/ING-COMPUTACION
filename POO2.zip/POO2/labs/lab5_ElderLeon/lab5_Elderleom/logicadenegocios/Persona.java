package logicadenegocios;

import java.time.LocalDate;
import java.time.Period;
/**
 *propuesta de gerarquia
 * 
 * @author (elder) 
 * @version (30/09)
 */
public class Persona {
  private String nombre;
  private String identificacion;
  private LocalDate fechaNacimiento;
  private EstadoCivil estadoCivil;
  private Direccion miDireccion; 
  public Persona(String pNombre, String pIdentificacion) {
    nombre= pNombre;
    identificacion = pIdentificacion;
  }
  
  public Persona (String pNombre, String pIdentificacion, int pDia, int pMes, int pAno, EstadoCivil pEstadoCivil) {
    nombre = pNombre;
    identificacion = pIdentificacion;
    fechaNacimiento = LocalDate.of(pAno,pMes,pDia);
    estadoCivil = pEstadoCivil;
  }

  public void setFechaNacimiento(int pDia, int pMes, int pAno){
    fechaNacimiento = LocalDate.of(pAno,pMes,pDia);
  }
  
  public int calcularEdad() {
    LocalDate ahora = LocalDate.now ();
    int edad = Period.between(fechaNacimiento, ahora). getYears();
    return edad;
  }
  
  public String toString (){
    String cadena = "";
    cadena = "Nombre: " + nombre + "\n";
    cadena+= "identificacion" + this.identificacion + "\n";
    return cadena;
  }
}
