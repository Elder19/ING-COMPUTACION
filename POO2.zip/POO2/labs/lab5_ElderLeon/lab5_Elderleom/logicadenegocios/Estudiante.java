package logicadenegocios;


/**
 * Write a description of class Estudiante here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Estudiante extends Persona
{
  private int carnet;
  
  public Estudiante(String pNombre, String pIdentificacion, int pCarnet) {
    super(pNombre, pIdentificacion);
    carnet = pCarnet;
  }

  public Estudiante (String pNombre, String pIdentificacion, int pDia, int pMes, int pAno, EstadoCivil pEstadoCivil, int pCarnet) {
    super(pNombre, pIdentificacion, pDia, pMes, pAno, pEstadoCivil);
    carnet = pCarnet;
  }
  
  // sobre escritura del padre
  public String toString(){
    String cadena = "";
    cadena = super.toString() + "\n";
    cadena += "Carnet:  "+ carnet;
    return cadena;
  }
}
