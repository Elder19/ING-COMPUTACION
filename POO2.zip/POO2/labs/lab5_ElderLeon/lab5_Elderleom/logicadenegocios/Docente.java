package logicadenegocios;


/**
 * Write a description of class Docente here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Docente extends Funcionario{
  private int indiceH;
  private boolean esInvestigadorConsolidado; 
  private double ampliacionJornada;

  public Docente (String pNombre, String pIdentificacion, Double pSalarioBase,int pDiaContratacion, int pMesContratacion, int pAnoContratacion,int pIndiceH) {
    super (pNombre, pIdentificacion,pSalarioBase,pAnoContratacion,pMesContratacion,pDiaContratacion);
    indiceH= pIndiceH;
    esInvestigadorConsolidado= false;
    ampliacionJornada=0.0 ;
   }
}
