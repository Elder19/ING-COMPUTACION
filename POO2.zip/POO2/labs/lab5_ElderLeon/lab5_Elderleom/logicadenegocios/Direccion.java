package logicadenegocios;


/**
 * Write a description of class Direccion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Direccion {
  private String provincia; 
  private String canton; 
  private String distrito; 
  private String senas;

  public Direccion(String pProvincia, String pCanton, String pDistrito, String pSenas) {
    provincia = pProvincia; 
    canton = pCanton; 
    distrito = pDistrito;
    senas = "No especificado";
    }

  public String toString () {
    String cadena = "";
    cadena = "Provincia" + provincia + "\n";
    cadena += "Canton"+ canton + "\n";
    cadena += "Distrito"+ distrito;
    return cadena;
  }
}
