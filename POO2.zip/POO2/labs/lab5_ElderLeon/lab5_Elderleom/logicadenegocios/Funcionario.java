package logicadenegocios;

import java.time.LocalDate;
import java.time.Period;
/**
 * Write a description of class Funcionario here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Funcionario extends Persona{
  private double salarioBase;
  private LocalDate fechaContratacion; 
  public Funcionario(String pNombre, String pIdentificacion, Double pSalarioBase,int pDiaContratacion, int pMesContratacion, int pAnoContratacion) {
    super (pNombre, pIdentificacion);
    salarioBase = pSalarioBase;
    fechaContratacion = LocalDate.of(pAnoContratacion,pMesContratacion,pDiaContratacion);   
  }

  public int calcularAnosLaborados(){
    LocalDate ahora = LocalDate.now();
    int anosLaborados = Period.between(fechaContratacion, ahora).getYears();
    return anosLaborados;
  } 

  public String toString() {
    String msg = "";
    msg = super.toString() + "Salario bruto: "+ salarioBase +"\n";
    msg += "Anualidades cumpĺidas: "+ calcularAnosLaborados() + "\n";
    return msg;
  }
}
