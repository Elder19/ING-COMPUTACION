package logicadenegocios;


/**
 * Enumeration class EstadoCivil - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum EstadoCivil {
  CASADO, SOLTERO, UNION_LIBRE, DIVORSIADO, VIUDO
}
