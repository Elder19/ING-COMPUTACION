package aplicacion;

import logicadenegocios.Persona;
import logicadenegocios.Estudiante;
import logicadenegocios.Docente;
import logicadenegocios.Administrativo;
import logicadenegocios.EstadoCivil;
import java.util.LinkedList;

/**
 * Write a description of class AppEjemplo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AppEjemplo{
  public static void main(String[] args) {
    LinkedList<Persona> lista = new LinkedList<Persona>();
    Persona persona1 = new Estudiante ("Luis Soto", "8015845",2005412);
    Persona persona2 = new Docente ("miguel", "7845",150000.2,8,8,2000,5);
    Persona persona3 = new Administrativo ("ana", "111222",705441.2,10,8,2005,10);
    lista.add(persona1);
    lista.add(persona2);
    lista.add(persona3);
    for (Persona personaActual: lista){
      if (personaActual instanceof Estudiante){
        system.out.pritnln("\n Estudiante: \n"+ personaActual.toString());
      }
      else{
        system.out.println("\n Funcionario: \n"+ personaActual.toString());
      }
    }
  }
}

