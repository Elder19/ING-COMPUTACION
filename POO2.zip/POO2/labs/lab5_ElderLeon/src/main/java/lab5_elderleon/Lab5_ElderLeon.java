/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package lab5_elderleon;

/**
 *
 * @author Usuario
 */
public class Lab5_ElderLeon {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
