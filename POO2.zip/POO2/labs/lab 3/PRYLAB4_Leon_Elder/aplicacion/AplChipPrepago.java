package aplicacion;

import logicadenegocios.ChipPrepago;
import logicadenegocios.Llamada;
import logicadenegocios.Mensaje;
import logicadenegocios.Cliente;

public class AplChipPrepago {
  public static void main (String args[]) {

  // Declaracion del puntero e Instanciacion de los objetos de tipo ChipPrepagao
  ChipPrepago chipPrepago1 = new ChipPrepago ("Claro");
  ChipPrepago chipPrepago2 = new ChipPrepago ("Kolbi");
  ChipPrepago chipPrepago3 = new ChipPrepago ("Movistar");
  ChipPrepago chipPrepago4 = new ChipPrepago ("Kolbi");
  
  // Declaracion del puntero e Instanciacion de los objetos de tipo Cliente 
  Cliente cliente1 = new Cliente ("Luis Soto", "1-101-233");
  Cliente cliente2 = new Cliente ("Ana Orozco", "2-845-736");
  Cliente cliente3 = new Cliente ("Tony Stark", "8-135-785");
        
  // Envio de mensajes a los objetos 
  chipPrepago1.activar(cliente1);
  
  // Imprision de salidas en consola 
  System.out.println(chipPrepago1);
  System.out.println(chipPrepago2);
  
  chipPrepago1.recargar(500);
  System.out.println(chipPrepago1);
  
  chipPrepago2.activar(cliente2);
  chipPrepago1.llamar (12,chipPrepago2);
  
  System.out.println(chipPrepago1);
  System.out.println(chipPrepago2);
  }

}