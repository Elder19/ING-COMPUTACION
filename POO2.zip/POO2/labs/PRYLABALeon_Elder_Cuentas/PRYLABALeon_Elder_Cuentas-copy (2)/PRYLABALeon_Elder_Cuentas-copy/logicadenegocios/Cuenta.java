package logicadenegocios;
import java.util.*;
import java.text.*;
 
/**
 * Desarrollo del lab 4
 * clase cuenta
 * @author (Elder) 
 * @version (29/08/23)
 */

public class Cuenta
{
  private int numCuenta = 0;
  private Cliente duenio= null;
  private double saldo = 0;
  private ArrayList<Operacion> operaciones;
  private int numOperaciones = 0;
  private Date fechaCreacion;
  private static int cantCuentas = 0;
  public Cuenta( Cliente pDuenio, double pMonto ){
    setDuenio( pDuenio );
    operaciones = new ArrayList<Operacion>();
    setFechaCreacion();
    depositar(pMonto);
    cantCuentas++;
    numCuenta= cantCuentas;
  }
  
  public String depositar(double pMonto) {
    saldo += pMonto;
    Operacion nuevaOperacion = new Operacion( ++numOperaciones, "deposito", pMonto );
    operaciones.add( nuevaOperacion );
    return "Saldo actual: " + saldo;
  }

  private boolean validarRetiro( double pMonto ) {
    return pMonto <= saldo; 
  }
  
  public String retirar(double pMonto) {
    if (validarRetiro(pMonto)) {
      saldo -= pMonto;
      Operacion nuevaOperacion= new Operacion( ++numOperaciones, "retiro", pMonto);
      operaciones.add(nuevaOperacion);
      return "Saldo actual: " + saldo;
    } else
      return "No tiene suficiente dinero";
  }

  public String toString(){
    String msg;
    msg = "Cuenta Número: " + getNumCuenta() + "\n";
    msg += "Fecha creada: " + getFechaCreacion() + "\n";
    msg += duenio.toString();
    msg += "Saldo: " + getSaldo() + "\n";
    msg += "Registro de Operaciones" + "\n";
    msg += " Número " + " Fecha " + " Operación " + " Monto " +"\n";
    for ( int i = 0; i < operaciones.size(); i++ ){
      Operacion unaOp= (Operacion) operaciones.get(i); 
      msg += unaOp.toString();
    }
    return msg;
  }
  
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null) {
      return false;
    }
    if (getClass() != o.getClass()) {
      return false;
    }
    Cuenta cuenta = (Cuenta) o;
    return duenio.equals(cuenta.duenio) && numCuenta == cuenta.numCuenta;
  }

  public void setFechaCreacion() {
    Calendar calendario;
    calendario = Calendar.getInstance();
    fechaCreacion= (Date)calendario.getTime();
  }
  
  public String getFechaCreacion() {
  SimpleDateFormat mascara = new SimpleDateFormat("dd/MM/yy");
  return mascara.format(fechaCreacion);
  }  
  
  public int getNumCuenta() {
    return numCuenta;
  }
  
  public Cliente getDuenio() {
   return duenio;
  }
  
  public double getSaldo(){
    return saldo;
  }
  
  public void setNumCuenta(int pNumCuenta){
    pNumCuenta = numCuenta;
  }
    
  public void setDuenio(Cliente pCliente) {
      duenio=pCliente;
  }

   public void setSaldo(double pSaldo) {
    saldo = pSaldo;
  }
}
