package logicadenegocios;

/**
 * clase cliente
 * 
 * @author (elder) 
 * @version (31/08/23)
 */
public class Cliente
{
  private String cedula;
  private String nombre;
  private String apellido;
  
  public Cliente( String pCedula, String pNombre, String pApellido) {
    setCedula( pCedula );
    setNombre( pNombre );
    setApellido( pApellido );
  }
  
  public String toString( ) {
    String msg = "";
    msg = "Cédula: " + getCedula() + "\n";
    msg += "Nombre: " + getNombre() + " " + getApellido() + "\n"; 
    return msg;
  }
  
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    
    if (o == null) {
      return false;
    }
    
    if (getClass() != o.getClass()) {
      return false;
    }
    Cliente cliente = (Cliente) o;
    return cedula.equals(cliente.cedula) && nombre == cliente.nombre;
  }
  
  public String getCedula() {
    return cedula;
  }
  
  public void setCedula(String pCedula) {
    cedula = pCedula;
  }

  public String getNombre() {
    return nombre;
  }
  
  public void setNombre(String pNombre) {
    nombre= pNombre;
  }

  public String getApellido(){
    return apellido;
  }
  
   public void setApellido(String pApellido) {
    apellido= pApellido;
  }
}
