package aplicacion;
import logicadenegocios.Cliente;
import logicadenegocios.Cuenta;

public class AplCuenta
{
  public static void main (String args[]){
    Cliente cliente1 = new Cliente("134", "Bryan", "Rojas");
    Cliente cliente2 = new Cliente("356", "Alberto", "Hermandez");
    
    Cuenta cuenta1 = new Cuenta(cliente1, 3500.0);
    Cuenta cuenta2 = new Cuenta(cliente2, 1700.0);
    
    cuenta1.depositar(1700.0);
    cuenta1.depositar(2200.0);
    
    cuenta1.retirar(500.0);
    cuenta2.retirar(400.0);
    
    System.out.println(cuenta1.toString());
    System.out.println(cuenta2.toString());
    
    System.out.println("Prueba del Metodo equals: ");
    System.out.println(cuenta1 == cuenta2);
    System.out.println(cuenta1.equals(cuenta2));
    System.out.println(cuenta1 == cuenta2);
    System.out.println(cuenta1.equals(cuenta2));
  }
}
