import java.util.Random;

/**
 * Abtraccion de la clase radio para efectos academicos
 * 
 * @author (Elder leon perez) 
 * @version (1.0)
 */
public class Radio {
  private String marca;
  private boolean estaEncendido;
  private double frecuencia;
  private String banda;
  private int volumen;
  private Disco disco;
  // Atributos de clase o estaticos
  private static int cantRadios=0;
  private static final double RANGOS_FRECUENCIA[]= new double[] {80.1, 107.5};
  private static final String BANDAS_DISPONIBLES[]= new String[] {"AM","FM1","FM2"};
    
  public Radio(String pMarca) {
    marca=pMarca;
    estaEncendido= false;
    frecuencia= 80.1;
    banda= "AM";
    volumen = 0; 
    // incrementar el contador de radios accediendo a un atributo de la clase
    cantRadios++;
  }
    
  public boolean encender() {
    return (estaEncendido = true);
  }
    
  public boolean apagar() {
    return (estaEncendido= false);
  }
    
  public void cambiarFrecuencia(double pFrecuencia) {
    if (estaEncendido && verificarFrecuencia(pFrecuencia)) { 
      frecuencia= pFrecuencia;
    }
    
  }
    
  public void cambiarFrecuencia() {
    Random randomObject= new Random();
    double frecuencia=80.1 + (107.5 -80.1)*randomObject.nextDouble();
    if (estaEncendido && verificarFrecuencia(frecuencia)) {
      this.frecuencia = frecuencia;
    }
  }
    
  private boolean verificarFrecuencia(double pFrecuencia) {
    return (pFrecuencia>= RANGOS_FRECUENCIA[0]&& pFrecuencia <= RANGOS_FRECUENCIA[1]? true : false);     
  }
    
  public void cambiarBanda(String pBanda) {
    if (estaEncendido && verificarBanda(pBanda)) {
      banda=pBanda;
    }
  }
    
  private boolean verificarBanda(String pBanda) {
    for (String bandaActual: BANDAS_DISPONIBLES) {
      if (bandaActual.equals(pBanda)) {
        return true;
      }
    }
    return false;
  } 
    
  public int subirVolumen() {
    if (estaEncendido) {
      volumen +=1;
    }
    return volumen;
  }
    
  public int bajarVolumen() {
    if (estaEncendido) {
     volumen -=1;
    }
    return volumen;
  }
    
  public String reproducir() {
    if (estaEncendido && tieneDisco()) {
      return "Reproduciendo pista 1 ";
    }
    return "Radio is turn off | No disc. ";
  }
    
  public String reproducir (int pPista) {
    if (estaEncendido && tieneDisco() && disco.getCantidadCanciones() <= pPista) {
      return "Reproduciendo pista "+ pPista;
    }
    return "Radio is turn off | No disc. | No valid track";  
  }
    
  private boolean tieneDisco() {
    if (disco!= null) {
      return true;
    }
    return false; 
  }
      
  // contecto No estatico 
  // puede invocar miembros estaticos y no estaticos  (atrributos y metodos)
  public String insertarDisco(Disco pDisco) {
    if (estaEncendido) {
      disco=pDisco;
      return disco.toString();
    }
    return "Radio is off. ";
    }
    
  // contexto estatico: acceder a atributos estaticos y metodos estaticos 
  public static int getCantidadRadios() {
    return cantRadios;
  }  
}

