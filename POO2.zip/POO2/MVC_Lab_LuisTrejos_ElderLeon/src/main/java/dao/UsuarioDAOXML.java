/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import modelo.*;
import java.util.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.DOMException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.xml.sax.SAXException;
import java.io.File;
import java.io.IOException;

/**
 * Implementación de la interfaz UsuarioDAO que utiliza un archivo XML como
 * fuente de datos. Permite realizar operaciones relacionadas con usuarios, como
 * inicio de sesión, carga de la lista de usuarios, cambio de contraseña y
 * registro de nuevos usuarios. El archivo XML se utiliza para almacenar la
 * información de los usuarios.
 *
 * @author Luis Trejos
 * @author Elder León
 * @version 1.0
 */
public class UsuarioDAOXML implements UsuarioDAO {

  /**
   * Inicia sesión de un usuario verificando las credenciales proporcionadas.
   *
   * @param usuario el objeto Usuario que contiene el nombre de usuario y la
   * contraseña.
   * @return el objeto Usuario correspondiente si las credenciales son válidas,
   * o null si no coincide ningún usuario.
   */
  @Override
  public Usuario iniciarSesion(Usuario usuario) {
    return (iniciarSesion(usuario.getNombre(), usuario.getContrasenia()));
  }

  /**
   * Inicia sesión de un usuario verificando las credenciales proporcionadas.
   *
   * @param pUsuario el nombre de usuario.
   * @param pContrasenia la contraseña.
   * @return el objeto Usuario correspondiente si las credenciales son válidas,
   * o null si no coincide ningún usuario.
   */
  public Usuario iniciarSesion(String pUsuario, String pContrasenia) {
    ArrayList<Usuario> usuarios = cargarListaUsuarios();
    for (Usuario usuario : usuarios) {
      if (pUsuario.equals(usuario.getNombre()) && pContrasenia.equals(usuario.getContrasenia())) {
        return usuario;
      }
    }
    return null;
  }

  /**
   * Carga la lista de usuarios desde el archivo XML.
   *
   * @return una lista de objetos Usuario cargada desde el archivo XML.
   */
  @Override
  public ArrayList<Usuario> cargarListaUsuarios() {
    try {
      File archivoXml = new File("registros.xml");
      if (!archivoXml.exists()) {
        return null;
      }
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
      Document archivo = builder.parse(archivoXml);
      archivo.getDocumentElement().normalize();

      NodeList listaUsuarios = archivo.getElementsByTagName("usuario");

      ArrayList<Usuario> usuarios = new ArrayList<>();

      for (int i = 0; i < listaUsuarios.getLength(); i++) {
        Node nodoUsuario = listaUsuarios.item(i);
        if (nodoUsuario.getNodeType() == Node.ELEMENT_NODE) {
          Element elementoUsuario = (Element) nodoUsuario;
          String nombre = elementoUsuario.getElementsByTagName("nombre").item(0).getTextContent();
          String clave = elementoUsuario.getElementsByTagName("clave").item(0).getTextContent();
          Usuario usuario = new Usuario(nombre, clave);
          usuarios.add(usuario);
        }
      }
      return usuarios;
    } catch (ParserConfigurationException | SAXException | IOException ex) {
      return null;
    }
  }

  /**
   * Cambia la contraseña de un usuario.
   *
   * @param nombreUsuario el nombre de usuario.
   * @param contrasenia la contraseña actual.
   * @param contraseniaNueva la nueva contraseña.
   * @return true si el cambio de contraseña se realiza correctamente, false en
   * caso contrario.
   */
  @Override
  public boolean cambiarContrasenia(String nombreUsuario, String contrasenia, String contraseniaNueva) {
    ArrayList<Usuario> listaU = cargarListaUsuarios();
    for (Usuario usuario : listaU) {
      if (nombreUsuario.equals(usuario.getNombre())) {
        if (contrasenia.equals(usuario.getContrasenia())) {
          usuario.setContrasenia(contraseniaNueva);
          try {
            File archivoXml = new File("registros.xml");
            if (!archivoXml.exists()) {
              return false;
            }
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document archivo = builder.parse(archivoXml);
            archivo.getDocumentElement().normalize();
            NodeList listaUsuarios = archivo.getElementsByTagName("usuario");
            for (int i = 0; i < listaUsuarios.getLength(); i++) {
              Node nodoUsuario = listaUsuarios.item(i);
              if (nodoUsuario.getNodeType() == Node.ELEMENT_NODE) {
                Element elementoUsuario = (Element) nodoUsuario;
                String nombre = elementoUsuario.getElementsByTagName("nombre").item(0).getTextContent();
                if (nombre.equals(nombreUsuario)) {
                  elementoUsuario.getElementsByTagName("clave").item(0).setTextContent(contraseniaNueva);
                  TransformerFactory transFactory = TransformerFactory.newInstance();
                  Transformer transformer = transFactory.newTransformer();
                  DOMSource source = new DOMSource(archivo);
                  StreamResult result = new StreamResult(new File("registros.xml"));
                  transformer.transform(source, result);
                  return true;
                }
              }
            }
          } catch (ParserConfigurationException | SAXException | IOException | TransformerException ex) {
            return false;
          }
        }
      }
    }

    return false;
  }

  /**
   * Registra un nuevo usuario en el archivo XML.
   *
   * @param usuario el objeto Usuario que representa al nuevo usuario a
   * registrar.
   * @return true si el registro se realiza correctamente, false en caso
   * contrario.
   */
  @Override
  public boolean registrarUsuario(Usuario usuario) {
    try {
      File archivoXml = new File("registros.xml");
      Document archivo;
      if (archivoXml.exists()) {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        archivo = docBuilder.parse(archivoXml);
      } else {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        archivo = docBuilder.newDocument();
        archivo.appendChild(archivo.createElement("usuarios"));
      }

      Node nodoRaiz = archivo.getDocumentElement();

      Element nuevoUsuario = archivo.createElement("usuario");
      Element nombreElement = archivo.createElement("nombre");
      nombreElement.setTextContent(usuario.getNombre());

      Element claveElement = archivo.createElement("clave");
      claveElement.setTextContent(usuario.getContrasenia());
      nuevoUsuario.appendChild(nombreElement);
      nuevoUsuario.appendChild(claveElement);
      nodoRaiz.appendChild(nuevoUsuario);
      TransformerFactory transFactory = TransformerFactory.newInstance();
      Transformer transformer = transFactory.newTransformer();
      DOMSource source = new DOMSource(archivo);
      StreamResult result = new StreamResult(new File("registros.xml"));
      transformer.transform(source, result);

      return true;
    } catch (TransformerConfigurationException ex) {
      return false;
    } catch (ParserConfigurationException | IOException | SAXException | DOMException | TransformerException ex) {
      return false;
    }

  }

}
