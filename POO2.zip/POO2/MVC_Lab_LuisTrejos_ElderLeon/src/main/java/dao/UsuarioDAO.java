/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import java.util.ArrayList;
import modelo.*;


/**
 * La interfaz UsuarioDAO proporciona métodos para interactuar con los datos de usuario en una capa de acceso a datos.
 * Define operaciones como iniciar sesión, cargar listas de usuarios, cambiar contraseñas y registrar nuevos usuarios.
 * Las clases que implementen esta interfaz deben proporcionar la implementación real de estos métodos.
 *
 * @author Luis Trejos
 * @author Elder León
 * @version 1.0
 */
public interface UsuarioDAO {
  Usuario iniciarSesion(Usuario usuario);
  ArrayList<Usuario> cargarListaUsuarios();
  boolean cambiarContrasenia(String nombreUsuario, String contrasenia, String contraseniaNueva);
  boolean registrarUsuario(Usuario usuario);
}
