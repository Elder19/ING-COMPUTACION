/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.*;
import modelo.*;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * La clase SalaDAOXML implementa la interfaz SalaDAO y proporciona la
 * funcionalidad para interactuar con el almacenamiento en formato XML. Permite
 * cargar, registrar y obtener salas utilizando un archivo XML como fuente de
 * datos.
 *
 * El archivo XML debe seguir una estructura específica para almacenar la
 * información de las salas.
 *
 * @author Luis Trejos
 * @author Elder León
 * @version 1.0
 */
public class SalaDAOXML implements SalaDAO {

  /**
   * Metodo que permite cargar la lista de salas
   *
   * @return lista de salas almacenadas
   */
  @Override
  public ArrayList<Sala> cargarListaSalas() {
    try {
      File archivoXml = new File("salas.xml");
      if (!archivoXml.exists()) {
        return null;
      }
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
      Document archivo = builder.parse(archivoXml);
      archivo.getDocumentElement().normalize();

      NodeList listaSalas = archivo.getElementsByTagName("sala");

      ArrayList<Sala> salas = new ArrayList<>();

      for (int i = 0; i < listaSalas.getLength(); i++) {
        Node nodo = listaSalas.item(i);
        if (nodo.getNodeType() == Node.ELEMENT_NODE) {
          Element salaElemento = (Element) nodo;
          String identificador = salaElemento.getAttribute("identificador");
          String ubicacion = salaElemento.getElementsByTagName("ubicacion").item(0).getTextContent();
          String capacidadStr = salaElemento.getElementsByTagName("capacidad").item(0).getTextContent();
          String estilo = salaElemento.getElementsByTagName("estilo").item(0).getTextContent();
          String tipo = salaElemento.getElementsByTagName("tipo").item(0).getTextContent();
          String cantidadMesasStr = salaElemento.getElementsByTagName("cantidadMesas").item(0).getTextContent();

          Sala sala = new Sala(identificador, ubicacion, Integer.parseInt(capacidadStr), estilo, tipo, Integer.parseInt(cantidadMesasStr));
          salas.add(sala);
        }
      }
      return salas;
    } catch (ParserConfigurationException | SAXException | IOException ex) {
      System.out.println("Error al cargar la lista de salas: " + ex.getMessage());
      return null;
    }
  }

  /**
   * Registra una sala en el archivo XML de registros.
   *
   * @param sala La sala a registrar.
   * @return true si la sala se registró exitosamente, false si no se pudo
   * registrar.
   */
  @Override
  public boolean registrarSala(Sala sala) {
    try {
      File archivoXml = new File("salas.xml");
      Document archivo;
      if (archivoXml.exists()) {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        archivo = docBuilder.parse(archivoXml);
      } else {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        archivo = docBuilder.newDocument();
        archivo.appendChild(archivo.createElement("salas"));
      }
      Node nodoRaiz = archivo.getDocumentElement();
      Element nuevaSala = archivo.createElement("sala");

      Element idElement = archivo.createElement("identificador");
      idElement.setTextContent(sala.getIdentificador());

      Element ubiElement = archivo.createElement("ubicacion");
      ubiElement.setTextContent(sala.getUbicacion());

      Element capacidadElement = archivo.createElement("capacidad");
      capacidadElement.setTextContent(String.valueOf(sala.getPrecio()));

      Element estiloElement = archivo.createElement("estilo");
      estiloElement.setTextContent(sala.getEstilo());

      Element tipoElement = archivo.createElement("tipo");
      tipoElement.setTextContent(sala.getTipo());

      Element mesasElement = archivo.createElement("cantidadMesas");
      mesasElement.setTextContent(String.valueOf(sala.getCantidadMesas()));

      nuevaSala.appendChild(idElement);
      nuevaSala.appendChild(ubiElement);
      nuevaSala.appendChild(capacidadElement);
      nuevaSala.appendChild(estiloElement);
      nuevaSala.appendChild(tipoElement);
      nuevaSala.appendChild(mesasElement);
      nodoRaiz.appendChild(nuevaSala);

      TransformerFactory transFactory = TransformerFactory.newInstance();
      Transformer transformer = transFactory.newTransformer();
      DOMSource source = new DOMSource(archivo);
      StreamResult result = new StreamResult(new File("salas.xml"));
      transformer.transform(source, result);

      return true;
    } catch (TransformerConfigurationException ex) {
      return false;
    } catch (ParserConfigurationException | IOException | SAXException | DOMException | TransformerException ex) {
      return false;
    }

  }

  /**
   * Obtiene una sala del archivo XML de registros basado en su identificador.
   *
   * @param pIdentificador El identificador de la sala a obtener.
   * @return La sala encontrada con el identificador dado, o null si no se
   * encontró ninguna sala.
   */
  @Override
  public Sala obtenerSala(String pIdentificador) {
    try {
      File archivoXml = new File("salas.xml");
      if (!archivoXml.exists()) {
        return null;
      }
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
      Document archivo = builder.parse(archivoXml);
      archivo.getDocumentElement().normalize();
      NodeList listaSalas = archivo.getElementsByTagName("sala");
      for (int i = 0; i < listaSalas.getLength(); i++) {
        Node nodo = listaSalas.item(i);
        if (nodo.getNodeType() == Node.ELEMENT_NODE) {
          Element salaElemento = (Element) nodo;
          String identificador = salaElemento.getElementsByTagName("identificador").item(0).getTextContent();
          if (identificador.equals(pIdentificador)) {
            String ubicacion = salaElemento.getElementsByTagName("ubicacion").item(0).getTextContent();
            int capacidad = Integer.parseInt(salaElemento.getElementsByTagName("capacidad").item(0).getTextContent());
            String estilo = salaElemento.getElementsByTagName("estilo").item(0).getTextContent();
            String tipo = salaElemento.getElementsByTagName("tipo").item(0).getTextContent();
            int cantidadMesas = Integer.parseInt(salaElemento.getElementsByTagName("cantidadMesas").item(0).getTextContent());

            Sala sala = new Sala(identificador, ubicacion, capacidad, estilo, tipo, cantidadMesas);
            return sala;
          }
        }
      }
    } catch (ParserConfigurationException | SAXException | IOException ex) {
      System.out.println(ex.getMessage());
    }
    return null;
    
  }

}
