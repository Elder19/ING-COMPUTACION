/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * La clase Sala representa una sala con un identificador único, ubicación y capacidad.
 * 
 * @author Luis Trejos
 * @author Elder León
 * @version 1.0
 */
public class Sala {
  public String identificador;
  public String ubicacion;
  public double precio;
  public String estilo;
  public String tipo;
  public int cantidadMesas;

  /**
   * Crea una nueva instancia de la clase Sala.
   * 
   * @param pIdentificador el identificador de la sala
   * @param pUbicacion la ubicación de la sala
   * @param pPrecio
   * @param pEstilo
   * @param pTipo
   * @param pCantidadMesas
   */
  public Sala(String pIdentificador, String pUbicacion, double pPrecio, String pEstilo, String pTipo, int pCantidadMesas){
    identificador = pIdentificador;
    ubicacion = pUbicacion;
    precio = pPrecio;
    estilo = pEstilo;
    tipo = pTipo;
    cantidadMesas = pCantidadMesas;
  }
  
  /**
   * Crea una nueva instancia de Sala sin especificar ningún atributo.
   * Todos los atributos son inicializados con valores predeterminados.
   */
  public Sala() {
    identificador = "";
    ubicacion = "";
    precio = 0.0;
    estilo = "";
    tipo = "";
    cantidadMesas = 0;
  }
  
 //Metodos accesores:
  
  public String getIdentificador(){
    return identificador;
  } 
  
  public void setIdentificador(String pIdentificador){
    identificador = pIdentificador;
  }
  
  public String getUbicacion(){
    return ubicacion;
  }
  
  public void setUbicacion(String pUbicacion){
    ubicacion = pUbicacion;
  }
  
  public double getPrecio() {
    return precio;
  }
  
  public void setPrecio(double pPrecio){
    precio = pPrecio;
  }
  
  public String getEstilo() {
    return estilo;
  }

  public void setEstilo(String pEstilo) {
    estilo = pEstilo;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String pTipo) {
    tipo = pTipo;
  }

  public int getCantidadMesas() {
    return cantidadMesas;
  }

  public void setCantidadMesas(int pCantidadMesas) {
    cantidadMesas = pCantidadMesas;
  }

}
