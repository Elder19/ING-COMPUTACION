/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * La clase Usuario representa un usuario con un nombre y contraseña.
 * 
 * @author Luis Trejos
 * @author Elder León
 * @version 1.0
 */
public class Usuario {
  public String nombre;
  public String contrasenia;

 /**
  * Crea una nueva instancia de la clase Usuario.
  * 
  * @param pNombre el nombre del usuario
  * @param pContrasenia la contraseña del usuario
  */
  public Usuario(String pNombre, String pContrasenia){
  nombre = pNombre;
  contrasenia = pContrasenia;
  }
  
  /**
   * Crea una nueva instancia de la clase Usuario con valores predeterminados para nombre y contraseña.
   */
  public Usuario() {
    this.nombre = "";
    this.contrasenia = "";
  }
  
  //Metodos accesores:
  
  public String getNombre() {
    return nombre;
  }
  
  public void setNombre(String pNombre) {
    nombre = pNombre;
  }
  
  public String getContrasenia(){ 
    return contrasenia;
  }
  
  public void setContrasenia(String pContrasenia) {
    contrasenia = pContrasenia;
  }
}
