package aplicacion;


import vista.*;
import controlador.*;
import dao.*;
import java.util.ArrayList;
import modelo.*;

/**
 * Clase principal del programa para gestionar las salas utilizando el patrón
 * MVC. Se encarga de inicializar la vista, el modelo y el controlador
 * correspondientes.
 *
 * @author Luis Trejos
 * @author Elder León
 * @version 1.0
 */
public class GestorSalasMVC {

  /**
   * Método principal que inicia la aplicación.
   *
   * @param args los argumentos de la línea de comandos
   */
  public static void main(String[] args) {
    LoginForm vista = new LoginForm();
    Usuario usuario = new Usuario();
    

    ControladorUsuario controladorUsuario = new ControladorUsuario(vista, usuario);
    controladorUsuario.vista.setVisible(true);
    controladorUsuario.vista.setLocationRelativeTo(null);


  }
}
