/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import javax.swing.*;
import java.awt.event.*;
import modelo.*;
import vista.*;
import dao.*;

/**
 * Controlador para la funcionalidad de inicio de sesión de usuarios. Se encarga
 * de manejar las interacciones entre la vista, el modelo y el DAO. Implementa
 * la interfaz ActionListener para gestionar eventos de los botones.
 *
 * @author Luis Trejos
 * @author Elder León
 * @version 1.0
 */
public class ControladorUsuario implements ActionListener {

  public LoginForm vista;
  public UsuarioDAO daoUsuario;
  public Usuario usuario;

  /**
   * Constructor de la clase ControladorUsuario.
   *
   * @param pVista la vista LoginForm asociada al controlador.
   * @param pUsuario el objeto Usuario asociado al controlador.
   */
  public ControladorUsuario(LoginForm pVista, Usuario pUsuario) {
    vista = pVista;
    usuario = pUsuario;
    daoUsuario = new UsuarioDAOXML();

    this.vista.btIniciarLogin.addActionListener(this);
    this.vista.btCanelarLogin.addActionListener(this);
  }

  /**
   * Método que se ejecuta cuando se produce un evento de acción. Verifica el
   * comando de acción del evento y realiza la acción correspondiente.
   *
   * @param e el objeto ActionEvent que representa el evento de acción.
   */
  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "Iniciar login":
        logIn();
        break;
      case "Cancelar login":
        cerrarVentanaLogin();
        break;
      default:
        break;
    }
  }

  /**
   * Método para realizar el inicio de sesión. Verifica los datos ingresados en
   * los campos de texto de la vista y realiza la validación a través del DAO de
   * usuarios. Muestra mensajes de error o bienvenida según el resultado.
   */
  public void logIn() {
    if (vista.logInDatosCorrectos() == true) {
      String nombreUsuario = vista.txtNombreUsuario.getText();
      String contrasenia = vista.txtContrasenia.getText();
      usuario = new Usuario(nombreUsuario, contrasenia);
      Usuario usuarioActual = daoUsuario.iniciarSesion(usuario);

      if (usuarioActual != null) {
        vista.setVisible(false);
        SalaForm salaVista = new SalaForm();
        ControladorSala controladorSala = new ControladorSala(salaVista);
        controladorSala.vista.setVisible(true);
        controladorSala.vista.setLocationRelativeTo(null);
        JOptionPane.showMessageDialog(vista, "Bienvenido: " + usuario.getNombre());
      } else {
        JOptionPane.showMessageDialog(vista, "El usuario indicado no existe");
      }
    } else {
      JOptionPane.showMessageDialog(vista, "Todos los datos son requerido");
    }
  }

  /**
   * Método para cerrar la ventana de inicio de sesión. Llama al método
   * correspondiente en la vista para finalizar la aplicación.
   */
  public void cerrarVentanaLogin() {
    vista.cancelarInicioSesion();
  }
}
