
package controlador;

import dao.SalaDAO;
import dao.SalaDAOXML;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Sala;
import vista.SalaForm;

/**
 * Clase ControladorSala que implementa la interfaz ActionListener para
 * controlar las acciones en la vista de sala.
 *
 * @author Luis Trejos
 * @author Elder León
 * @version 1.0
 */
public class ControladorSala implements ActionListener {

  public SalaForm vista;
  public SalaDAO daoSala = new SalaDAOXML();
  public Sala sala;

  /**
   * Constructor de la clase ControladorSala.
   *
   * @param pVista La instancia de SalaForm que representa la vista de sala.
   */
  public ControladorSala(SalaForm pVista) {
    vista = pVista;
    sala = null;
    daoSala = new SalaDAOXML();

    this.vista.btCrearSala.addActionListener(this);
    this.vista.btCancelarSala.addActionListener(this);
  }

  /**
   * Método actionPerformed que se ejecuta cuando se realiza una acción en la
   * vista de sala.
   *
   * @param e El objeto ActionEvent que representa la acción realizada.
   */
  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "Crear Sala":
        agregarSala();
        break;
      case "Salir":
        cerrarVentanaSalas();
        break;
      default:
        break;
    }
  }

  /**
   * Método para agregar una sala a través de la vista.
   */
  public void agregarSala() {
    if (vista.datosValidos() == true) {
      String identificador = vista.txtIdentificador.getText();
      String ubicacion = vista.txtUbicacion.getText();
      String precio = vista.txtPrecio.getText();
      String estilo = vista.txtEstilo.getText();
      String tipo = vista.txtTipo.getText();
      String cantidadMesas = vista.txtCantidadMesas.getText();
      Sala sala = new Sala(identificador, ubicacion,  Double.parseDouble(precio),estilo, tipo, Integer.parseInt(cantidadMesas));
      boolean salaIngresada = daoSala.registrarSala(sala);
      if (salaIngresada) {
        JOptionPane.showMessageDialog(vista, "Se registro la sala con exito");
      } else {
        JOptionPane.showMessageDialog(vista, "Error: No se logro agregar la sala");
      }
    } else {
      JOptionPane.showMessageDialog(vista, "Error: Datos ingresados esta incorrectos");
    }
  }

  /**
   * Método para cerrar la ventana de salas en la vista.
   */
  public void cerrarVentanaSalas() {
    vista.cancelarAgregado();
  }
}
