package logicadenegocio;

import java.util.ArrayList;

/**
 *
 * @author Elder Leon  
 */
public class AplProyecto {
  
  public static void main (String[] args) {
    // Las directrices indican que debes declarar un puntero utilizando el
    //tipo de la SUPERCLASE y crear instancias de objetos utilizando 
    //el tipo de la SUPERCLASE. 
    Proyecto p1 = new Permanente ("AX125", "Disenio", 12500.0, 353000.0, 615);
    Proyecto p2 = new Temporal ("tp45", "implementacion", 12500.0, 353000.0, 85000, 1.25);
    Proyecto p3= new Permanente ("eff123", "programacion", 12500.0, 353000.0,615);

    ArrayList<Proyecto> misProyectos = new ArrayList<Proyecto> ();
    
    misProyectos.add(p1);
    misProyectos.add(p2);
    misProyectos.add(p3);
    
    for (Proyecto proyectoActual: misProyectos ){
      System.out.println(proyectoActual.toString());
      System.out.println(proyectoActual.calcularBalance());
    }
    
    Human p4 = new Boy ();
    Human p5 = new Human ();
    
    p4.caminar();
    p5.caminar();
  }
  
}
