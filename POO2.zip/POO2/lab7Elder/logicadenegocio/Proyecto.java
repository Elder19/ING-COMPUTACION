package logicadenegocio;

/**
 *
 * @author Elder Leon 
 */
public abstract class Proyecto {
  private String codigo;
  private String nombre;
  protected Double costoInicial;
  private Double ingresosAcumulados;
  
  public Proyecto (String pCodigo, String pNombre, Double pCI, Double pIA) { 
    costoInicial = pCI;
    nombre = pNombre;
    codigo = pCodigo;
    ingresosAcumulados = pIA;
  }

  //Método abstracto que debe ser 
  //implementado por las subclases para calcular el costo actual.
  public abstract double calcularCostoActual();
  
  //Método concreto que calcula el 
  //balance restando los ingresos acumulados al costo actual.
  public double calcularBalance() {
    return ingresosAcumulados - calcularCostoActual();
  }
  
  // metodo que sobre escribe 
  public String toString () {
    String cadena = "";
    
    cadena = "Codigo: "  + codigo + "\n";
    cadena += "Nombre : " + nombre+ "\n";
    cadena +="Costo inicial: " + costoInicial+ "\n";
    cadena += "Ingreso acumulado: " + ingresosAcumulados+ "\n";
    
    return cadena;
  }
  
}
