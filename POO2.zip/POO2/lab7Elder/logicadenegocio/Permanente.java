package logicadenegocio;

/**
 *
 * @author Elder Leon
 */
public final class Permanente extends Proyecto {
  private double valorDolar;
  
  // metodo principal 
  public Permanente (String pCodigo , String pNombre, Double pCI, Double pIA, double pDolar) {
    super (pCodigo,pNombre,pCI,pIA);
   
    valorDolar = pDolar;
  }
  
  // uso del metodo abstracto
  @Override
  public double calcularCostoActual() {
    return (costoInicial * valorDolar ); 
  }

  // metodo sobreescrito override
  public String toString () {
    String cadena = "";
    
    cadena = super.toString()+ "\n";
    cadena += "Valor dolar: " + valorDolar;
    return cadena;
  }

}
