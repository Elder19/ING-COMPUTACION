package logicadenegocio;

/**
 *
 * @author Elder Leon
 */
public class Boy extends Human {
  public static void caminar () {
    System.out.println("EL CHICO camina");
  }
  
}
