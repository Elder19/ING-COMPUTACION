package logicadenegocio;

/**
 *
 * @author Elder Leon  
 */
public class Human {
  public static void caminar() {
    System.out.println("Humano camina");
  }

}
