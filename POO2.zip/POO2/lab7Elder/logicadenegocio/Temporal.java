package logicadenegocio;

/**
 *
 * @author Elder Leon
 */
public final class Temporal extends Proyecto {
  private double costoAnualFijo;
  private Double inflacion;
  
  // metodo principal de clase
  public Temporal (String pCodigo , String pNombre, Double pCI, Double pIA, double pCAF, Double pInflacion ){
    super (pCodigo,pNombre,pCI,pIA);
    
    costoAnualFijo = pCAF;
    inflacion = pInflacion;
    
  }
  // Uso y desarrollo del metodo abstracto
  @Override
  public double calcularCostoActual() {
    return (costoInicial+ costoAnualFijo ) * inflacion;
  }
  
  // metodo override
  public String toString () {
    String cadena = "";
    
    cadena = super.toString()+ "\n";
    cadena += "Costo Anual Fijo: " + costoAnualFijo+ "\n";
    cadena += "Inflacion: " + inflacion+ "\n";
    return cadena;
  }

}
